# -*- coding: utf-8 -*-
# EspaDaily — Copyright (C) 2024-2026 RubénSDFA1labernt (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
import os
import json
import xbmc
import xbmcaddon
import xbmcvfs



# Paths
_PROFILE_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
if not os.path.exists(_PROFILE_PATH): os.makedirs(_PROFILE_PATH)

_CONTEXT_FILE = os.path.join(_PROFILE_PATH, "full_context.json")
_DEBUG_FILE = os.path.join(_PROFILE_PATH, 'debug_state.json')
_FROZEN_FILE = os.path.join(_PROFILE_PATH, 'frozen_state.json')
_RECENT_FILE = os.path.join(_PROFILE_PATH, 'recent_state.json')
_FAV_FILE = os.path.join(_PROFILE_PATH, 'favorites.json')
_DL_FILE = os.path.join(_PROFILE_PATH, 'downloads_history.json')
_DURATION_FILE = os.path.join(_PROFILE_PATH, 'min_duration.json')
_ADVANCED_SEARCH_FILE = os.path.join(_PROFILE_PATH, 'advanced_search_state.json')
_SNAPSHOT_CTX_FILE = os.path.join(_PROFILE_PATH, 'snapshot_context.json')
_PALANTIR_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'palantir_integration_state.json')


def get_context_level():
    if not os.path.exists(_CONTEXT_FILE): return 1 # Default Level 1
    try:
        with open(_CONTEXT_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            val = data.get("level", 1)

            if isinstance(val, bool): return 1 if val else 0
            return int(val)
    except Exception: return 1

def cycle_context_level():
    """Cicla el nivel 0 -> 1 -> 2 -> 3 -> 0 y lo guarda. Devuelve el nuevo nivel."""
    current = get_context_level()
    new_level = (current + 1) % 4
    try:
        with open(_CONTEXT_FILE, 'w', encoding='utf-8') as f: json.dump({"level": new_level}, f)
        return new_level
    except Exception:
        return current


def get_snapshot_context_level():
    if not os.path.exists(_SNAPSHOT_CTX_FILE): return -1
    try:
        with open(_SNAPSHOT_CTX_FILE, 'r', encoding='utf-8') as f:
            return int(json.load(f).get("level", -1))
    except Exception: return -1

def cycle_snapshot_context():
    """Cicla -1 -> 0 -> 1 -> 2 -> -1"""
    curr = get_snapshot_context_level()
    new_val = curr + 1
    if new_val > 2: new_val = -1
    
    with open(_SNAPSHOT_CTX_FILE, 'w', encoding='utf-8') as f: json.dump({"level": new_val}, f)
    return new_val

def build_query(title, context_data, force_level=None):
    """Aplica contexto a un titulo segun el nivel configurado."""
    depth = get_context_level() if force_level is None else force_level
    
    if depth == 0: return title.strip()
    if not context_data: return title.strip()

    clean_title = title.strip()
    

    if "||" in context_data:
        parts = context_data.split("||")

        if depth > len(parts): depth = len(parts) 
        used = parts[-depth:]
        ctx_str = " ".join(used)
    else:

        ctx_str = context_data


    if ctx_str.lower() not in clean_title.lower():

        return f"{ctx_str} {clean_title}".strip()
    
    return clean_title



def is_debug_active():
    if not os.path.exists(_DEBUG_FILE): return False
    try:
        with open(_DEBUG_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_debug_active(state):
    with open(_DEBUG_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)



def is_frozen_active():
    if not os.path.exists(_FROZEN_FILE): return False
    try:
        with open(_FROZEN_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False


_PRIORITY_FILE = os.path.join(_PROFILE_PATH, 'priority_state.json')

def is_prioritize_match_active():
    if not os.path.exists(_PRIORITY_FILE): return False
    try:
        with open(_PRIORITY_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_prioritize_match(state):
    with open(_PRIORITY_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)



def is_recent_active():
    if not os.path.exists(_RECENT_FILE): return False
    try:
        with open(_RECENT_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_recent_active(state):
    with open(_RECENT_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)



def get_favorites():
    if not os.path.exists(_FAV_FILE): return []
    try:
        with open(_FAV_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return []

def add_favorite(title, url, icon, platform, action, params=None):
    favs = get_favorites()

    if any(f['title'] == title and f['platform'] == platform for f in favs): return False
    
    favs.append({
        "title": title, "url": url, "icon": icon, 
        "platform": platform, "action": action, "params": params or {}
    })
    try:
        with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(favs, f)
        return True
    except Exception: return False

def remove_favorite(url):
    favs = get_favorites()
    new_favs = [f for f in favs if f['url'] != url]
    with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(new_favs, f)
    return len(favs) != len(new_favs)

def rename_favorite(url, new_title):
    favs = get_favorites()
    changed = False
    for f in favs:
        if f['url'] == url:
            f['title'] = new_title
            changed = True
            break
    if changed:
        with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(favs, f)
    return changed

def move_favorite(url, direction):
    favs = get_favorites()
    index = -1
    for i, f in enumerate(favs):
        if f['url'] == url:
            index = i
            break
            
    if index == -1: return False
    
    if direction == "up" and index > 0:
        favs[index], favs[index-1] = favs[index-1], favs[index]
        with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(favs, f)
        return True
    elif direction == "down" and index < len(favs) - 1:
        favs[index], favs[index+1] = favs[index+1], favs[index]
        with open(_FAV_FILE, 'w', encoding='utf-8') as f: json.dump(favs, f)
        return True
        
    return False



def get_downloads():
    if not os.path.exists(_DL_FILE): return []
    try:
        with open(_DL_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return []

def log_download(title, path, vid):
    dls = get_downloads()

    entry = {"title": title, "path": path, "vid": vid}
    import time
    entry["date"] = time.strftime("%d/%m/%Y %H:%M")
    dls.insert(0, entry)
    dls = dls[:50]
    with open(_DL_FILE, 'w', encoding='utf-8') as f: json.dump(dls, f)

def remove_download(path):
    dls = get_downloads()
    new_dls = [d for d in dls if d['path'] != path]
    with open(_DL_FILE, 'w', encoding='utf-8') as f: json.dump(new_dls, f)


def get_min_duration():
    if not os.path.exists(_DURATION_FILE): return 0
    try:
        with open(_DURATION_FILE, 'r', encoding='utf-8') as f: return json.load(f).get('minutes', 0)
    except Exception: return 0

def set_min_duration(minutes):
    with open(_DURATION_FILE, 'w', encoding='utf-8') as f: json.dump({'minutes': minutes}, f)


def is_advanced_search_active():
    if not os.path.exists(_ADVANCED_SEARCH_FILE): return True
    try:
        with open(_ADVANCED_SEARCH_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', True)
    except Exception: return True

def set_advanced_search_active(state):
    with open(_ADVANCED_SEARCH_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)


_PALANTIR_SEARCH_FILE = os.path.join(_PROFILE_PATH, 'palantir_search_state.json')

def is_palantir_search_active():
    if not os.path.exists(_PALANTIR_SEARCH_FILE): return False
    try:
        with open(_PALANTIR_SEARCH_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_palantir_search_active(state):
    with open(_PALANTIR_SEARCH_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)


def is_palantir_integration_enabled():
    """Devuelve True si la integracion con Palantir 3 esta habilitada (por defecto: True)."""
    if not os.path.exists(_PALANTIR_INTEGRATION_FILE): return True
    try:
        with open(_PALANTIR_INTEGRATION_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', True)
    except Exception: return True

def set_palantir_integration_enabled(state):
    """Guarda el estado del toggle de integracion con Palantir."""
    with open(_PALANTIR_INTEGRATION_FILE, 'w', encoding='utf-8') as o: json.dump({'active': state}, o)

def is_palantir_installed():
    """Comprueba si plugin.video.palantir3 esta instalado en el sistema."""
    try:
        return xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)")
    except Exception:
        return False



_LEGAL_DISCLAIMER_FILE = os.path.join(_PROFILE_PATH, 'legal_state.json')

def is_legal_disclaimer_accepted():
    if not os.path.exists(_LEGAL_DISCLAIMER_FILE): return False
    try:
        with open(_LEGAL_DISCLAIMER_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('accepted', False)
    except Exception: return False


def set_legal_disclaimer_accepted(state):
    with open(_LEGAL_DISCLAIMER_FILE, 'w', encoding='utf-8') as o: json.dump({'accepted': state}, o)


_TRAKT_SETTINGS_FILE = os.path.join(_PROFILE_PATH, 'trakt_settings.json')

def get_trakt_settings():
    if not os.path.exists(_TRAKT_SETTINGS_FILE): return {"api_key": "", "lists": []}
    try:
        with open(_TRAKT_SETTINGS_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return {"api_key": "", "lists": []}

def save_trakt_settings(data):
    with open(_TRAKT_SETTINGS_FILE, 'w', encoding='utf-8') as f: json.dump(data, f)

def get_trakt_api_key():
    return get_trakt_settings().get("api_key", "")

def set_trakt_api_key(key):
    data = get_trakt_settings()
    data["api_key"] = key
    save_trakt_settings(data)

def get_trakt_lists():
    return get_trakt_settings().get("lists", [])

def add_trakt_list(list_id, name, user, item_count=0):
    data = get_trakt_settings()
    lists = data.get("lists", [])

    for l in lists:
        if l['id'] == list_id:

            l['name'] = name
            l['user'] = user
            l['item_count'] = item_count
            save_trakt_settings(data)
            return
    
    lists.append({"id": list_id, "name": name, "user": user, "item_count": item_count})
    data["lists"] = lists
    save_trakt_settings(data)

def remove_trakt_list(list_id):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    new_lists = [l for l in lists if l['id'] != list_id]
    data["lists"] = new_lists
    save_trakt_settings(data)

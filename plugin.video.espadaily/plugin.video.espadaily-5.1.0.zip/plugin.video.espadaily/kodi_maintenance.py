# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""Mantenimiento del sistema Kodi: paquetes, miniaturas en desuso, bases de datos
y copia de la configuración de Kodi.

Independiente de storage_manager.py (que gestiona las cachés propias del addon).
No toca datos de EspaDaily ni de otros addons.
"""
import glob
import os
import re
import shutil
import sqlite3
import time
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timedelta, timezone

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_LOG = "[EspaDaily-MAINT]"
ADDON = xbmcaddon.Addon()

# glob de stdlib no resuelve special://: se traduce a ruta real una sola vez.
DB_DIR = xbmcvfs.translatePath("special://database/")
THUMBS_DIR = xbmcvfs.translatePath("special://thumbnails/")
LOG_DIR = xbmcvfs.translatePath("special://logpath/")
TEMP_DIR = xbmcvfs.translatePath("special://temp/")
PKG_DIR = xbmcvfs.translatePath("special://home/addons/packages/")
ATEMP_DIR = xbmcvfs.translatePath("special://home/addons/temp/")
USERDATA_DIR = xbmcvfs.translatePath("special://masterprofile/")
HOME_ADDONS = xbmcvfs.translatePath("special://home/addons/")

# Ficheros de configuración de Kodi (verificados en disco). passwords.xml se
# excluye a propósito: contiene credenciales de fuentes SMB/NFS.
_CONFIG_FILES = ("guisettings.xml", "sources.xml", "favourites.xml",
                 "advancedsettings.xml", "RssFeeds.xml", "profiles.xml")

_CRASH_PATTERNS = (os.path.join(LOG_DIR, "*crashlog*.*"), os.path.join(TEMP_DIR, "*.dmp"))

# Caché de enlaces resueltos de resolveurl (si está instalado). Son ficheros con
# nombre hash, no una DB abierta -> se pueden borrar sin riesgo de lock.
RESOLVEURL_CACHE = xbmcvfs.translatePath(
    "special://profile/addon_data/script.module.resolveurl/cache/")

# A partir de este tamaño, un VACUUM puede tardar y necesita espacio temporal
# del orden de la propia DB; se pregunta antes de compactar (heurístico).
_VACUUM_WARN_BYTES = 256 * 1024 * 1024


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"{_LOG} {msg}", level)


def _notify(msg, icon=xbmcgui.NOTIFICATION_INFO, ms=3500):
    xbmcgui.Dialog().notification("EspaDaily", msg, icon, ms)


def fmt_size(b):
    if b < 1024:
        return f"{b} B"
    if b < 1024 * 1024:
        return f"{b / 1024:.1f} KB"
    return f"{b / 1024 / 1024:.2f} MB"


def _walk_size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def _safe_getsize(path):
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def _within(base, target):
    """True si target queda DENTRO de base. Defensa anti path-traversal en el
    borrado de miniaturas: un cachedurl corrupto con '..' no debe escapar de
    Thumbnails y tocar otra cosa."""
    try:
        base_real = os.path.realpath(base)
        return os.path.commonpath([base_real, os.path.realpath(target)]) == base_real
    except (ValueError, OSError):
        return False


def _safe_remove(path):
    """Borra un fichero o carpeta. Devuelve los bytes liberados (0 si falla)."""
    try:
        if os.path.isdir(path):
            sz = _walk_size(path)
            shutil.rmtree(path, ignore_errors=True)
            return sz if not os.path.exists(path) else 0
        sz = os.path.getsize(path)
        os.remove(path)
        return sz
    except OSError as e:
        _log(f"No se pudo borrar {path}: {e}", xbmc.LOGWARNING)
        return 0


def _chunks(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def latest_db(prefix):
    """Ruta del fichero {prefix}NN.db de mayor versión, o None. Nunca se hardcodea
    el número de versión (cambia entre versiones de Kodi)."""
    rx = re.compile(re.escape(prefix) + r"(\d+)\.db$", re.IGNORECASE)
    best, best_ver = None, -1
    for path in glob.glob(os.path.join(DB_DIR, prefix + "*.db")):
        m = rx.search(os.path.basename(path))
        if m and int(m.group(1)) > best_ver:
            best_ver, best = int(m.group(1)), path
    return best


# --- Limpieza de archivos del sistema (workers internos: sin UI, devuelven bytes) ---

def _clear_packages_bytes():
    """Vacía addons/packages: .zip de instaladores cacheados, sus .crc y carpetas
    de descompresión. Todo es regenerable; Kodi lo vuelve a bajar si hace falta."""
    if not os.path.isdir(PKG_DIR):
        return 0
    return sum(_safe_remove(os.path.join(PKG_DIR, e)) for e in os.listdir(PKG_DIR))


def _clear_addons_temp_bytes():
    if not os.path.isdir(ATEMP_DIR):
        return 0
    return sum(_safe_remove(os.path.join(ATEMP_DIR, e)) for e in os.listdir(ATEMP_DIR))


def _crash_files():
    """Rutas (sin duplicados) de crashlogs y minidumps. Los patrones
    (*crashlog*.* y *.dmp) nunca casan con kodi.log/kodi.old.log. El realpath
    deduplica por si special://logpath y special://temp solapan."""
    found = set()
    for pat in _CRASH_PATTERNS:
        for entry in glob.glob(pat):
            found.add(os.path.realpath(entry))
    return found


def _clear_crashlogs_bytes():
    return sum(_safe_remove(p) for p in _crash_files())


def _resolveurl_cache_size():
    """Tamaño de la caché de enlaces de resolveurl, o 0 si no está instalado o
    está vacía. La opción del menú solo se ofrece cuando esto es > 0."""
    if not xbmc.getCondVisibility("System.HasAddon(script.module.resolveurl)"):
        return 0
    if not os.path.isdir(RESOLVEURL_CACHE):
        return 0
    return _walk_size(RESOLVEURL_CACHE)


def _clear_resolveurl_cache_bytes():
    """Vacía SOLO el contenido de cache/ de resolveurl (nunca settings.xml ni sesión,
    que están en el directorio padre). Son enlaces resueltos cacheados, regenerables."""
    if not os.path.isdir(RESOLVEURL_CACHE):
        return 0
    freed = 0
    for entry in os.listdir(RESOLVEURL_CACHE):
        full = os.path.join(RESOLVEURL_CACHE, entry)
        if _within(RESOLVEURL_CACHE, full):  # defensa: nunca salir de cache/
            freed += _safe_remove(full)
    return freed


def _confirm_and_clean(label, size, worker, detail):
    if size == 0:
        return
    if not xbmcgui.Dialog().yesno(
        label, f"{detail}\n\nSe liberarán [B]{fmt_size(size)}[/B].\n\n¿Continuar?"):
        return
    _notify(f"Liberados {fmt_size(worker())}")


def _do_bundle(total):
    if total == 0:
        return
    if not xbmcgui.Dialog().yesno(
        "Limpieza completa segura",
        f"Se borrarán paquetes de instalación, temporales de addons y registros de "
        f"fallos ([B]{fmt_size(total)}[/B]).\n\n"
        "[COLOR lightgreen]No toca tus datos ni los de otros addons.[/COLOR]\n\n¿Continuar?"):
        return
    freed = _clear_packages_bytes() + _clear_addons_temp_bytes() + _clear_crashlogs_bytes()
    _notify(f"Liberados {fmt_size(freed)}")


# --- Miniaturas en desuso ---

def old_thumbs():
    dbfile = latest_db("Textures")
    if not dbfile:
        _notify("No se encontró la base de datos de miniaturas", xbmcgui.NOTIFICATION_WARNING)
        return

    choices = (("7 días", 7), ("30 días", 30), ("90 días", 90))
    idx = xbmcgui.Dialog().select("Borrar miniaturas sin usar desde hace…",
                                  [c[0] for c in choices])
    if idx < 0:
        return
    days = choices[idx][1]
    # lastusetime lo escribe Kodi con CURRENT_TIMESTAMP (UTC): el corte va en UTC.
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")

    conn = sqlite3.connect(dbfile, timeout=2.0, isolation_level=None)
    try:
        # HAVING MAX(lastusetime) es defensivo. Hoy Kodi guarda 1 fila por textura,
        # pero versiones antiguas guardaban varias (solo se borra si TODAS son viejas).
        rows = conn.execute(
            "SELECT t.id, t.cachedurl FROM texture t "
            "WHERE t.id IN (SELECT idtexture FROM sizes GROUP BY idtexture "
            "HAVING MAX(lastusetime) < ?)", (cutoff,)).fetchall()
        rows = [(i, c) for i, c in rows if c]
        if not rows:
            _notify(f"No hay miniaturas sin usar desde hace {days} días")
            return

        total = sum(_safe_getsize(p) for p in (os.path.join(THUMBS_DIR, c) for _i, c in rows)
                    if _within(THUMBS_DIR, p))
        if not xbmcgui.Dialog().yesno(
            "Miniaturas en desuso",
            f"Se borrarán [B]{len(rows)}[/B] miniaturas sin usar desde hace {days} días "
            f"([B]{fmt_size(total)}[/B]).\n\n"
            "Kodi las regenera al verlas; no afecta a las que usas.\n\n¿Continuar?"):
            return

        freed, done, interrumpido = 0, 0, False
        prog = xbmcgui.DialogProgressBG()
        prog.create("EspaDaily", "Borrando miniaturas en desuso…")
        try:
            for chunk in _chunks(rows, 200):
                ids = [r[0] for r in chunk]
                placeholders = ",".join("?" * len(ids))
                try:
                    # Fila ANTES que el fichero: una fila sin fichero se regenera
                    # sola; un fichero sin fila sería una entrada de caché obsoleta.
                    # El trigger textureDelete borra también las filas de sizes.
                    conn.execute(f"DELETE FROM texture WHERE id IN ({placeholders})", ids)
                except sqlite3.DatabaseError:
                    interrumpido = True  # bloqueada/corrupta a mitad: paramos y reportamos lo hecho
                    break
                for _i, cachedurl in chunk:
                    full = os.path.join(THUMBS_DIR, cachedurl)
                    # Solo se borra si es un FICHERO DENTRO de Thumbnails. La fila de
                    # la DB ya se borró arriba; un cachedurl raro (con '..' o que apunte
                    # a una carpeta) no toca nada fuera de Thumbnails.
                    if _within(THUMBS_DIR, full) and os.path.isfile(full):
                        freed += _safe_remove(full)
                done += len(chunk)
                prog.update(int(done * 100 / len(rows)), "EspaDaily", f"{done}/{len(rows)}")
        finally:
            prog.close()
        if interrumpido:
            _log("Textures DB ocupada durante el borrado por lotes", xbmc.LOGWARNING)
            _notify(f"Interrumpido (DB ocupada): {done} borradas, {fmt_size(freed)} liberados",
                    xbmcgui.NOTIFICATION_WARNING)
        else:
            _notify(f"Miniaturas: {done} borradas, {fmt_size(freed)} liberados")
    except sqlite3.DatabaseError as e:
        _log(f"No se pudo acceder a Textures DB: {e}", xbmc.LOGWARNING)
        _notify("No se pudo acceder a la base de datos de miniaturas", xbmcgui.NOTIFICATION_WARNING)
    finally:
        conn.close()


# --- Bases de datos de Kodi ---

def integrity_check():
    db_files = sorted(glob.glob(os.path.join(DB_DIR, "*.db")))
    if not db_files:
        _notify("No se encontraron bases de datos", xbmcgui.NOTIFICATION_WARNING)
        return
    lines = []
    prog = xbmcgui.DialogProgressBG()
    prog.create("EspaDaily", "Comprobando integridad…")
    try:
        for i, path in enumerate(db_files):
            name = os.path.basename(path)
            prog.update(int(i * 100 / len(db_files)), "EspaDaily", name)
            try:
                conn = sqlite3.connect(path, timeout=2.0)
                try:
                    # quick_check devuelve varias filas si hay corrupción; en sano: [('ok',)].
                    res = conn.execute("PRAGMA quick_check").fetchall()
                finally:
                    conn.close()
                if res == [("ok",)]:
                    lines.append(f"[COLOR lime]OK[/COLOR]      {name}")
                else:
                    lines.append(f"[COLOR red]PROBLEMA[/COLOR]   {name}")
            except sqlite3.OperationalError:
                lines.append(f"[COLOR gold]ocupada[/COLOR]   {name}")  # bloqueada por Kodi
            except sqlite3.DatabaseError:
                lines.append(f"[COLOR red]PROBLEMA[/COLOR]   {name}")  # corrupta / no es una DB
    finally:
        prog.close()
    xbmcgui.Dialog().textviewer("Integridad de bases de datos", "\n".join(lines))


def vacuum_dbs():
    db_files = sorted(glob.glob(os.path.join(DB_DIR, "*.db")))
    if not db_files:
        _notify("No se encontraron bases de datos", xbmcgui.NOTIFICATION_WARNING)
        return
    if not xbmcgui.Dialog().yesno(
        "Compactar bases de datos",
        "Compacta las bases de datos de Kodi para recuperar espacio.\n\n"
        "Si alguna está en uso ahora, se omite. Puede liberar 0 B si ya están "
        "compactas: es normal.\n\n¿Continuar?"):
        return

    # ¿Hay DBs grandes? Se pregunta UNA vez por adelantado, en vez de con diálogos
    # modales a mitad de la barra de progreso (mejor UX y la barra no miente).
    large = [p for p in db_files if _safe_getsize(p) > _VACUUM_WARN_BYTES]
    include_large = True
    if large:
        nombres = ", ".join(os.path.basename(p) for p in large)
        include_large = xbmcgui.Dialog().yesno(
            "Bases de datos grandes",
            f"[B]{nombres}[/B] son grandes; compactarlas puede tardar y necesita "
            "espacio temporal del tamaño de cada una.\n\n¿Incluirlas?")

    freed_total, vacuumed, skipped = 0, 0, 0
    prog = xbmcgui.DialogProgressBG()
    prog.create("EspaDaily", "Compactando bases de datos…")
    try:
        for i, path in enumerate(db_files):
            name = os.path.basename(path)
            prog.update(int(i * 100 / len(db_files)), "EspaDaily", name)
            if not include_large and _safe_getsize(path) > _VACUUM_WARN_BYTES:
                skipped += 1
                continue
            try:
                before = os.path.getsize(path)
                conn = sqlite3.connect(path, timeout=2.0, isolation_level=None)
                try:
                    if conn.execute("PRAGMA freelist_count").fetchone()[0] == 0:
                        skipped += 1
                        continue
                    conn.execute("VACUUM")
                finally:
                    conn.close()
                freed_total += max(0, before - os.path.getsize(path))
                vacuumed += 1
            except sqlite3.DatabaseError as e:
                # OperationalError (en uso por Kodi, típico en Epg/MyVideos) o
                # DatabaseError (corrupta / no es una DB): en ambos casos se omite.
                skipped += 1
                _log(f"VACUUM omitido {name}: {e}", xbmc.LOGDEBUG)
            except OSError as e:
                _log(f"VACUUM {name}: {e}", xbmc.LOGWARNING)
                skipped += 1
    finally:
        prog.close()
    _notify(f"Compactadas {vacuumed}, omitidas {skipped}. Liberados {fmt_size(freed_total)}")


# --- Copia de seguridad de la configuración de Kodi ---

def _backup_dir():
    p = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")), "kodi_config_backups")
    os.makedirs(p, exist_ok=True)
    return p


def _unique_path(path):
    """Evita pisar un fichero existente añadiendo _2, _3… antes de la extensión
    (dos copias en el mismo segundo tendrían el mismo nombre por timestamp)."""
    if not os.path.exists(path):
        return path
    root, ext = os.path.splitext(path)
    n = 2
    while os.path.exists(f"{root}_{n}{ext}"):
        n += 1
    return f"{root}_{n}{ext}"


def _sweep_orphan_tmp(dirpath, pattern):
    """Borra temporales huérfanos (>24 h) que pudieran quedar si el proceso murió
    entre escribir y os.replace. Inerte (no se listan como copias) y best effort."""
    cutoff = time.time() - 24 * 3600
    for p in glob.glob(os.path.join(dirpath, pattern)):
        try:
            if os.path.getmtime(p) < cutoff:
                os.remove(p)
        except OSError:
            pass


def _write_config_zip(target):
    """Escribe el ZIP de configuración de forma atómica (.tmp + os.replace) y
    devuelve la lista de ficheros incluidos. Lanza OSError/BadZipFile si falla;
    nunca deja un ZIP a medias en target."""
    tmp = target + ".tmp"
    included = []
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
            for name in _CONFIG_FILES:
                fp = os.path.join(USERDATA_DIR, name)
                if not os.path.isfile(fp):
                    continue
                try:
                    with open(fp, "rb") as fh:
                        data = fh.read()
                    # Validar que es XML íntegro (rechaza lectura truncada si Kodi lo
                    # reescribe a la vez). Tolerar BOM: Notepad en Windows lo añade y
                    # según la versión de expat ET.fromstring lo rechazaría.
                    ET.fromstring(data[3:] if data.startswith(b"\xef\xbb\xbf") else data)
                    zf.writestr(name, data)  # se guarda el original (BOM incluido)
                    included.append(name)
                except (OSError, ET.ParseError) as e:
                    _log(f"Omitido {name} (no legible o íntegro): {e}", xbmc.LOGWARNING)
            ids = sorted(d for d in os.listdir(HOME_ADDONS)
                         if d not in ("packages", "temp")
                         and os.path.isdir(os.path.join(HOME_ADDONS, d)))
            zf.writestr("installed_addons.txt", "\n".join(ids))
        with zipfile.ZipFile(tmp, "r") as zf:
            if zf.testzip() is not None:
                raise zipfile.BadZipFile("verificación CRC del ZIP falló")
        os.replace(tmp, target)
        return included
    except (OSError, zipfile.BadZipFile):
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
        raise


def _create_config_backup():
    target = _unique_path(os.path.join(
        _backup_dir(), f"Kodi_Config_{time.strftime('%Y%m%d_%H%M%S')}.zip"))
    try:
        included = _write_config_zip(target)
        _notify(f"Copia creada: {len(included)} ficheros + lista de addons")
    except (OSError, zipfile.BadZipFile) as e:
        _log(f"Error creando copia: {e}", xbmc.LOGERROR)
        _notify("No se pudo crear la copia", xbmcgui.NOTIFICATION_ERROR)


def _snapshot_before_restore():
    """Copia de la config ACTUAL antes de restaurar, para poder DESHACER si la
    restauración sale mal (idea tomada de loiolink). Best effort: si falla, se
    avisa pero la restauración continúa. Devuelve el path o None."""
    target = _unique_path(os.path.join(
        _backup_dir(), f"Kodi_Config_PRE_RESTORE_{time.strftime('%Y%m%d_%H%M%S')}.zip"))
    try:
        _write_config_zip(target)
        return target
    except (OSError, zipfile.BadZipFile) as e:
        _log(f"No se pudo crear copia previa a la restauración: {e}", xbmc.LOGWARNING)
        return None


def _restore_config_backup():
    bdir = _backup_dir()
    zips = sorted((f for f in os.listdir(bdir) if f.lower().endswith(".zip")), reverse=True)
    if not zips:
        _notify("No hay copias guardadas", xbmcgui.NOTIFICATION_WARNING)
        return
    zi = xbmcgui.Dialog().select("Restaurar copia de configuración", zips)
    if zi < 0:
        return
    source = os.path.join(bdir, zips[zi])
    undo = None
    staged = []          # [(tmp_path, dst_path), ...] escritos en fase 1
    replaced = failed = 0
    try:
        with zipfile.ZipFile(source, "r") as zf:
            # Restauración por lista blanca: solo nombres conocidos -> Zip-Slip imposible.
            present = [n for n in zf.namelist() if n in _CONFIG_FILES]
            if not present:
                xbmcgui.Dialog().ok("EspaDaily", "Esta copia no contiene configuración reconocida.")
                return
            sel = xbmcgui.Dialog().multiselect("¿Qué quieres restaurar?", present)
            if not sel:
                return
            # Aviso ANTES de escribir: el cambio es irreversible y guisettings/profiles
            # solo cuajan si se cierra Kodi por completo.
            if not xbmcgui.Dialog().yesno(
                "Restaurar configuración",
                f"Se sobrescribirán [B]{len(sel)}[/B] ficheros de configuración de Kodi.\n\n"
                "Después hay que reiniciar Kodi. Si restauras [B]guisettings.xml[/B] o "
                "[B]profiles.xml[/B], cierra Kodi por completo (no solo reiniciar el addon): "
                "Kodi los reescribe al cerrarse de forma normal y se perdería el cambio.\n\n"
                "¿Continuar?"):
                return
            # Copia de la config ACTUAL antes de sobrescribir, para poder deshacer.
            undo = _snapshot_before_restore()
            if undo is None and not xbmcgui.Dialog().yesno(
                "Sin copia de seguridad previa",
                "No se pudo guardar una copia de tu configuración actual (¿disco lleno?).\n\n"
                "Si restauras ahora [COLOR gold]no podrás deshacer automáticamente[/COLOR].\n\n"
                "¿Continuar de todos modos?"):
                return
            # Fase 1: escribir TODOS los seleccionados a su .maint_tmp. Si algo falla
            # aquí (p. ej. disco lleno), no se reemplaza ningún original: quedan intactos.
            for i in sel:
                name = present[i]
                dst_path = os.path.join(USERDATA_DIR, name)
                tmp_path = f"{dst_path}.maint_tmp"
                # Registrar ANTES de escribir: si copyfileobj falla, el except limpia
                # también el .tmp a medio escribir.
                staged.append((tmp_path, dst_path))
                with zf.open(name) as src, open(tmp_path, "wb") as dst:
                    shutil.copyfileobj(src, dst)
            # Fase 2: reemplazar. Se intentan TODOS (best effort): si uno falla,
            # seguir con el resto deja menos ficheros en estado viejo.
            for tmp_path, dst_path in staged:
                try:
                    os.replace(tmp_path, dst_path)
                    replaced += 1
                except OSError as e:
                    _log(f"No se pudo aplicar {os.path.basename(dst_path)}: {e}", xbmc.LOGERROR)
                    failed += 1
                    try:
                        os.remove(tmp_path)
                    except OSError:
                        pass
            staged = []
    except (OSError, zipfile.BadZipFile) as e:
        # Fallo en fase 1: no se ha reemplazado nada, los originales siguen intactos.
        _log(f"Error restaurando (fase 1): {e}", xbmc.LOGERROR)
        for tmp_path, _dst in staged:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        xbmcgui.Dialog().ok("Restauración cancelada",
                            "No se aplicó ningún cambio; tu configuración sigue intacta.")
        return
    if failed and replaced:
        msg = (f"Se aplicaron {replaced} ficheros y {failed} no.\n\n"
               "[COLOR gold]Tu configuración quedó a medias.[/COLOR]")
        if undo:
            msg += ("\nPara volver al estado anterior, restaura la copia:\n"
                    f"[B]{os.path.basename(undo)}[/B]")
        xbmcgui.Dialog().ok("Restauración incompleta", msg)
    elif failed:
        _notify(f"No se pudo aplicar la restauración ({failed} ficheros)",
                xbmcgui.NOTIFICATION_ERROR)
    elif undo:
        xbmcgui.Dialog().ok(
            "Restauración completada",
            "Reinicia Kodi para aplicar los cambios.\n\n"
            "[COLOR lightgreen]Por si quieres deshacer[/COLOR], se guardó tu configuración "
            f"anterior en la lista de copias:\n[B]{os.path.basename(undo)}[/B]")
    else:
        _notify("Configuración restaurada. Reinicia Kodi para aplicar.")


_BACKUP_HELP = "\n".join([
    "COPIA DE CONFIGURACIÓN DE KODI",
    "â”€" * 40,
    "",
    "Guarda en un ZIP los ajustes generales de Kodi para",
    "recuperarlos tras reinstalar:",
    "",
    "  • guisettings.xml (ajustes y skin)",
    "  • sources.xml (fuentes de archivos)",
    "  • favourites.xml (favoritos de Kodi)",
    "  • advancedsettings.xml (ajustes avanzados)",
    "  • RssFeeds.xml, profiles.xml",
    "  • lista de addons instalados (texto)",
    "",
    "NO incluye: bases de datos, miniaturas, datos de",
    "addons ni passwords.xml (credenciales de fuentes).",
    "",
    "Al restaurar se guarda antes una copia de tu configuración",
    "actual (PRE_RESTORE), que aparece en la lista de copias",
    "a restaurar por si quieres deshacer.",
    "",
    "Esto es la configuración de KODI. Tus datos de",
    "EspaDaily se respaldan aparte, en 'Copias de Seguridad'.",
])


def backup_submenu():
    # Limpiar restos temporales de un cierre abrupto previo (zip de copia y .tmp
    # de restauración). Inerte: ninguno se lista como copia restaurable.
    _sweep_orphan_tmp(_backup_dir(), "*.tmp")
    _sweep_orphan_tmp(USERDATA_DIR, "*.maint_tmp")
    while True:
        idx = xbmcgui.Dialog().select("Copia de configuración de Kodi", [
            "[COLOR green]Crear copia de la configuración[/COLOR]",
            "Restaurar una copia…",
            "[COLOR grey]¿Qué incluye? (ayuda)[/COLOR]",
        ])
        if idx == 0:
            _create_config_backup()
        elif idx == 1:
            _restore_config_backup()
        elif idx == 2:
            xbmcgui.Dialog().textviewer("Copia de configuración - ayuda", _BACKUP_HELP)
        else:
            break


# --- Menú principal ---

_HELP = "\n".join([
    "MANTENIMIENTO DE KODI",
    "â”€" * 40,
    "",
    "Limpia y optimiza KODI en general (no el addon).",
    "Tus datos de EspaDaily y los de otros addons no se tocan.",
    "",
    "  • Paquetes .zip: instaladores cacheados; Kodi los",
    "    vuelve a bajar si hace falta.",
    "  • Temporales de addons / crashlogs: archivos de paso.",
    "  • Miniaturas en desuso: solo las que no ves desde hace",
    "    tiempo; Kodi las regenera al volver a verlas.",
    "  • Compactar bases de datos: recupera espacio (VACUUM);",
    "    omite las que Kodi esté usando.",
    "  • Integridad: comprueba las bases de datos (solo lectura).",
    "  • Caché de enlaces (resolveurl): si lo tienes instalado,",
    "    vacía enlaces resueltos caducados (arregla links caídos).",
    "  • Copia de configuración: respalda los ajustes de Kodi.",
])


def maintenance_menu():
    while True:
        # try dentro del bucle: un fallo en una operación vuelve al menú, no expulsa.
        # La construcción del menú no lanza (_walk_size/_safe_getsize tragan OSError),
        # así que no hay riesgo de bucle de error.
        try:
            pkg = _walk_size(PKG_DIR) if os.path.isdir(PKG_DIR) else 0
            atemp = _walk_size(ATEMP_DIR) if os.path.isdir(ATEMP_DIR) else 0
            crash = sum(_safe_getsize(p) for p in _crash_files())
            resolver = _resolveurl_cache_size()
            bundle = pkg + atemp + crash

            opciones, acciones = [], []
            if bundle > 0:
                opciones.append(f"[COLOR red]Limpieza completa segura ({fmt_size(bundle)})[/COLOR]")
                acciones.append("bundle")
            if pkg > 0:
                opciones.append(f"Paquetes de instalación (.zip)    [COLOR grey]{fmt_size(pkg)}[/COLOR]")
                acciones.append("pkg")
            if atemp > 0:
                opciones.append(f"Temporales de addons    [COLOR grey]{fmt_size(atemp)}[/COLOR]")
                acciones.append("atemp")
            if crash > 0:
                opciones.append(f"Registros de fallos (crashlogs)    [COLOR grey]{fmt_size(crash)}[/COLOR]")
                acciones.append("crash")
            if resolver > 0:
                opciones.append(f"Caché de enlaces (resolveurl)    [COLOR grey]{fmt_size(resolver)}[/COLOR]")
                acciones.append("resolver")
            opciones.append("Miniaturas en desuso…")
            acciones.append("thumbs")
            opciones.append("[COLOR orange]Compactar bases de datos (VACUUM)[/COLOR]")
            acciones.append("vacuum")
            opciones.append("[COLOR grey]Comprobar integridad de las bases de datos[/COLOR]")
            acciones.append("integrity")
            opciones.append("[COLOR aqua]Copia de seguridad de Kodi (config)…[/COLOR]")
            acciones.append("backup")
            opciones.append("[COLOR grey]¿Qué hace cada opción? (ayuda)[/COLOR]")
            acciones.append("info")

            heading = (f"Mantenimiento de Kodi - {fmt_size(bundle)} en limpieza rápida"
                       if bundle > 0 else "Mantenimiento de Kodi")
            idx = xbmcgui.Dialog().select(heading, opciones)
            if idx < 0:
                break
            a = acciones[idx]
            if a == "bundle":
                _do_bundle(bundle)
            elif a == "pkg":
                _confirm_and_clean("Paquetes de instalación", pkg, _clear_packages_bytes,
                                   "Se vaciará la carpeta de paquetes (instaladores .zip y "
                                   "temporales de descompresión). Kodi los re-descarga si "
                                   "hace falta.")
            elif a == "atemp":
                _confirm_and_clean("Temporales de addons", atemp, _clear_addons_temp_bytes,
                                   "Se borrarán los temporales de instalación de addons.")
            elif a == "crash":
                _confirm_and_clean("Registros de fallos", crash, _clear_crashlogs_bytes,
                                   "Se borrarán crashlogs y minidumps. No se toca kodi.log.")
            elif a == "resolver":
                _confirm_and_clean("Caché de enlaces (resolveurl)", resolver,
                                   _clear_resolveurl_cache_bytes,
                                   "Se vaciará la caché de enlaces resueltos de resolveurl. "
                                   "Se regenera al reproducir; útil si hay enlaces caídos.")
            elif a == "thumbs":
                old_thumbs()
            elif a == "vacuum":
                vacuum_dbs()
            elif a == "integrity":
                integrity_check()
            elif a == "backup":
                backup_submenu()
            elif a == "info":
                xbmcgui.Dialog().textviewer("Mantenimiento de Kodi - ayuda", _HELP)
        except Exception as e:  # handler de UI: registra, avisa y vuelve al menú
            _log(f"Error inesperado en el menú: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("EspaDaily", f"Se produjo un error en mantenimiento:\n{e}")

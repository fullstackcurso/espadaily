# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
import sys
import os
import json
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import core_settings
import requests
import ui_utils

def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

def _get_thumb_cache_path(list_id):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, f"trakt_thumbs_{list_id}.json")

def _load_thumb_cache(list_id):
    path = _get_thumb_cache_path(list_id)
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception: pass
    return {}


def _meta_flag_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(p, 'trakt_meta_downloaded.flag')


def _meta_items_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(p, 'trakt_meta_items.json')


def _has_trakt_meta():
    return os.path.exists(_meta_flag_path())

def search_dialog(query, ot="", mode=""):
    """
    Muestra un diálogo para elegir dónde buscar: Dailymotion, Elementum,
    Palantir o el addon externo de Dailymotion (Gujal).
    Todas las opciones muestran un teclado con el texto pre-rellenado
    para que el usuario pueda editarlo antes de buscar.
    """
    if not query: return

    options = [
        "[COLOR gold]Editar búsqueda / Reintentar...[/COLOR]"
    ]
    actions = ["retry"]

    options.append("[B]Buscar en internet[/B]")
    actions.append("buscar")

    options.append("[B]Buscar en Megabuscador[/B]")
    actions.append("megabuscador")

    _ext_off = core_settings.are_external_integrations_disabled()

    # Elementum
    if xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
        options.append("[COLOR FFD2691E]Buscar en webs de torrent (Elementum)[/COLOR]")
        actions.append("elementum")

    if not _ext_off:
        # Palantir (Dinámico) solo aparece si está instalado.
        try:
            if core_settings.get_palantir_addon_id():
                options.append("[COLOR orange]Buscar en Palantir[/COLOR]")
                actions.append("palantir")
        except Exception: pass

        # Balandro (Dinámico) solo aparece si está instalado.
        try:
            if xbmc.getCondVisibility("System.HasAddon(plugin.video.balandro)"):
                options.append("[COLOR chartreuse]Buscar en Balandro[/COLOR]")
                actions.append("balandro")
        except Exception: pass

        # Jacktook (Dinámico) solo aparece si está instalado.
        try:
            if core_settings.is_jacktook_installed():
                options.append("[COLOR yellow]Buscar en Jacktook[/COLOR]")
                actions.append("jacktook")
        except Exception: pass

        # Alfa (Dinámico) solo aparece si está instalado.
        try:
            if core_settings.get_alfa_addon_id():
                options.append("[COLOR cyan]Buscar en Alfa[/COLOR]")
                actions.append("alfa")
        except Exception: pass

        # Dailymotion (Gujal)
        try:
            if xbmcaddon.Addon().getSetting('gujal_search_enabled') == 'true':
                if xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
                    options.append("[COLOR deepskyblue]Buscar en addon Dailymotion (Gujal)[/COLOR]")
                    actions.append("dm_gujal")
        except Exception: pass

        # TMDB Helper (Abrir en otro addon)
        try:
            if xbmc.getCondVisibility("System.HasAddon(plugin.video.themoviedb.helper)") and core_settings.is_tmdbhelper_integration_enabled():
                options.append("[COLOR plum]Abrir en otro addon[/COLOR]")
                actions.append("tmdbhelper")
        except Exception: pass

        # AtresDaily / EspaTV / TopZilla
        try:
            if xbmc.getCondVisibility("System.HasAddon(plugin.video.atresdaily)"):
                options.append("[COLOR gold]Buscar en AtresDaily[/COLOR]")
                actions.append("atresdaily")
            if xbmc.getCondVisibility("System.HasAddon(plugin.video.espatv)"):
                options.append("[COLOR gold]Buscar en EspaTV[/COLOR]")
                actions.append("espatv")
            if xbmc.getCondVisibility("System.HasAddon(plugin.video.topzilla)"):
                options.append("[COLOR gold]Buscar en TopZilla[/COLOR]")
                actions.append("topzilla")
        except Exception: pass

    # YouTube
    try:
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            options.append("[COLOR red]Buscar en YouTube[/COLOR]")
            actions.append("youtube")
    except Exception: pass

    # Atajos personalizados del usuario
    try:
        import search_shortcuts_manager as ssm
        for s in ssm.load_active_shortcuts():
            if s.get('type') == 'builtin':
                continue  # los builtins ya están arriba o no aplican aquí
            label = s.get('name', '?')
            options.append(label)
            actions.append(('custom', s))
    except Exception:
        pass

    sel = xbmcgui.Dialog().select(f"Buscar: {query}", options)
    if sel < 0: return

    choice = actions[sel]

    if choice == "retry":
        nq = ui_utils.get_text('Editar búsqueda', query or '')
        if nq:
            search_dialog(nq, ot, mode)

    elif choice == "buscar":
        xbmc.executebuiltin(
            f"Container.Update({_u(action='lfr', q=query, ot=ot, mode=mode)})")

    elif choice == "megabuscador":
        xbmc.executebuiltin(
            f"Container.Update({_u(action='bt_run', q=query)})")

    elif choice == "elementum":
        nq = ui_utils.get_text('Buscar en webs de torrent', query or '')
        if nq:
            xbmc.executebuiltin(
                f"RunPlugin({_u(action='elementum_search', q=nq)})")

    elif choice == "palantir":
        # palantir_search_prompt ya pide consentimiento del ajuste del skin (ensure_) antes de buscar.
        xbmc.executebuiltin(
            f"RunPlugin({_u(action='palantir_search_prompt', q=query)})")

    elif choice == "balandro":
        xbmc.executebuiltin(
            f"RunPlugin({_u(action='search_balandro_from_results', q=query)})")

    elif choice == "jacktook":
        xbmc.executebuiltin(
            f"RunPlugin({_u(action='search_jacktook_from_results', q=query)})")

    elif choice == "alfa":
        xbmc.executebuiltin(
            f"RunPlugin({_u(action='search_alfa_from_results', q=query)})")

    elif choice == "dm_gujal":
        xbmc.executebuiltin(
            f"Container.Update({_u(action='dm_gujal_search', q=query)})")

    elif choice == "youtube":
        nq = ui_utils.get_text('Buscar en YouTube', query or '').strip()
        if nq:
            url = _u(action='yt_html_search', q=nq)
            xbmc.executebuiltin(f'Container.Update({url})')

    elif choice == "tmdbhelper":
        xbmc.executebuiltin(
            f"RunPlugin({_u(action='tmdbhelper_search', q=query)})")

    elif choice in ("atresdaily", "espatv", "topzilla"):
        addon_ids = {
            "atresdaily": "plugin.video.atresdaily",
            "espatv": "plugin.video.espatv",
            "topzilla": "plugin.video.topzilla",
        }
        xbmc.executebuiltin(
            f"RunPlugin({_u(action='search_in_addon', addon_id=addon_ids[choice], q=query, ot=ot)})")

    elif isinstance(choice, tuple) and choice[0] == 'custom':
        s = choice[1]
        cmd = s.get('command', '')
        if cmd:
            xbmc.executebuiltin(cmd.replace('{query}', urllib.parse.quote_plus(query)))

def menu_collections():

    li = xbmcgui.ListItem(label="Listas de Trakt.tv")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_root"), listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(_handle())

def _get_tmdb_thumb(tmdb_id, fallback):
    if not tmdb_id:
        return fallback
    try:
        r = requests.get(
            f"https://api.themoviedb.org/3/movie/{tmdb_id}",
            params={"api_key": core_settings._ESPADAILY_TMDB_API_KEY},
            timeout=5
        )
        if r.status_code == 200:
            poster_path = r.json().get("poster_path")
            if poster_path:
                return f"https://image.tmdb.org/t/p/w342{poster_path}"
    except Exception:
        pass
    return fallback

def menu_trakt_root():
    core_settings.seed_default_trakt_lists(core_settings.get_trakt_api_key())

    _media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    li = xbmcgui.ListItem(label="[COLOR yellow][B]Actualizar nombres y datos[/B][/COLOR]")
    li.setArt({'icon': os.path.join(_media, 'adv_refrescar.png')})
    li.setInfo('video', {'plot': "Obtiene el nombre real y el número de ítems de todas las listas desde Trakt."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_refresh_defaults"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR blue]Opciones / Importar[/COLOR]")
    li.setArt({'icon': os.path.join(_media, 'url_config.png')})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_options"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Películas Top (130+ históricas)")
    li.setArt({'icon': os.path.join(_media, 'cat_peliculas.png')})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="top_movies", page=1), listitem=li, isFolder=True)

    lists = core_settings.get_trakt_lists()
    for l in lists:
        count = l.get('item_count', 0)
        name = l.get('name') or f"Lista #{l.get('id', '?')}"
        label = f"{name} [COLOR gray]({count} ítems)[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultFolder.png'})
        li.setInfo('video', {'plot': f"ID: {l['id']}\nUsuario: {l['user']}\nTotal: {count} elementos."})

        cm = [("Eliminar lista", f"RunPlugin({_u(action='trakt_delete_list', list_id=l['id'])})")]
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_view_list", list_id=l['id']), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(_handle())

def refresh_all_lists():
    api_key = core_settings.get_trakt_api_key()
    if not api_key:
        xbmcgui.Dialog().notification("Error", "No hay API Key configurada", xbmcgui.NOTIFICATION_ERROR)
        return
    lists = core_settings.get_trakt_lists()
    if not lists:
        xbmcgui.Dialog().notification("Trakt", "No hay listas para actualizar", xbmcgui.NOTIFICATION_INFO)
        return
    headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': api_key}
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaDaily", "Actualizando listas de Trakt...")
    total = len(lists)
    for i, l in enumerate(lists):
        if pDialog.iscanceled():
            break
        pDialog.update(int((i / total) * 100), f"({i+1}/{total}) {l['name']}")
        try:
            r = requests.get(f"https://api.trakt.tv/lists/{l['id']}", headers=headers, timeout=5)
            if r.status_code == 200:
                data = r.json()
                l['name'] = data.get('name', l['name'])
                l['user'] = data.get('user', {}).get('username', l.get('user', 'official')) if isinstance(data.get('user'), dict) else l.get('user', 'official')
                l['item_count'] = data.get('item_count', l.get('item_count', 0))
        except Exception:
            pass
    pDialog.close()
    settings = core_settings.get_trakt_settings()
    existing = {l['id']: l for l in settings.get('lists', [])}
    for l in lists:
        if l['id'] in existing:
            existing[l['id']].update(l)
    settings['lists'] = list(existing.values())
    core_settings.save_trakt_settings(settings)
    xbmcgui.Dialog().notification("EspaDaily", "Listas actualizadas correctamente", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def menu_options():
    _media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    li = xbmcgui.ListItem(label="[COLOR yellow][B]Guía: Cómo obtener tu API Key (Paso a Paso)[/B][/COLOR]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    li.setInfo('video', {'plot': "Instrucciones detalladas de cómo registrarte en Trakt.tv para obtener tu propia llave Client ID."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_help_guide"), listitem=li, isFolder=False)

    key = core_settings.get_trakt_api_key()
    status = "[COLOR green]CONFIGURADA[/COLOR]" if key else "[COLOR red]NO CONFIGURADA[/COLOR]"

    li = xbmcgui.ListItem(label=f"Configurar API Key {status}")
    li.setArt({'icon': os.path.join(_media, 'url_config.png')})
    li.setInfo('video', {'plot': "Pulsa aquí para introducir tu Client ID una vez lo tengas."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_set_key"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Importar colecciones desde EspaTV")
    li.setArt({'icon': os.path.join(_media, 'cat_espatv.png')})
    li.setInfo('video', {'plot': "Copia las colecciones que tengas guardadas en EspaTV a EspaDaily.\nSolo añade las que no tengas ya."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_import_espatv"), listitem=li, isFolder=False)

    if key:
        li = xbmcgui.ListItem(label="Importar por ID")
        li.setArt({'icon': os.path.join(_media, 'url_cloud.png')})
        li.setInfo('video', {'plot': "Introduce el ID numérico de la lista pública (ej: 21583416)"})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_import"), listitem=li, isFolder=False)

    if _has_trakt_meta():
        li = xbmcgui.ListItem(label="[COLOR red]Borrar metadatos TMDB de Trakt[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        li.setInfo('video', {'plot': "Elimina los metadatos TMDB guardados para todas las listas de Trakt."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_clear_all_meta"), listitem=li, isFolder=False)
    elif key:
        li = xbmcgui.ListItem(label="Metadatos TMDB en español (sinopsis, director, actores)")
        li.setArt({'icon': os.path.join(_media, 'cat_cinemeta.png')})
        li.setInfo('video', {'plot': "Descarga sinopsis en español, director y reparto de TMDB para todas las listas de Trakt.\nSustituye los textos en inglés de Trakt por los datos completos en español."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_cache_all_meta"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(_handle())

def import_from_espatv():
    espatv_file = os.path.join(
        xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.espatv/'),
        'trakt_settings.json'
    )
    if not os.path.exists(espatv_file):
        xbmcgui.Dialog().ok("EspaTV no encontrado", "No se encontró el archivo de colecciones de EspaTV.\nAsegúrate de que EspaTV está instalado y tiene colecciones guardadas.")
        return
    try:
        with open(espatv_file, 'r', encoding='utf-8') as f:
            espatv_data = json.load(f)
    except Exception as e:
        xbmcgui.Dialog().ok("Error al leer EspaTV", f"No se pudo leer el archivo de EspaTV:\n{e}")
        return

    source_lists = espatv_data.get('lists', [])
    if not isinstance(source_lists, list) or not source_lists:
        xbmcgui.Dialog().notification("EspaDaily", "EspaTV no tiene colecciones guardadas", xbmcgui.NOTIFICATION_INFO)
        return

    existing_ids = {l['id'] for l in core_settings.get_trakt_lists() if l.get('id')}
    new_lists = [l for l in source_lists if l.get('id') and l['id'] not in existing_ids]
    if not new_lists:
        xbmcgui.Dialog().notification("EspaDaily", "Todas las colecciones de EspaTV ya están importadas", xbmcgui.NOTIFICATION_INFO)
        return

    imported = 0
    try:
        for lst in new_lists:
            core_settings.add_trakt_list(
                lst['id'],
                lst.get('name') or f"Lista #{lst['id']}",
                lst.get('user', 'espatv'),
                lst.get('item_count', 0),
            )
            imported += 1
    except Exception as e:
        xbmcgui.Dialog().ok("Error al importar", f"Se guardaron {imported} de {len(new_lists)} colecciones.\n{e}")
        if imported:
            xbmc.executebuiltin("Container.Refresh")
        return

    msg = f"Importada {imported} colección de EspaTV" if imported == 1 else f"Importadas {imported} colecciones de EspaTV"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def help_guide():
    heading = "[COLOR yellow]GUÍA: CONFIGURAR TRAKT.TV[/COLOR]"
    
    text = (
        "[B]PASO 1: REGISTRO[/B]\n"
        "Entra en tu navegador (PC o móvil) a:\n"
        "[COLOR cyan]https://trakt.tv/oauth/applications[/COLOR]\n"
        "Identifícate con tu cuenta de usuario.\n\n"
        
        "[B]PASO 2: CREAR APLICACIÓN[/B]\n"
        "Pulsa el botón verde [B]NEW APPLICATION[/B].\n\n"
        
        "[B]PASO 3: RELLENAR DATOS[/B]\n"
        "Copia y pega exactamente esto en los cuadros:\n"
        " • [B]Name:[/B] EspaDaily\n"
        " • [B]Description:[/B] Addon de Kodi\n"
        " • [B]Redirect uri:[/B] urn:ietf:wg:oauth:2.0:oob\n"
        " • [B]Javascript (cors) origins:[/B] (Vacío)\n"
        " • [B]Permissions:[/B] No marques nada.\n\n"
        "Baja al final y dale al botón morado [B]SAVE APP[/B].\n\n"
        
        "[B]PASO 4: OBTENER EL CÓDIGO[/B]\n"
        "Tras guardar, aparecerán varios códigos.\n"
        "Busca el que dice [B]Client ID[/B] (es una línea de letras y números).\n\n"
        "Copia ese código y pégalo en el menú 'Configurar API Key' de este addon.\n\n"
        "--------------------------------------------------\n"
        "[I]* Nota: La API Key es personal y gratuita. Solo sirve para que el addon pueda leer las listas públicas de Trakt.tv.[/I]"
    )
    
    xbmcgui.Dialog().textviewer(heading, text)

def set_api_key():
    k = xbmc.Keyboard(core_settings.get_trakt_api_key(), 'Introduce Trakt Client ID (API Key)')
    k.doModal()
    if k.isConfirmed():
        key = k.getText().strip()
        core_settings.set_trakt_api_key(key)
        xbmcgui.Dialog().notification("EspaDaily", "API Key Guardada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")

def import_list():
    key = core_settings.get_trakt_api_key()
    if not key:
        xbmcgui.Dialog().notification("Error", "Configura la API Key primero", xbmcgui.NOTIFICATION_ERROR)
        return

    k = xbmc.Keyboard('', 'Introduce ID numérico de la lista')
    k.doModal()
    if k.isConfirmed():
        list_id = k.getText().strip()
        if not list_id: return
        

        headers = {
            'Content-Type': 'application/json',
            'trakt-api-version': '2',
            'trakt-api-key': key
        }
        

        pDialog = xbmcgui.DialogProgress()
        pDialog.create("EspaDaily", "Importando lista de Trakt...")
        
        try:
    
            r = requests.get(f'https://api.trakt.tv/lists/{list_id}', headers=headers)
            if r.status_code != 200:
                pDialog.close()
                xbmcgui.Dialog().notification("Error Trakt", f"Error {r.status_code}: No se pudo leer la lista", xbmcgui.NOTIFICATION_ERROR)
                return
            
            data = r.json()
            name = data.get('name', f'Lista {list_id}')
            user = data.get('user', {}).get('username', 'Unknown')
            item_count = data.get('item_count', 0)
            
    
            core_settings.add_trakt_list(list_id, name, user, item_count)
            
            pDialog.close()
            
            # Preguntar si abrirla ya
            if xbmcgui.Dialog().yesno("EspaDaily", f"Lista '{name}' importada con éxito.\n\n¿Quieres abrirla ahora mismo?"):
                xbmc.executebuiltin(f"Container.Update({_u(action='trakt_view_list', list_id=list_id)})")
            else:
                # Volver a la raiz de Trakt
                xbmc.executebuiltin(f"Container.Update({_u(action='trakt_root')})")
            
        except Exception as e:
            if 'pDialog' in locals(): pDialog.close()
            xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

def _collect_all_trakt_items(key, pDialog=None):
    """Obtiene todos los items de todas las listas sin duplicados. Devuelve lista de dicts."""
    headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': key}
    lists = core_settings.get_trakt_lists()
    all_items = []
    seen = set()
    total_lists = len(lists)
    for i, lst in enumerate(lists):
        if pDialog and pDialog.iscanceled():
            break
        if pDialog:
            pDialog.update(
                int((i / max(total_lists, 1)) * 100),
                "Lista ({0}/{1}): {2}".format(i + 1, total_lists, lst.get('name', lst['id']))
            )
        try:
            r = requests.get(
                'https://api.trakt.tv/lists/{0}/items?extended=full'.format(lst['id']),
                headers=headers, timeout=15,
            )
            if r.status_code != 200:
                xbmc.log("[EspaDaily-TM] list {0} -> {1}".format(lst['id'], r.status_code), xbmc.LOGWARNING)
                continue
            for item in r.json():
                if not isinstance(item, dict):
                    continue
                t = item.get('type')
                if t not in ('movie', 'show'):
                    continue
                data = item.get(t)
                if not data:
                    continue
                tmdb_id = data.get('ids', {}).get('tmdb')
                title = data.get('title')
                year = data.get('year')
                media_type = 'show' if t == 'show' else 'movie'
                dedup_key = (tmdb_id or title, year, media_type)
                if dedup_key in seen:
                    continue
                seen.add(dedup_key)
                all_items.append({'tmdb_id': tmdb_id, 'title': title, 'year': year, 'media_type': media_type})
        except Exception as e:
            xbmc.log("[EspaDaily-TM] collect list {0}: {1}".format(lst.get('id'), e), xbmc.LOGWARNING)
    if pDialog and not pDialog.iscanceled():
        pDialog.update(100)
    return all_items


def cache_all_meta():
    import metadata_enricher as me

    key = core_settings.get_trakt_api_key()
    if not key:
        xbmcgui.Dialog().ok("Error", "No hay API Key configurada para Trakt.")
        return

    lists = core_settings.get_trakt_lists()
    if not lists:
        xbmcgui.Dialog().ok("Trakt", "No hay listas configuradas en Trakt.")
        return

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaDaily", "Recopilando elementos de las listas de Trakt...")
    all_items = []
    try:
        all_items = _collect_all_trakt_items(key, pDialog)
    except Exception as e:
        pDialog.close()
        xbmc.log("[EspaDaily-TM] collect error: {0}".format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "No se pudo recopilar los elementos", xbmcgui.NOTIFICATION_ERROR)
        return

    if pDialog.iscanceled():
        pDialog.close()
        return

    if not all_items:
        pDialog.close()
        xbmcgui.Dialog().ok("Trakt", "No se encontraron elementos en las listas.\n\nComprueba que las listas tienen contenido y que la API Key es valida.")
        return

    pDialog.update(0, "Descargando metadatos TMDB en español...")
    try:
        count = me.batch_fetch_with_progress(all_items, pDialog)
    finally:
        pDialog.close()

    try:
        items_path = _meta_items_path()
        os.makedirs(os.path.dirname(items_path), exist_ok=True)
        with open(items_path, 'w', encoding='utf-8') as fh:
            json.dump(all_items, fh, ensure_ascii=False)
        open(_meta_flag_path(), 'w').close()
    except Exception as e:
        xbmc.log("[EspaDaily-TM] meta flag save error: {0}".format(e), xbmc.LOGWARNING)

    xbmcgui.Dialog().notification(
        "EspaDaily",
        "Metadatos guardados: {0}/{1}".format(count, len(all_items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_all_meta():
    import metadata_enricher as me

    items_path = _meta_items_path()
    flag_path = _meta_flag_path()

    saved_items = []
    if os.path.exists(items_path):
        try:
            with open(items_path, 'r', encoding='utf-8') as fh:
                saved_items = json.load(fh)
        except Exception:
            pass

    deleted_count = 0
    if saved_items:
        me.delete_items(saved_items)
        deleted_count = len(saved_items)
    else:
        key = core_settings.get_trakt_api_key()
        if key:
            items = _collect_all_trakt_items(key)
            if items:
                me.delete_items(items)
                deleted_count = len(items)

    for path in (items_path, flag_path):
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass

    if deleted_count:
        xbmcgui.Dialog().notification(
            "EspaDaily",
            "Metadatos TMDB de Trakt eliminados ({0})".format(deleted_count),
            xbmcgui.NOTIFICATION_INFO,
        )
    else:
        xbmcgui.Dialog().notification(
            "EspaDaily",
            "No habia metadatos TMDB que borrar",
            xbmcgui.NOTIFICATION_INFO,
        )
    xbmc.executebuiltin("Container.Refresh")


def view_list(list_id, show_covers=False):
    try:
        key = core_settings.get_trakt_api_key()
        if not key:
            xbmcgui.Dialog().notification("Error", "Falta API Key", xbmcgui.NOTIFICATION_ERROR)
            return

        headers = {
            'Content-Type': 'application/json',
            'trakt-api-version': '2',
            'trakt-api-key': key
        }
        
        url = f'https://api.trakt.tv/lists/{list_id}/items?extended=full'
        
        try:
            r = requests.get(url, headers=headers, timeout=15)
            items = r.json()
        except Exception as e:
            xbmc.log("[EspaDaily-TM] view_list request: {0}".format(e), xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("Trakt", "No se pudo conectar con Trakt", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(_handle())
            return

        if not isinstance(items, list):
            msg = items.get('message', 'Error desconocido') if isinstance(items, dict) else "Respuesta no válida"
            xbmcgui.Dialog().ok("Error Trakt", f"No se pudieron cargar los elementos:\n{msg}")
            xbmcplugin.endOfDirectory(_handle())
            return

        import metadata_enricher as me

        addon = xbmcaddon.Addon()
        ai = addon.getAddonInfo('icon')
        af = core_settings.addon_fanart()

        cache = _load_thumb_cache(list_id)
        has_cache = len(cache) > 0


        if not has_cache:
            covers_label = "[COLOR cyan]Carátulas (temporales activas)[/COLOR]" if show_covers else "Carátulas"
            li = xbmcgui.ListItem(label=covers_label)
            li.setArt({'icon': 'DefaultAddonService.png'})
            li.setInfo('video', {'plot': "Opciones para mostrar o guardar las carátulas de esta lista."})
            xbmcplugin.addDirectoryItem(
                handle=_handle(),
                url=_u(action="trakt_covers_menu", list_id=list_id, show_covers="1" if show_covers else "0"),
                listitem=li, isFolder=False,
            )
        else:
            li = xbmcgui.ListItem(label="[COLOR red][B]Borrar carátulas guardadas (Volver a carga rápida)[/B][/COLOR]")
            li.setArt({'icon': 'DefaultIconError.png'})
            li.setInfo('video', {'plot': "Elimina las fotos guardadas para que la lista vuelva a cargar al instante."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_clear_cache", list_id=list_id), listitem=li, isFolder=False)

        for item in items:
            if not isinstance(item, dict): continue
            t = item.get('type')
            if t not in ('movie', 'show'): continue
            data = item.get(t)
            if not data: continue

            title = data.get('title')
            year = data.get('year')
            overview = data.get('overview', '')
            tagline = data.get('tagline', '')
            
            tmdb_id = data.get('ids', {}).get('tmdb')
            media_type = 'show' if t == 'show' else 'movie'
            item_key = f"{title}_{year}"
            label = f"{title} ({year})" if year else title
            li = xbmcgui.ListItem(label=label)

            meta = me.enrich(tmdb_id=tmdb_id, title=title, year=year, media_type=media_type, use_cache_only=True)
            if meta:
                me.apply_to_listitem(li, meta, addon_fanart=af)
                thumb = meta.get('poster') or ai
            else:
                thumb = ai
                if has_cache and item_key in cache:
                    thumb = cache[item_key]
                elif show_covers:
                    thumb = _get_tmdb_thumb(tmdb_id, ai)
                li.setArt({'icon': 'DefaultVideo.png', 'thumb': thumb, 'poster': thumb, 'fanart': af})
                video_info = {
                    'title': title,
                    'year': year,
                    'plot': f"[B]{tagline}[/B]\n\n{overview}" if tagline else overview,
                    'mediatype': 'movie' if t == 'movie' else 'tvshow'
                }
                li.setInfo('video', video_info)
            
            cm = []
            if core_settings.is_palantir_installed() and core_settings.is_palantir_integration_enabled():
                cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=title)})"))
            
            cm.append(("Buscar en webs de torrent", f"RunPlugin({_u(action='elementum_search', q=title)})"))
            

            params_json = json.dumps({'q': title})
            fav_url = _u(action='add_favorite', title=title, fav_url=title, icon=thumb, platform='Trakt', fav_action='lfr', params=params_json)
            cm.append(("Añadir a Mis Favoritos", f"RunPlugin({fav_url})"))
            
            li.addContextMenuItems(cm)
            li.setProperty('IsPlayable', 'false')
            play_mode = 'show' if media_type == 'show' else 'movie'
            play_url = _u(action='search_alt_prompt', q=title, ot=thumb, mode=play_mode)
            xbmcplugin.addDirectoryItem(handle=_handle(), url=play_url, listitem=li, isFolder=False)
            
        xbmcplugin.endOfDirectory(_handle())
    except Exception as e:
        xbmcgui.Dialog().ok("Error Trakt", f"Ocurrió un error al ver la lista:\n{str(e)}")
        try:
            xbmcplugin.endOfDirectory(_handle())
        except Exception:
            pass

def covers_menu(list_id, show_covers):
    if not list_id:
        return
    showing = show_covers == "1"
    temp_label = "Ocultar carátulas temporales" if showing else "Ver solo esta vez (sin guardar)"
    options = [
        "Descargar y guardar permanentemente",
        temp_label,
    ]
    idx = xbmcgui.Dialog().select("Carátulas", options)
    if idx == 0:
        cache_covers(list_id)
    elif idx == 1:
        new_show = "0" if showing else "1"
        xbmc.executebuiltin("Container.Update({0})".format(
            _u(action='trakt_view_list', list_id=list_id, show_covers=new_show)
        ))


def cache_covers(list_id):
    try:
        if not xbmcgui.Dialog().yesno("EspaDaily",
            "[B]AVISO DE CARGA:[/B]\n\n"
            "Al guardar las carátulas, el addon mostrará las fotos siempre que entres.\n\n"
            "Se descargarán en paralelo y se guardarán en la base de datos local.\n\n"
            "¿Quieres continuar con la descarga?"):
            return

        key = core_settings.get_trakt_api_key()
        headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': key}
        url = f'https://api.trakt.tv/lists/{list_id}/items?extended=full'

        try:
            r = requests.get(url, headers=headers, timeout=15)
            items = r.json()
        except Exception:
            xbmcgui.Dialog().notification("Error", "No se pudo conectar con Trakt", xbmcgui.NOTIFICATION_ERROR)
            return

        if not isinstance(items, list):
            msg = items.get('message', 'Error desconocido') if isinstance(items, dict) else "Respuesta no válida"
            xbmcgui.Dialog().ok("Error Trakt", f"No se pudo obtener la lista para cachear:\n{msg}")
            return

        import metadata_enricher as me

        enrich_targets = []
        for item in items:
            if not isinstance(item, dict): continue
            t = item.get('type')
            if t not in ('movie', 'show'): continue
            data = item.get(t)
            if not data: continue
            enrich_targets.append({
                'tmdb_id': data.get('ids', {}).get('tmdb'),
                'title': data.get('title'),
                'year': data.get('year'),
                'media_type': 'show' if t == 'show' else 'movie',
            })

        if not enrich_targets:
            xbmcgui.Dialog().notification("Trakt", "La lista está vacía", xbmcgui.NOTIFICATION_INFO)
            return

        pDialog = xbmcgui.DialogProgress()
        pDialog.create("EspaDaily", "Descargando carátulas y fanart...")
        was_cancelled = False
        try:
            me.batch_fetch_with_progress(enrich_targets, pDialog, max_workers=10)
            was_cancelled = pDialog.iscanceled()
        finally:
            pDialog.close()

        if was_cancelled:
            return

        cache = {}
        for target in enrich_targets:
            item_key = f"{target['title']}_{target['year']}"
            meta = me.enrich(tmdb_id=target['tmdb_id'], title=target['title'],
                             year=target['year'], media_type=target['media_type'],
                             use_cache_only=True)
            if meta and meta.get('poster'):
                cache[item_key] = meta.get('poster')

        if cache:
            path = _get_thumb_cache_path(list_id)
            tmp = path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(cache, f)
            os.replace(tmp, path)
            xbmcgui.Dialog().notification("EspaDaily", "Carátulas y fanart guardados correctamente", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        else:
            xbmcgui.Dialog().notification("EspaDaily", "No se encontraron carátulas", xbmcgui.NOTIFICATION_WARNING)
    except Exception as e:
        xbmcgui.Dialog().ok("Error Cache", f"Error al guardar carátulas:\n{str(e)}")

def clear_cache(list_id):
    try:
        path = _get_thumb_cache_path(list_id)
        if os.path.exists(path):
            os.remove(path)
            xbmcgui.Dialog().notification("EspaDaily", "Cache eliminada: Volvemos a carga rápida", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

def delete_list(list_id):
    try:
        if xbmcgui.Dialog().yesno("Eliminar Lista", "¿Seguro que quieres borrar esta lista de tu colección?"):
            core_settings.remove_trakt_list(list_id)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

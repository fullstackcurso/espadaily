# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
import threading
import requests

_lock = threading.Lock()
_session = None

_UA_MOBILE = 'Mozilla/5.0 (Linux; Android 7.1.1; Pixel Build/NMF26O) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.91 Mobile Safari/537.36'
_UA_DESKTOP = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'


def get() -> requests.Session:
    global _session
    if _session is None:
        with _lock:
            if _session is None:
                s = requests.Session()
                s.headers.update({'User-Agent': _UA_DESKTOP})
                adapter = requests.adapters.HTTPAdapter(
                    pool_connections=10,
                    pool_maxsize=20,
                    max_retries=1,
                )
                s.mount('http://', adapter)
                s.mount('https://', adapter)
                _session = s
    return _session


def fetch(url: str, headers: dict = None, stream: bool = False, timeout: int = 15, **kwargs):
    """Hace GET con los headers base más los específicos del token."""
    s = get()
    merged = {}
    if headers:
        merged.update(headers)
    return s.get(url, headers=merged, stream=stream, timeout=timeout, **kwargs)

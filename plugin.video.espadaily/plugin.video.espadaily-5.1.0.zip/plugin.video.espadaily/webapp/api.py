# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
# Endpoints JSON. Datos de catalogo via ce_espa; red via connector. La
# reproduccion en navegador usa Dailymotion (filosofia del addon) y los
# directos de Atresplayer (HLS). El resto del directo solo va en Kodi.
import concurrent.futures as cf
import json
import threading
import urllib.parse

from . import tokens
from . import a2espa as ap

_history_lock = threading.Lock()
_favs_lock = threading.Lock()
_HISTORY_FILE = "webapp_history.json"
_FAVS_FILE = "webapp_favorites.json"
_HISTORY_MAX = 100


# --- Util ---

def _json(handler, data, status=200, max_age=0):
    body = json.dumps(data, ensure_ascii=False).encode('utf-8')
    handler.send_response(status)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    handler.send_header('Content-Length', str(len(body)))
    handler.send_header('Cache-Control', f'private, max-age={max_age}' if max_age > 0 else 'no-store')
    handler.end_headers()
    handler.wfile.write(body)


def _proxy_thumb(url):
    if url and url.startswith('http'):
        return f'/thumb/{tokens.create_thumb(url)}'
    return url or ''


def _real_thumb(thumb):
    if not thumb:
        return ''
    if thumb.startswith('http'):
        return thumb
    if thumb.startswith('/thumb/'):
        return tokens.get_thumb(thumb[len('/thumb/'):].split('?')[0]) or ''
    return ''


def _item_id(*parts):
    return tokens.encode_url('|'.join(str(p) for p in parts))[:20]


def _read_body(handler):
    length = int(handler.headers.get('Content-Length', 0))
    return json.loads(handler.rfile.read(length)) if length else {}


def _history_read():
    try:
        import ui_utils
        data = ui_utils.load_json(_HISTORY_FILE, default=[])
        return data if isinstance(data, list) else []
    except Exception as e:
        import xbmc
        xbmc.log(f'[EspaWebApp] No se pudo leer el historial: {e}', xbmc.LOGWARNING)
        return []


def _history_write(data):
    try:
        import ui_utils
        ui_utils.save_json(_HISTORY_FILE, data[:_HISTORY_MAX])
    except Exception as e:
        import xbmc
        xbmc.log(f'[EspaWebApp] No se pudo guardar el historial: {e}', xbmc.LOGWARNING)


# --- Builders ---

def _folder(title, kind, params, thumb='', plot='', source=''):
    return {
        'id': _item_id(kind, params),
        'title': title, 'thumb': _proxy_thumb(thumb), 'type': 'folder',
        'plot': plot, 'duration': 0, 'source': source,
        'navigate': {'kind': kind, **params},
    }


def _live_item(ch):
    """Item de canal en directo. RTVE -> 'cast' (se reproduce en Kodi); resto -> navegador."""
    if ch.get('cast'):
        play = {'kind': 'cast', 'target': ch['cast_target'], 'id': ch['cast_id'], 'title': ch['name']}
        plot = 'Se reproduce en tu Kodi (TV).'
    else:
        play = {'kind': 'live', 'ch_id': ch['id'], 'title': ch['name']}
        plot = ''
    return _video(title=ch['name'], play=play, thumb=ch.get('logo', ''),
                  source=ch['source'], is_live=True, plot=plot)


def _video(title, play, thumb='', plot='', duration=0, source='', **extras):
    item = {
        'id': _item_id(play.get('kind'), play.get('vid') or play.get('ch_id') or play.get('q')),
        'title': title, 'thumb': _proxy_thumb(thumb), 'type': 'video',
        'plot': plot, 'duration': duration, 'source': source, 'play': play,
    }
    item.update(extras)
    return item


# --- Dispatcher ---

def handle_api(handler, path, method):
    qs = ''
    if '?' in path:
        path, qs = path.split('?', 1)
    params = dict(urllib.parse.parse_qsl(qs))

    if path in ('/api/home', '/api/menu'):
        _home(handler, params)
    elif path == '/api/list':
        _list(handler, params)
    elif path == '/api/details':
        _details(handler, params)
    elif path == '/api/search':
        _search(handler, params)
    elif path == '/api/live/channels':
        _live_channels(handler)
    elif path == '/api/live/epg':
        _json(handler, {'channel': params.get('name', ''), 'programs': []})
    elif path == '/api/resolve' and method == 'POST':
        _resolve(handler)
    elif path == '/api/cast' and method == 'POST':
        _cast(handler)
    elif path == '/api/favorites':
        if method == 'GET':
            _favs_get(handler)
        elif method == 'POST':
            _favs_post(handler)
    elif path == '/api/history':
        _history(handler)
    elif path == '/api/history/progress' and method == 'POST':
        _progress(handler)
    else:
        _json(handler, {'error': 'Not found'}, 404)


# --- /api/home ---

def _history_items(limit=50):
    """Entradas del historial como items reproducibles, mas reciente primero."""
    items = []
    for e in _history_read()[:limit]:
        key = e.get('vid')
        if not key:
            continue
        title = ap.strip_bbcode(e.get('title', ''))
        # play original (kind/q/vid). Fallback para entradas antiguas sin play.
        play = dict(e.get('play') or {'kind': 'dm', 'vid': key})
        play.setdefault('title', title)
        items.append(_video(
            title=title,
            play=play,
            thumb=e.get('thumb', ''), duration=int(e.get('duration', 0) or 0),
            progress=int(e.get('progress', 0) or 0),
            source=e.get('source', ''),
        ))
    return items


def _home(handler, params):
    source = params.get('source', 'all')
    rows = []
    featured = []

    # En directo
    try:
        live_items = [_live_item(ch) for ch in ap.live_channels()]
        if live_items:
            rows.append({'id': 'live', 'title': 'En directo', 'items': live_items})
    except Exception:
        pass

    # Catalogo Mediaset/RTVE
    try:
        for sec in ap.home_rows(source):
            sec_items = []
            for it in sec['items']:
                sec_items.append(_folder(
                    title=it['title'], kind='details',
                    params={'url': it['href'], 'ctx': it['title']},
                    thumb=it['thumb'], plot=it.get('plot', ''), source=it['source'],
                ))
                if len(featured) < 6 and it.get('thumb'):
                    featured.append(_video(
                        title=it['title'],
                        play={'kind': 'dm_search', 'q': f"{sec['source']} {it['title']}", 'title': it['title']},
                        thumb=it['thumb'], plot=it.get('plot', ''), source=it['source'],
                    ))
            if sec_items:
                rows.append({'id': sec['id'], 'title': f"{sec['name']}", 'items': sec_items})
    except Exception:
        pass

    _json(handler, {'featured': featured, 'rows': rows}, max_age=120)


# --- /api/list ---

def _list(handler, params):
    kind = params.get('kind', 'catalog_root')
    source = params.get('source', 'all')
    try:
        if kind == 'catalog_root':
            cats = [(n, c, s) for n, c, s in ap.CATS if source in ('all', s)]
            # Thumb de portada por categoria (1er programa) en paralelo: 8 fetches
            # secuenciales serian lentos la 1a vez; ap.category_thumb cachea 30 min.
            with cf.ThreadPoolExecutor(max_workers=8) as ex:
                thumbs = dict(zip((c for _, c, _ in cats),
                                  ex.map(lambda c: ap.category_thumb(c),
                                         (c for _, c, _ in cats))))
            items = [_folder(title=n, kind='catalog_section',
                             params={'cat_id': c, 'page': 0}, source=s,
                             thumb=thumbs.get(c, ''))
                     for n, c, s in cats]
            _json(handler, {'title': 'Catalogo', 'items': items}, max_age=1800)
        elif kind == 'catalog_section':
            cat_id = params.get('cat_id', '')
            page = int(params.get('page', 0))
            rows = ap.category_items(cat_id, page=page)
            items = []
            for it in rows:
                if not it.get('href'):
                    continue
                items.append(_folder(title=it['title'], kind='details',
                                     params={'url': it['href'], 'ctx': it['title']},
                                     thumb=it['thumb'], plot=it.get('plot', ''), source=it['source']))
            if len(rows) >= 40:
                items.append(_folder(title='Pagina siguiente >', kind='catalog_section',
                                     params={'cat_id': cat_id, 'page': page + 1}))
            name = next((n for n, c, _s in ap.CATS if c == cat_id), 'Seccion')
            _json(handler, {'title': name, 'items': items}, max_age=1800)
        else:
            _json(handler, {'title': '', 'items': []})
    except Exception as e:
        _json(handler, {'error': str(e)}, 500)


# --- /api/details ---

def _details(handler, params):
    url = params.get('url', '')
    ctx = params.get('ctx', '')
    if not url:
        _json(handler, {'title': '', 'items': []})
        return
    # Fuente segun el prefijo del href interno: el front la usa para el mensaje
    # cuando un programa no devuelve episodios (Mediaset no siempre es listable).
    src_of_url = 'mediaset' if url.startswith('espa://ms/') else (
        'rtve' if url.startswith('espa://rtve/') else '')
    try:
        eps = ap.episodes(url)
        items = []
        for ep in eps:
            if not ep.get('vid'):
                continue
            src = ep.get('source', '')
            prefix = 'RTVE' if src == 'rtve' else ('Mediaset' if src == 'mediaset' else '')
            q = f"{prefix} {ctx} {ep['title']}".strip()
            items.append(_video(
                title=ep['title'],
                play={'kind': 'dm_search', 'q': q, 'title': ep['title']},
                thumb=ep.get('thumb', ''), plot=ep.get('plot', ''), source=src,
            ))
        # Si vino vacio no cachear: puede ser un fallo transitorio y conviene reintentar.
        _json(handler, {'title': ctx or 'Episodios', 'items': items, 'source': src_of_url},
              max_age=600 if items else 0)
    except Exception as e:
        _json(handler, {'error': str(e)}, 500)


# --- /api/search ---

def _search(handler, params):
    q = params.get('q', '').strip()
    if not q:
        _json(handler, {'title': 'Busqueda', 'items': []})
        return
    try:
        videos = ap.search_dm(q)
        scored = ap.score_dm(q, videos)
        items = []
        for score, v in scored:
            n = ap.normalize_dm(v, score=score)
            if not n['vid']:
                continue
            items.append(_video(title=n['title'],
                                play={'kind': 'dm', 'vid': n['vid'], 'title': n['title']},
                                thumb=n['thumb'], plot=n['plot'], duration=n['duration']))
        try:
            import exploration_history
            exploration_history.add_exploration(q)
        except Exception:
            pass
        _json(handler, {'title': f'Resultados: {q}', 'items': items}, max_age=300)
    except Exception as e:
        _json(handler, {'error': str(e)}, 500)


# --- /api/live/channels ---

def _live_channels(handler):
    try:
        items = [_live_item(ch) for ch in ap.live_channels()]
        _json(handler, {'title': 'Directos', 'items': items}, max_age=60)
    except Exception as e:
        _json(handler, {'error': str(e)}, 500)


# --- /api/resolve ---

def _resolve(handler):
    try:
        body = _read_body(handler)
    except Exception:
        _json(handler, {'error': 'Bad request'}, 400)
        return
    kind = body.get('kind', '')
    title = ap.strip_bbcode(body.get('title', ''))
    thumb = _real_thumb(body.get('thumb', ''))

    if kind == 'dm':
        _resolve_dm(handler, body.get('vid', ''), title, thumb)
    elif kind == 'dm_search':
        _resolve_dm_search(handler, body.get('q', ''), title, thumb)
    elif kind == 'live':
        _resolve_live(handler, body.get('ch_id', ''), title)
    else:
        _json(handler, {'error': f'Tipo desconocido: {kind}'}, 400)


def _emit_stream(handler, res, kind, vid, title, thumb):
    """Crea token y respuesta a partir de un dict de a2espa.resolve_dm."""
    real_url = res['url']
    headers = res.get('headers') or {}
    is_mp4 = 'mp4' in (res.get('mime') or '') or (real_url.split('?')[0].lower().endswith('.mp4'))
    token = tokens.create(real_url, headers, kind, real_url, {'vid': vid, 'title': title})

    subs = []
    for s in (res.get('subs') or []):
        su = s if isinstance(s, str) else (s.get('url') if isinstance(s, dict) else '')
        if not su:
            continue
        lang = s.get('lang', 'es') if isinstance(s, dict) else 'es'
        enc = urllib.parse.quote(tokens.encode_url(su))
        subs.append({'lang': lang, 'url': f'/proxy/{token}/sub?u={enc}'})

    if is_mp4:
        enc = urllib.parse.quote(tokens.encode_url(real_url))
        playlist = f'/proxy/{token}/seg?u={enc}'
        _json(handler, {'token': token, 'playlist': playlist, 'direct': True,
                        'mime': 'video/mp4', 'subtitles': subs, 'title': title, 'kind': kind})
    else:
        _json(handler, {'token': token, 'playlist': f'/proxy/{token}/master.m3u8',
                        'subtitles': subs, 'title': title, 'kind': kind})


def _resolve_dm(handler, vid, title, thumb=''):
    if not vid:
        _json(handler, {'error': 'vid requerido'}, 400)
        return
    res = ap.resolve_dm(vid)
    if not res:
        _json(handler, {'error': 'No se pudo resolver el video'}, 502)
        return
    _emit_stream(handler, res, 'dm', vid, title, thumb)


def _resolve_dm_search(handler, q, title, thumb=''):
    if not q:
        _json(handler, {'error': 'q requerido'}, 400)
        return
    videos = ap.search_dm(q)
    scored = ap.score_dm(q, videos)
    if not scored:
        _json(handler, {'error': 'Sin resultados para reproducir. Prueba la busqueda.'}, 502)
        return
    vid = scored[0][1].get('id', '')
    res = ap.resolve_dm(vid) if vid else None
    if not res:
        _json(handler, {'error': 'No se pudo resolver el video'}, 502)
        return
    _emit_stream(handler, res, 'dm', vid, title or scored[0][1].get('title', ''), thumb)


def _cast(handler):
    """Lanza la reproduccion en la propia instancia de Kodi (para canales con
    DRM como RTVE, que el navegador no puede reproducir)."""
    try:
        body = _read_body(handler)
    except Exception:
        _json(handler, {'error': 'Bad request'}, 400)
        return
    import re as _re
    target = body.get('target', '')
    cid = str(body.get('id', ''))
    # Solo destinos conocidos e id saneado: nada de acciones arbitrarias.
    try:
        import xbmc
        if target == 'live_rtve' and _re.fullmatch(r'[A-Za-z0-9_-]{1,32}', cid):
            url = 'plugin://plugin.video.espadaily/?action=play_live_rtve&video_id=' + urllib.parse.quote(cid)
            xbmc.executebuiltin('PlayMedia(%s)' % url)
            _json(handler, {'status': 'ok'})
        elif target == 'live_ms' and _re.fullmatch(r'[a-z0-9]{1,30}', cid):
            ms_url = ap.ms_channel_url(cid)
            if not ms_url:
                _json(handler, {'error': 'Canal desconocido'}, 400)
                return
            url = ('plugin://plugin.video.espadaily/?action=play_live_mediaset&url='
                   + urllib.parse.quote(ms_url))
            xbmc.executebuiltin('RunPlugin(%s)' % url)
            _json(handler, {'status': 'ok'})
        else:
            _json(handler, {'error': 'Destino no permitido'}, 400)
    except Exception as e:
        _json(handler, {'error': str(e)}, 500)


def _resolve_live(handler, ch_id, title):
    real = ch_id.split(':', 1)[1] if ':' in ch_id else ch_id

    if ch_id.startswith('live_atres:'):
        url, headers = ap.resolve_atres_live(real)
        if not url:
            _json(handler, {'error': 'Emision no disponible (prueba sin VPN).'}, 502)
            return
        token = tokens.create(url, headers, 'live', url, {'ch_id': ch_id, 'title': title})
        _json(handler, {'token': token, 'playlist': f'/proxy/{token}/master.m3u8',
                        'subtitles': [], 'title': title, 'kind': 'live'})
        return

    if ch_id.startswith('live_ms:'):
        url = ap.resolve_ms_live(real)
        if not url:
            _json(handler, {'error': 'Necesita el addon StreamNinja instalado en Kodi.'}, 502)
            return
        real_url, headers = _parse_kodi_pipe(url)
        if not headers:
            headers = dict(ap._DM_HEADERS)
        token = tokens.create(real_url, headers, 'live', real_url, {'ch_id': ch_id, 'title': title})
        _json(handler, {'token': token, 'playlist': f'/proxy/{token}/master.m3u8',
                        'subtitles': [], 'title': title, 'kind': 'live'})
        return

    if ch_id.startswith('live_rtve:'):
        d = ap.resolve_rtve_live(real)
        if not d or not d.get('url'):
            _json(handler, {'error': 'Emision no disponible.'}, 502)
            return
        if d.get('license_url'):
            _json(handler, {'error': 'Canal con DRM: solo se reproduce en la app de Kodi.'}, 502)
            return
        mpd = d['url']
        base = mpd.rsplit('/', 1)[0] + '/'
        token = tokens.create(mpd, dict(ap._DM_HEADERS), 'dash', base, {'ch_id': ch_id, 'title': title})
        _json(handler, {'token': token, 'playlist': f'/proxy/{token}/manifest.mpd',
                        'subtitles': [], 'title': title, 'kind': 'live', 'type': 'dash'})
        return

    _json(handler, {'error': 'Canal no reproducible en el navegador.'}, 502)


def _parse_kodi_pipe(pipe_url):
    if not pipe_url or '|' not in pipe_url:
        return pipe_url, {}
    real, qs = pipe_url.split('|', 1)
    return real.strip(), dict(urllib.parse.parse_qsl(qs))


# --- Historial (propio, en JSON; core_settings de EspaDaily no lo tiene).
# Lo escribe SOLO el front via /api/history/progress: conoce el play original
# (kind, source) y usa un id estable por contenido, no el id de DM resuelto. ---

def _history(handler):
    # Items reproducibles para la vista "Seguir viendo"; sin cache (siempre fresco).
    _json(handler, {'title': 'Seguir viendo', 'items': _history_items()})


def _progress(handler):
    try:
        body = _read_body(handler)
        key = body.get('id', '')
        if not key:
            _json(handler, {'status': 'noop'})
            return
        pos = max(0, int(float(body.get('position', 0) or 0)))
        dur = max(0, int(float(body.get('duration', 0) or 0)))
        title = ap.strip_bbcode(body.get('title', ''))
        thumb = _real_thumb(body.get('thumb', ''))
        play = body.get('play') or {}
        source = body.get('source', '') or play.get('source', '')
        import time as _t
        now = int(_t.time())
        with _history_lock:
            hist = _history_read()
            entry = next((e for e in hist if e.get('vid') == key), None)
            if entry is None:
                entry = {'vid': key}
            else:
                hist.remove(entry)
            # Lo ultimo reproducido va primero: "Continuar viendo" muestra hist[:15].
            hist.insert(0, entry)
            # pos=0 es el ping de apertura (_registerPlay): solo crea/sube la entrada,
            # nunca pisa un avance ya guardado. Un pos>0 real siempre actualiza.
            if pos > 0 or 'progress' not in entry:
                entry['progress'] = pos
            entry['ts'] = now
            if dur:
                entry['duration'] = dur
            if title:
                entry['title'] = title
            if thumb:
                entry['thumb'] = thumb
            if play:
                entry['play'] = play
            if source:
                entry['source'] = source
            _history_write(hist)
        _json(handler, {'status': 'ok'})
    except Exception as e:
        _json(handler, {'status': 'error', 'error': str(e)})


# --- Favoritos (fichero propio de la webapp) ---
# No se usa core_settings.favorites a proposito: esas entradas tienen un
# 'action' del addon que la webapp no genera, y mezclar entradas con href
# espa:// rompe el menu de favoritos de Kodi. La webapp es su propia superficie.

def _favs_read():
    try:
        import ui_utils
        data = ui_utils.load_json(_FAVS_FILE, default=[])
        return data if isinstance(data, list) else []
    except Exception as e:
        import xbmc
        xbmc.log(f'[EspaWebApp] No se pudo leer favoritos: {e}', xbmc.LOGWARNING)
        return []


def _favs_write(data):
    try:
        import ui_utils
        ui_utils.save_json(_FAVS_FILE, data)
    except Exception as e:
        import xbmc
        xbmc.log(f'[EspaWebApp] No se pudo guardar favoritos: {e}', xbmc.LOGWARNING)


def _favs_get(handler):
    favs = _favs_read()
    result = [{'title': f.get('title', ''), 'url': f.get('url', ''),
               'thumb': _proxy_thumb(f.get('thumb', ''))} for f in favs]
    _json(handler, {'favorites': result})


def _favs_post(handler):
    try:
        body = _read_body(handler)
        op = body.get('op', 'toggle')
        url = body.get('url', '')
        title = body.get('title', '')
        thumb = body.get('thumb', '')
        if not url:
            _json(handler, {'error': 'url requerido'}, 400)
            return
        if thumb.startswith('/thumb/'):
            thumb = _real_thumb(thumb)
        with _favs_lock:
            favs = _favs_read()
            exists = any(f.get('url') == url for f in favs)
            if op == 'remove' or (op == 'toggle' and exists):
                favs = [f for f in favs if f.get('url') != url]
                _favs_write(favs)
                _json(handler, {'status': 'removed'})
            else:
                if not exists:
                    favs.insert(0, {'title': title, 'url': url, 'thumb': thumb})
                    _favs_write(favs)
                _json(handler, {'status': 'added'})
    except Exception as e:
        _json(handler, {'error': str(e)}, 500)

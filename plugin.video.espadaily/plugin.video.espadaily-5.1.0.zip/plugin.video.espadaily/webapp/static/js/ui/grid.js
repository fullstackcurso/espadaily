import { Icons } from '../icons.js';
import { API } from '../api.js';

export function makeCard(item, onPlay, onNavigate, favSet, size = 'landscape') {
  const card = document.createElement('div');
  card.className = `card card-${size}`;
  card.dataset.type = item.type;

  // URL de favorito: para folders usamos navigate.url; para vídeos no aplican favoritos
  const favUrl = item.navigate?.url || '';
  if (favUrl) card.dataset.navUrl = favUrl;

  const isFolder = item.type === 'folder';
  const isLive = !!item.is_live;
  const isFav = favSet && favUrl && favSet.has(favUrl);

  // ── Imagen ──
  const imgWrap = document.createElement('div');
  // Los directos llevan logo de canal (PNG transparente): contener, no recortar.
  imgWrap.className = isLive ? 'card-img card-img-logo' : 'card-img';

  if (item.thumb) {
    const img = document.createElement('img');
    img.className = 'loading';
    img.alt = item.title;
    img.loading = 'lazy';
    img.decoding = 'async';
    img.onload = () => { img.classList.remove('loading'); img.classList.add('loaded'); };
    img.onerror = () => { img.replaceWith(makePlaceholder(isFolder, isLive)); };
    img.src = item.thumb;
    imgWrap.appendChild(img);
  } else {
    imgWrap.appendChild(makePlaceholder(isFolder, isLive));
  }

  // Progreso (Continuar viendo)
  if (item.progress > 0 && item.duration > 0) {
    const pct = Math.min(100, (item.progress / item.duration) * 100);
    imgWrap.insertAdjacentHTML('beforeend', `
      <div class="card-progress"><div class="card-progress-bar" style="width:${pct}%"></div></div>
    `);
  }

  // Badge EN DIRECTO
  if (isLive) {
    imgWrap.insertAdjacentHTML('beforeend',
      `<div class="card-live-badge"><span class="card-live-dot"></span>EN DIRECTO</div>`);
  }

  // Badge de fuente (RTVE / Mediaset / Atresplayer)
  const srcLabels = { rtve: 'RTVE', mediaset: 'Mediaset', atres: 'Atresplayer' };
  if (item.source && srcLabels[item.source]) {
    imgWrap.insertAdjacentHTML('beforeend',
      `<div class="card-source-badge src-${item.source}">${srcLabels[item.source]}</div>`);
  } else if (item.play?.kind === 'dm') {
    imgWrap.insertAdjacentHTML('beforeend',
      `<div class="card-source-badge dm">DM</div>`);
  }

  // Overlay
  const overlay = document.createElement('div');
  overlay.className = 'card-overlay';
  overlay.innerHTML = `
    <div class="card-overlay-title">${escHtml(item.title)}</div>
    ${item.plot ? `<div class="card-overlay-meta">${escHtml(item.plot)}</div>` : ''}
    <div class="card-overlay-actions">
      ${!isFolder ? `<button class="card-action-btn play-btn" title="Reproducir">${Icons.play}</button>` : ''}
      ${isFolder ? `<button class="card-action-btn open-btn" title="Abrir">${Icons.arrowRight}</button>` : ''}
      ${favUrl ? `<button class="card-action-btn fav-btn${isFav ? ' active' : ''}" title="${isFav ? 'Quitar de favoritos' : 'Añadir a favoritos'}">${isFav ? Icons.heartFilled : Icons.heart}</button>` : ''}
    </div>
  `;
  imgWrap.appendChild(overlay);
  card.appendChild(imgWrap);

  // Info bajo la card
  const info = document.createElement('div');
  info.className = 'card-info';
  info.innerHTML = `<div class="card-info-title">${escHtml(item.title)}</div>`;
  if (item.duration > 0) {
    info.insertAdjacentHTML('beforeend', `<div class="card-info-sub">${formatDur(item.duration)}</div>`);
  }
  card.appendChild(info);

  // ── Eventos ──
  card.addEventListener('click', (e) => {
    if (e.target.closest('.card-action-btn')) return;
    if (isFolder) onNavigate(item);
    else onPlay(item);
  });

  overlay.querySelector('.play-btn')?.addEventListener('click', (e) => {
    e.stopPropagation();
    onPlay(item);
  });

  overlay.querySelector('.open-btn')?.addEventListener('click', (e) => {
    e.stopPropagation();
    onNavigate(item);
  });

  const favBtn = overlay.querySelector('.fav-btn');
  if (favBtn) {
    favBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      try {
        const r = await API.toggleFavorite(favUrl, item.title, item.thumb);
        const nowFav = r.status === 'added';
        favBtn.classList.toggle('active', nowFav);
        favBtn.innerHTML = nowFav ? Icons.heartFilled : Icons.heart;
        favBtn.title = nowFav ? 'Quitar de favoritos' : 'Añadir a favoritos';
        if (favSet) {
          if (nowFav) favSet.add(favUrl);
          else favSet.delete(favUrl);
        }
      } catch {}
    });
  }

  return card;
}

function makePlaceholder(isFolder, isLive) {
  const ph = document.createElement('div');
  ph.className = 'card-img-placeholder';
  ph.innerHTML = isLive ? Icons.live : isFolder ? Icons.folder : Icons.video;
  return ph;
}

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function formatDur(s) {
  if (!s) return '';
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h) return `${h}h ${m}m`;
  if (m) return `${m}m ${sec}s`;
  return `${sec}s`;
}

export function makeSkeleton(count = 6) {
  return Array.from({ length: count }, () => {
    const c = document.createElement('div');
    c.className = 'card card-landscape card-skeleton';
    c.innerHTML = `
      <div class="card-img skeleton-box"></div>
      <div class="card-info">
        <div class="skeleton-box" style="height:12px;width:70%;border-radius:4px;margin-bottom:6px"></div>
        <div class="skeleton-box" style="height:10px;width:40%;border-radius:4px"></div>
      </div>`;
    return c;
  });
}

export { formatDur, escHtml };

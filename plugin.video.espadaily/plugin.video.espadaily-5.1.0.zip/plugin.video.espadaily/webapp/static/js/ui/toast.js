const container = document.getElementById('toast-container');

export function toast(msg, type = 'info', duration = 4000) {
  const el = document.createElement('div');
  el.className = `toast ${type}`;

  const icon = type === 'error' ? '✕' : type === 'success' ? '✓' : 'ℹ';
  el.innerHTML = `<span style="opacity:0.7">${icon}</span><span>${msg}</span>`;
  container.appendChild(el);

  const remove = () => {
    el.classList.add('leaving');
    el.addEventListener('animationend', () => el.remove(), { once: true });
  };

  const timer = setTimeout(remove, duration);
  el.addEventListener('click', () => { clearTimeout(timer); remove(); });
}

import { API } from '../api.js';
import { Icons } from '../icons.js';
import { makeCard, makeSkeleton } from './grid.js';
import { toast } from './toast.js';

// Vista "Seguir viendo": recarga el historial fresco cada vez que se abre.
export async function renderContinue(container, { onPlay, onNavigate, favSet }) {
  const wrap = document.createElement('div');
  wrap.className = 'grid-view page-enter';
  wrap.innerHTML = `
    <div class="grid-header">
      <button class="grid-back" title="Volver">${Icons.arrowLeft}</button>
      <h2 class="grid-title">Seguir viendo</h2>
    </div>
  `;
  wrap.querySelector('.grid-back').addEventListener('click', () => {
    if (history.length > 1) history.back();
    else location.href = '/';
  });

  const grid = document.createElement('div');
  grid.className = 'grid';
  makeSkeleton(8).forEach(c => grid.appendChild(c));
  wrap.appendChild(grid);
  container.appendChild(wrap);

  let data;
  try {
    data = await API.getHistory();
  } catch (e) {
    grid.innerHTML = `<div class="empty-state">Error: ${e.message}</div>`;
    toast(`Error cargando el historial: ${e.message}`, 'error');
    return;
  }

  grid.innerHTML = '';
  if (!data.items?.length) {
    grid.innerHTML = `<div class="empty-state">Aún no has empezado nada.<br>Lo que reproduzcas aparecerá aquí para seguir donde lo dejaste.</div>`;
    return;
  }
  for (const item of data.items) {
    grid.appendChild(makeCard(item, onPlay, onNavigate, favSet, 'landscape'));
  }
}

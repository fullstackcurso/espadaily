# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
# Adaptador de datos de la WebApp. Capa pura: catalogo via ce_espa, red via
# connector. Sin URLs de APIs ni HTTP propio (salvo el proxy de streams, que
# solo relaya URLs ya resueltas por connector).
import difflib
import re
import threading
import time

import ce_espa as ce
import connector

_BBCODE_RE = re.compile(r'\[/?[A-Za-z][A-Za-z0-9=/ #]*\]')

_DM_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
}

CATS = ce.CATS


def strip_bbcode(s):
    if not s:
        return s
    return _BBCODE_RE.sub('', s).strip()


def home_rows(source=None):
    """Filas del catalogo (Mediaset/RTVE) para /api/home, filtradas por fuente."""
    rows = []
    for name, cid, src in ce.CATS:
        if source and source != "all" and source != src:
            continue
        try:
            items = ce.fetch_cat_rows(cid, page=0)[:18]
        except Exception:
            items = []
        if items:
            rows.append({"id": cid, "name": name, "source": src, "items": items})
    return rows


def category_items(cat_id, page=0):
    return ce.fetch_cat_rows(cat_id, page=page)


# Thumb de portada de cada categoria (el del primer programa). Cacheado para que
# abrir el catalogo no dispare 8 fetches cada vez. TTL alto: las portadas cambian
# poco y un thumb obsoleto no es grave.
_CAT_THUMB_TTL = 1800
_cat_thumb_cache = {}  # cid -> (thumb, expires_at)
_cat_thumb_lock = threading.Lock()


def category_thumb(cat_id):
    """Thumb del primer programa de la categoria, o '' si no hay. Cacheado."""
    now = time.time()
    with _cat_thumb_lock:
        hit = _cat_thumb_cache.get(cat_id)
        if hit and hit[1] > now:
            return hit[0]
    try:
        thumb = next((it["thumb"] for it in ce.fetch_cat_rows(cat_id, page=0)
                      if it.get("thumb")), "")
    except Exception:
        thumb = ""
    # Si no hubo thumb (red caida, lista vacia) cachear poco para reintentar pronto.
    ttl = _CAT_THUMB_TTL if thumb else 60
    with _cat_thumb_lock:
        _cat_thumb_cache[cat_id] = (thumb, now + ttl)
    return thumb


def episodes(href):
    return ce.fetch_episodes(href)


def live_channels():
    """Todos los canales en directo. RTVE usa DRM Widevine y EME requiere HTTPS
    (no disponible en LAN), asi que no se reproduce en el navegador: se marca
    'cast' para lanzarlo en Kodi. Mediaset (StreamNinja) y Atresplayer (HLS) si
    se reproducen en el navegador."""
    out = []
    # Atresplayer primero (HLS sin DRM, se reproduce en navegador).
    # RTVE y Mediaset usan DRM Widevine -> se lanzan en Kodi (cast).
    try:
        for c in connector.get_live_channels():
            out.append({"id": f"live_atres:{c['id']}", "name": c["name"],
                        "logo": connector.fix_img(connector._ATRES_CH_LOGOS.get(c["id"], "")),
                        "source": "atres"})
    except Exception:
        pass
    for c in connector._RTVE_LIVE_CHANNELS:
        out.append({"id": f"live_rtve:{c['video_id']}", "name": c["name"],
                    "logo": connector.fix_img(c.get("logo", "")),
                    "source": "rtve", "cast": True,
                    "cast_target": "live_rtve", "cast_id": c["video_id"]})
    for c in connector._MEDIASET_LIVE_CHANNELS:
        out.append({"id": f"live_ms:{c['id']}", "name": c["name"],
                    "logo": connector.fix_img(connector._MEDIASET_CH_LOGOS.get(c["id"], "")),
                    "source": "mediaset", "cast": True,
                    "cast_target": "live_ms", "cast_id": c["id"]})
    return out


def ms_channel_url(ch_id):
    """URL del directo de Mitele para un id de canal Mediaset."""
    return next((c["url"] for c in connector._MEDIASET_LIVE_CHANNELS if c["id"] == ch_id), None)


def resolve_atres_live(ch_id):
    """Atresplayer en directo -> (url HLS, headers) o (None, None)."""
    url = connector.resolve_live_channel(ch_id)
    if url:
        return url, dict(_DM_HEADERS)
    return None, None


def resolve_rtve_live(video_id):
    """RTVE en directo -> {'url': .mpd, 'license_url'} o None."""
    try:
        d = connector.resolve_rtve_live(video_id)
        if d and d.get("url"):
            return d
    except Exception:
        pass
    return None


def resolve_ms_live(ch_id):
    """Mediaset en directo (via StreamNinja) -> url HLS o None."""
    url = next((c["url"] for c in connector._MEDIASET_LIVE_CHANNELS if c["id"] == ch_id), None)
    if not url:
        return None
    try:
        return connector.resolve_mediaset_live(url)
    except Exception:
        return None


# Dailymotion: reproduccion en navegador del catalogo y la busqueda.

def search_dm(q, limit=50):
    try:
        return connector.search_dailymotion(q, {"limit": limit})
    except Exception:
        return []


def normalize_dm(v, score=None):
    du = int(v.get("duration", 0) or 0)
    mins, secs = divmod(du, 60)
    owner = v.get("owner.username", "Dailymotion")
    title = v.get("title", "Video")
    if score is not None:
        title = f"{title}  ·  {int(score * 100)}%"
    return {
        "title": title,
        "vid": v.get("id", ""),
        "thumb": v.get("thumbnail_720_url") or v.get("thumbnail_360_url") or "",
        "plot": f"Canal: {owner}\nDuracion: {mins}m {secs}s",
        "duration": du,
    }


def score_dm(q, videos):
    if not videos:
        return []
    try:
        prioritize = connector.core_settings.is_prioritize_match_active() if getattr(connector, "core_settings", None) else False
    except Exception:
        prioritize = False
    scored = []
    ql = q.lower().strip()
    qn = re.findall(r'(\d+)', ql)
    q_words = [w for w in ql.replace('-', ' ').replace('.', ' ').split() if len(w) > 2]
    for v in videos:
        t = (v.get("title") or "").strip()
        if not t:
            continue
        tl = t.lower()
        s = difflib.SequenceMatcher(None, ql, tl).ratio()
        if q_words:
            if q_words[0] not in tl:
                s -= 0.6
            found = sum(1 for w in q_words if w in tl)
            if found < len(q_words):
                s -= 0.1 * (len(q_words) - found)
        if ql in tl:
            s += 0.5
        tn = re.findall(r'(\d+)', tl)
        if qn and tn:
            try:
                if set(int(x) for x in qn).issubset(set(int(x) for x in tn)):
                    s += 2.0
                else:
                    s -= 0.5
            except Exception:
                pass
        du = int(v.get("duration", 0) or 0)
        if s > 0.4:
            if not prioritize:
                if du > 600:
                    s += 0.3
                elif du > 300:
                    s += 0.1
            if du < 60:
                s -= 0.2
        scored.append((s, v))
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[:25]


def resolve_dm(vid):
    """Resuelve un vid de Dailymotion. Devuelve dict con url, mime, subs, headers, o None."""
    try:
        import dm_resolver
        res = dm_resolver.resolve(vid)
        if res and res.get("url"):
            return {"url": res["url"], "mime": res.get("mime", ""),
                    "subs": res.get("subs") or [], "headers": dict(res.get("headers") or _DM_HEADERS)}
    except Exception:
        pass
    try:
        import dm_gujal
        final_url, subs, mime = dm_gujal.play_dm_extreme(vid, force_hls=True)
        if final_url:
            url, headers = _parse_pipe(final_url)
            return {"url": url, "mime": mime or "application/x-mpegURL",
                    "subs": subs or [], "headers": headers or dict(_DM_HEADERS)}
    except Exception:
        pass
    return None


def _parse_pipe(pipe_url):
    if not pipe_url or '|' not in pipe_url:
        return pipe_url, {}
    import urllib.parse
    real, qs = pipe_url.split('|', 1)
    return real.strip(), dict(urllib.parse.parse_qsl(qs))

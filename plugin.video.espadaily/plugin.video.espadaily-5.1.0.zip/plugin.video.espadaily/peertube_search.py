# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
#
# Búsqueda en PeerTube (red federada) sin API key, vía la instancia peertube.tv,
# cuyo índice de búsqueda devuelve vídeos de muchas instancias federadas:
#   1) /search/videos devuelve metadatos (sin URLs de stream).
#   2) Al reproducir, /videos/{uuid} entrega los ficheros: MP4 progresivo si existe
#      (más compatible) o, en su defecto, el playlist HLS (PeerTube v6+ solo genera HLS).
import hashlib
import json
import os
import sys
import time
import urllib.parse
import urllib.request
import urllib.error

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_API_SEARCH = "https://peertube.tv/api/v1/search/videos"
_API_VIDEO  = "https://peertube.tv/api/v1/videos/{uuid}"
_BASE_URL   = "https://peertube.tv"

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
}

_CACHE_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.espadaily/search_cache/")
_CACHE_TTL = 3600  # segundos


def _cache_get(key):
    path = os.path.join(_CACHE_DIR, key + ".json")
    try:
        if time.time() - os.path.getmtime(path) > _CACHE_TTL:
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        return None


def _cache_set(key, data):
    # tmp único por proceso; dos búsquedas simultáneas de la misma query no se pisan
    # el temporal (cada invocación del plugin es un proceso distinto). os.replace es atómico.
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        tmp = os.path.join(_CACHE_DIR, f"{key}.{os.getpid()}.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, os.path.join(_CACHE_DIR, key + ".json"))
    except OSError:
        pass


def _get_json(url, timeout=15):
    req = urllib.request.Request(url, headers=_HEADERS)
    resp = urllib.request.urlopen(req, timeout=timeout)
    return json.loads(resp.read().decode("utf-8", errors="replace"))


def _fmt_duration(secs):
    if not isinstance(secs, int) or secs <= 0:
        return ""
    h, rem = divmod(secs, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _thumb(v):
    """thumbnails[].fileUrl trae URL absoluta (la más fiable); si no, thumbnailPath es relativo."""
    for t in v.get("thumbnails") or []:
        if isinstance(t, dict) and t.get("fileUrl"):
            return t["fileUrl"]
    path = v.get("thumbnailPath")
    return _BASE_URL + path if path else ""


def _parse_video(v):
    if not isinstance(v, dict):
        return None
    uuid = v.get("uuid")
    name = v.get("name")
    if not uuid or not name:
        return None
    if v.get("isLive"):
        return None  # los directos no se sirven como VOD por /videos/{uuid}/files
    chan = v.get("channel") or {}
    acc = v.get("account") or {}
    return {
        "uuid":        uuid,
        "title":       name,
        "channel":     chan.get("displayName", ""),
        "host":        acc.get("host", ""),
        "thumb":       _thumb(v),
        "duration":    v.get("duration") or 0,
        "description": v.get("truncatedDescription") or v.get("description") or "",
    }


def search(query, count=30):
    query = (query or "").strip()
    if not query:
        return []
    key = "peertube_" + hashlib.md5(query.lower().encode()).hexdigest()[:16]
    cached = _cache_get(key)
    if cached is not None:
        return cached
    params = urllib.parse.urlencode(
        {"search": query, "count": count, "sort": "-match", "nsfw": "false"})
    data = _get_json(f"{_API_SEARCH}?{params}")
    items = data.get("data") if isinstance(data, dict) else None
    results = [p for p in (_parse_video(v) for v in (items or [])) if p]
    _cache_set(key, results)
    return results


def resolve_stream(uuid):
    """Devuelve (url, kind) donde kind es 'mp4' (progresivo directo) o 'hls'.
    Prefiere MP4 por máxima compatibilidad; cae a HLS solo si no hay ficheros progresivos."""
    if not uuid:
        return "", ""
    data = _get_json(_API_VIDEO.format(uuid=urllib.parse.quote(uuid)))

    files = [f for f in (data.get("files") or [])
             if isinstance(f, dict) and f.get("fileUrl")]
    if files:
        best = max(files, key=lambda f: (f.get("resolution") or {}).get("id", 0))
        return best["fileUrl"], "mp4"

    for sp in data.get("streamingPlaylists") or []:
        if isinstance(sp, dict) and sp.get("playlistUrl"):
            return _best_hls_url(sp["playlistUrl"]), "hls"
    return "", ""


def _probe(url, timeout=8):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": _HEADERS["User-Agent"]})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status == 200
    except Exception:
        return False


def _best_hls_url(url):
    # Algunas instancias con object storage guardan el master bajo prefijos
    # inconsistentes ('streaming-playlistshls' vs 'streaming-playlists/hls') sin
    # patrón derivable de la URL (en un mismo host conviven ambos), así que se
    # prueba cuál responde 200 en vez de reescribir a ciegas.
    if "streaming-playlists/hls/" in url:
        alt = url.replace("streaming-playlists/hls/", "streaming-playlistshls/")
    elif "streaming-playlistshls/" in url:
        alt = url.replace("streaming-playlistshls/", "streaming-playlists/hls/")
    else:
        return url  # no es object storage con el patrón conocido: se usa tal cual
    if _probe(url):
        return url
    if _probe(alt):
        return alt
    return url  # ninguno respondió; se devuelve el original


def play_item(handle, uuid):
    """Resuelve y reproduce un vídeo de PeerTube. Llamado por default.py action=peertube_play."""
    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", "Resolviendo stream de PeerTube...")
    try:
        stream_url, kind = resolve_stream(uuid)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Error resolviendo PeerTube: {e}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaDaily", f"Error al resolver el stream:\n{e}")
        return

    if not stream_url:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaDaily", "No se pudo obtener la URL de reproducción de PeerTube.")
        return

    if kind == "hls" and not _has_inputstream_adaptive():
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaDaily",
            "Este vídeo solo está disponible en formato HLS y requiere "
            "'InputStream Adaptive', que no está instalado o está deshabilitado en Kodi.\n\n"
            "Actívalo desde el repositorio oficial para reproducirlo.")
        return

    xbmc.log(f"[EspaDaily] PeerTube stream ({kind}): {stream_url}", xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=stream_url)
    if kind == "hls":
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstreamaddon', 'inputstream.adaptive')  # compat Kodi 19
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setProperty('inputstream.adaptive.stream_headers',
                       'User-Agent=' + _HEADERS["User-Agent"])
        li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(handle, True, li)


def _has_inputstream_adaptive():
    try:
        xbmcaddon.Addon('inputstream.adaptive')
        return True
    except Exception:
        return False


def render_results(handle, query):
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaDaily", f"Buscando en PeerTube: {query}...")
    try:
        results = search(query)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaDaily] Error buscando en PeerTube: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("EspaDaily", f"Error al buscar en PeerTube:\n{e}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not results:
        xbmcgui.Dialog().ok("EspaDaily", f"No se encontraron resultados para:\n{query}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    addon_url = sys.argv[0]
    xbmcplugin.setContent(handle, 'videos')
    for r in results:
        play_url = addon_url + '?' + urllib.parse.urlencode(
            {'action': 'peertube_play', 'uuid': r['uuid']})
        thumb = r["thumb"] or "DefaultMusicVideos.png"

        li = xbmcgui.ListItem(label=r["title"])
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb,
                   'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):     plot_lines.append(f"Canal: {r['channel']}")
        if r.get("host"):        plot_lines.append(f"Instancia: {r['host']}")
        dur = _fmt_duration(r.get("duration", 0))
        if dur:                  plot_lines.append(f"Duración: {dur}")
        if r.get("description"): plot_lines.append(r["description"][:200])
        li.setInfo('video', {'plot': "\n".join(plot_lines) or r["title"],
                             'title': r["title"], 'duration': r.get("duration", 0),
                             'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')

        xbmcplugin.addDirectoryItem(handle=handle, url=play_url,
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

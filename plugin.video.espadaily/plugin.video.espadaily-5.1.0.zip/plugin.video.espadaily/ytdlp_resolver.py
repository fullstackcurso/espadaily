# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
import json
import subprocess

import xbmc


_CREATE_NO_WINDOW = 0x08000000
_INSTALLED_CACHE = None


def is_available():
    return not xbmc.getCondVisibility("System.Platform.Android")


def is_installed():
    global _INSTALLED_CACHE
    if _INSTALLED_CACHE is not None:
        return _INSTALLED_CACHE
    if not is_available():
        _INSTALLED_CACHE = False
        return False
    try:
        result = subprocess.run(
            ["python", "-m", "yt_dlp", "--version"],
            capture_output=True,
            timeout=5,
            creationflags=_CREATE_NO_WINDOW if _is_windows() else 0,
        )
        _INSTALLED_CACHE = result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        _INSTALLED_CACHE = False
    return _INSTALLED_CACHE


def invalidate_installed_cache():
    global _INSTALLED_CACHE
    _INSTALLED_CACHE = None


def _run_ytdlp(args, timeout):
    creation_flags = _CREATE_NO_WINDOW if _is_windows() else 0
    try:
        return subprocess.run(
            ["python", "-m", "yt_dlp"] + args,
            capture_output=True,
            text=True,
            timeout=timeout,
            creationflags=creation_flags,
        )
    except FileNotFoundError:
        xbmc.log("[EspaDaily] yt-dlp: Python no encontrado en PATH", xbmc.LOGWARNING)
    except subprocess.TimeoutExpired:
        xbmc.log(f"[EspaDaily] yt-dlp: timeout ({timeout}s)", xbmc.LOGWARNING)
    except OSError as exc:
        xbmc.log(f"[EspaDaily] yt-dlp: error de SO: {exc}", xbmc.LOGWARNING)
    return None


def _is_youtube_url(url):
    return "youtube.com" in url or "youtu.be" in url


def _is_bot_block(stderr):
    s = (stderr or "").lower()
    return "sign in to confirm" in s or "not a bot" in s


def _build_yt_args(fmt):
    return [
        "--dump-json", "--no-download",
        "--format", fmt, "--no-playlist",
        "--extractor-args", "youtube:player_client=tv,web_safari,mweb,tv_simply",
    ]


def _run_with_yt_fallback(url, base_args, timeout):
    """Ejecuta yt-dlp y, si YouTube bloquea por bot, reintenta con --impersonate chrome.
    Requiere curl_cffi instalado para el reintento (pip install curl_cffi)."""
    proc = _run_ytdlp(base_args + [url], timeout)
    if proc is None or proc.returncode == 0:
        return proc
    if not (_is_youtube_url(url) and _is_bot_block(proc.stderr)):
        return proc
    xbmc.log("[EspaDaily] yt-dlp: bot block detectado, reintentando con --impersonate chrome", xbmc.LOGINFO)
    retry = _run_ytdlp(base_args + ["--impersonate", "chrome", url], timeout)
    if retry is None:
        return proc
    if retry.returncode != 0 and "curl_cffi" in (retry.stderr or "").lower():
        xbmc.log("[EspaDaily] yt-dlp: --impersonate requiere 'pip install curl_cffi'", xbmc.LOGWARNING)
    return retry


def resolve(url, fmt="best[ext=mp4]/best", timeout=30):
    """Devuelve la URL directa del stream, o None si falla."""
    if not is_available():
        return None

    if _is_youtube_url(url):
        proc = _run_with_yt_fallback(url, _build_yt_args(fmt), timeout)
    else:
        proc = _run_ytdlp(
            ["--dump-json", "--no-download", "--format", fmt, "--no-playlist", url],
            timeout,
        )
    if proc is None:
        return None

    if proc.returncode != 0:
        xbmc.log(
            "[EspaDaily] yt-dlp: código {0} - {1}".format(
                proc.returncode, (proc.stderr or "").strip()[:800]),
            xbmc.LOGWARNING,
        )
        return None

    stdout = (proc.stdout or "").strip()
    if not stdout:
        xbmc.log("[EspaDaily] yt-dlp: stdout vacío. stderr={0}".format(
            (proc.stderr or "").strip()[:800]), xbmc.LOGWARNING)
        return None

    try:
        info = json.loads(stdout)
    except (json.JSONDecodeError, ValueError):
        xbmc.log("[EspaDaily] yt-dlp: JSON inválido en stdout", xbmc.LOGWARNING)
        return None

    result_url = info.get("url")
    if not result_url:
        xbmc.log("[EspaDaily] yt-dlp: JSON sin URL. stderr={0}".format(
            (proc.stderr or "").strip()[:800]), xbmc.LOGWARNING)
    return result_url or None


def resolve_full(url, fmt="best[ext=mp4]/best", timeout=30):
    """Devuelve {url, headers, protocol, ext} o None. Necesario para streams con UA/cookies obligatorios."""
    if not is_available():
        return None

    if _is_youtube_url(url):
        proc = _run_with_yt_fallback(url, _build_yt_args(fmt), timeout)
    else:
        proc = _run_ytdlp(
            ["--dump-json", "--no-download", "--format", fmt, "--no-playlist", url],
            timeout,
        )
    if proc is None or proc.returncode != 0:
        return None

    stdout = (proc.stdout or "").strip()
    if not stdout:
        return None

    try:
        info = json.loads(stdout)
    except (json.JSONDecodeError, ValueError):
        return None

    stream_url = info.get("url")
    if not stream_url:
        return None

    return {
        "url": stream_url,
        "headers": info.get("http_headers") or {},
        "protocol": info.get("protocol") or "",
        "ext": info.get("ext") or "",
    }


def scan_videos(url, timeout=90):
    """Devuelve [{title, url, duration, filesize, ext}, ...] de la página/playlist. [] si falla."""
    if not is_available():
        return []

    proc = _run_ytdlp(
        ["--dump-json", "--no-download", "--flat-playlist", url],
        timeout,
    )
    if proc is None:
        return []

    if proc.returncode != 0:
        xbmc.log(
            "[EspaDaily] yt-dlp scan: código {0} - {1}".format(
                proc.returncode, (proc.stderr or "").strip()[:200]),
            xbmc.LOGWARNING,
        )
        return []

    stdout = (proc.stdout or "").strip()
    if not stdout:
        return []

    results = []
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            info = json.loads(line)
        except (json.JSONDecodeError, ValueError):
            continue
        video_url = info.get("url") or info.get("webpage_url") or ""
        if not video_url:
            continue
        results.append({
            "title": info.get("title") or video_url,
            "url": video_url,
            "duration": info.get("duration"),
            "filesize": info.get("filesize") or info.get("filesize_approx"),
            "ext": info.get("ext") or "",
        })
    return results


def _is_windows():
    return xbmc.getCondVisibility("System.Platform.Windows")
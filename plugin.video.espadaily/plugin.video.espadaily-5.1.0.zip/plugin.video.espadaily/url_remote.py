# EspaDaily - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later - Consulta el archivo LICENSE para mas detalles.
"""
Servidor HTTP local para recibir URLs o texto desde movil o PC.

Inicia un mini servidor en la red local que sirve una pagina web
donde el usuario puede pegar una URL o escribir texto. Al enviar,
Kodi lo recibe y actua (reproduce la URL o usa el texto).

Incluye controles de reproduccion y estado en tiempo real
mediante JSON-RPC de Kodi. El servidor se levanta bajo demanda y se cierra al
terminar, sin dejar puertos abiertos ni obligar a activar el control HTTP de Kodi.

Si este proyecto te ha gustado, puedes darle una estrella en GitHub.
Si decides utilizar este código en tus propios desarrollos o te inspiras en esta idea, 
se agradece que menciones este proyecto original.

Visita el github https://github.com/fullstackcurso para ver el código del addon completo, colaborar o usar la API.
"""
import json
import os
import re
import socket
import threading
import time as _time
from http.server import HTTPServer, BaseHTTPRequestHandler
import ipaddress
import secrets
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.parse import quote, urlparse, parse_qs
from urllib.error import URLError
try:
    from http.server import ThreadingHTTPServer
except ImportError:
    # Python < 3.7 fallback
    from socketserver import ThreadingMixIn
    class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
        daemon_threads = True

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_PORT_RANGE = 10
_PORT_DEFAULT = 8089
_TIMEOUT_SECONDS = 300  # 5 minutos

_VALID_URL_SCHEMES = ("http://", "https://", "rtmp://", "rtsp://", "magnet:?", "acestream://")

_NTFY_DEFAULT_SERVER = "https://ntfy.sh"
_NTFY_TOPIC_PREFIX = "EspaDaily-"
_NTFY_READ_TIMEOUT = 45         # 1.5x el keepalive de ntfy.sh (~30s): detecta conexión muerta
_NTFY_RECONNECT_DELAY = 3       # backoff entre reconexiones si cae el stream


def _is_public_url(url):
    try:
        host = urlparse(url).hostname
        if not host:
            return False
        for info in socket.getaddrinfo(host, None):
            ip = ipaddress.ip_address(info[4][0])
            if (ip.is_private or ip.is_loopback or ip.is_link_local
                    or ip.is_reserved or ip.is_multicast or ip.is_unspecified):
                return False
        return True
    except Exception:
        return False


class _NoPrivateRedirect(HTTPRedirectHandler):
    """Revalida cada salto de redirect: un 3xx no puede apuntar a una IP
    interna (cierra el SSRF por redirect en /preview)."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not _is_public_url(newurl):
            raise URLError("redirect a destino no permitido")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


_safe_opener = build_opener(_NoPrivateRedirect())


def _get_secure():
    try:
        return xbmcaddon.Addon().getSetting('remote_secure') == 'true'
    except (AttributeError, RuntimeError):
        return False


def _get_port_start():
    try:
        val = xbmcaddon.Addon().getSetting('remote_port')
        if val:
            port = int(val)
            if 1024 <= port <= 65535:
                return port
    except (ValueError, RuntimeError):
        pass
    return _PORT_DEFAULT


def _get_webremote_mode():
    _LABELS = ["Red local", "Internet"]
    try:
        val = xbmcaddon.Addon().getSetting('webremote_mode') or '0'
        try:
            idx = int(val)
        except ValueError:
            idx = _LABELS.index(val) if val in _LABELS else 0
        return "internet" if idx == 1 else "lan"
    except (AttributeError, RuntimeError):
        return "lan"


def _get_webremote_confirm():
    try:
        return xbmcaddon.Addon().getSetting('webremote_confirm') == 'true'
    except (AttributeError, RuntimeError):
        return False


def _get_webremote_server():
    try:
        val = (xbmcaddon.Addon().getSetting('webremote_server') or '').strip().rstrip('/')
        if val.startswith(("http://", "https://")):
            return val
    except (AttributeError, RuntimeError):
        pass
    return _NTFY_DEFAULT_SERVER


def _get_or_create_topic():
    # El topic actúa como secreto: solo quien lo conozca puede enviar a este Kodi.
    try:
        addon = xbmcaddon.Addon()
        topic = addon.getSetting('webremote_topic').strip()
        if not topic:
            topic = _NTFY_TOPIC_PREFIX + secrets.token_hex(8)
            addon.setSetting('webremote_topic', topic)
        return topic
    except (AttributeError, RuntimeError):
        return _NTFY_TOPIC_PREFIX + secrets.token_hex(8)


_POLL_INTERVAL_MS = 500


def _get_local_ip():
    try:
        ip = xbmc.getIPAddress()
        if ip and ip != "127.0.0.1" and not ip.startswith("0."):
            return ip
    except (AttributeError, RuntimeError):
        pass

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.settimeout(0)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            if ip and ip != "127.0.0.1":
                return ip
        finally:
            s.close()
    except OSError:
        pass

    return None


_MAX_HISTORY = 50
_history_lock = threading.Lock()
_sse_connections = 0
_sse_lock = threading.Lock()
_MAX_SSE = 3
_keep_alive_lock = threading.Lock()

_YOUTUBE_OEMBED = "https://www.youtube.com/oembed?url={url}&format=json"
_preview_cache = {}
_preview_lock = threading.Lock()
_PREVIEW_CACHE_MAX = 20


def _history_path():
    try:
        profile = xbmcaddon.Addon().getAddonInfo("profile")
        folder = xbmcvfs.translatePath(profile)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        return os.path.join(folder, "url_history.json")
    except (OSError, RuntimeError):
        return None


def _load_history():
    path = _history_path()
    if not path or not os.path.isfile(path):
        return []
    try:
        with _history_lock:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _save_history(entries):
    path = _history_path()
    if not path:
        return
    try:
        with _history_lock:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(entries[:_MAX_HISTORY], fh, ensure_ascii=False)
    except OSError:
        pass


def _add_to_history(url, url_type=""):
    with _history_lock:
        path = _history_path()
        if not path:
            return
        # Leer dentro del lock para evitar race condition con _save_history
        try:
            if os.path.isfile(path):
                with open(path, "r", encoding="utf-8") as fh:
                    entries = json.load(fh)
                if not isinstance(entries, list):
                    entries = []
            else:
                entries = []
        except (OSError, ValueError):
            entries = []
        entry = {
            "url": url,
            "type": url_type,
            "ts": int(_time.time()),
        }
        # Evitar duplicados consecutivos
        if entries and entries[0].get("url") == url:
            entries[0] = entry
        else:
            entries.insert(0, entry)
        try:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(entries[:_MAX_HISTORY], fh, ensure_ascii=False)
        except OSError:
            pass


def _detect_platform(url):
    if re.search(r'youtu\.?be|youtube', url, re.I):
        return "youtube"
    if re.search(r'dailymotion\.com|dai\.ly', url, re.I):
        return "dailymotion"
    if re.search(r'vimeo\.com', url, re.I):
        return "vimeo"
    return None


def _fetch_og_meta(url):
    try:
        req = Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; Kodi)"})
        with _safe_opener.open(req, timeout=4) as resp:
            html = resp.read(51200).decode("utf-8", errors="ignore")
        # Patron flexible: soporta content antes o despues de property
        og_title = re.search(
            r'<meta\s+[^>]*?(?:property|name)=["\']og:title["\'][^>]*?content=["\']([^"\']+)',
            html, re.I
        ) or re.search(
            r'<meta\s+[^>]*?content=["\']([^"\']+)["\'][^>]*?(?:property|name)=["\']og:title["\']',
            html, re.I
        )
        og_image = re.search(
            r'<meta\s+[^>]*?(?:property|name)=["\']og:image["\'][^>]*?content=["\']([^"\']+)',
            html, re.I
        ) or re.search(
            r'<meta\s+[^>]*?content=["\']([^"\']+)["\'][^>]*?(?:property|name)=["\']og:image["\']',
            html, re.I
        )
        og_site = re.search(
            r'<meta\s+[^>]*?(?:property|name)=["\']og:site_name["\'][^>]*?content=["\']([^"\']+)',
            html, re.I
        ) or re.search(
            r'<meta\s+[^>]*?content=["\']([^"\']+)["\'][^>]*?(?:property|name)=["\']og:site_name["\']',
            html, re.I
        )
        # Fallback al <title> si no hay og:title
        if not og_title:
            og_title = re.search(r'<title[^>]*>([^<]+)</title>', html, re.I)
        title = og_title.group(1).strip() if og_title else ""
        thumb = og_image.group(1).strip() if og_image else ""
        site = og_site.group(1).strip() if og_site else ""
        if not title and not thumb:
            return None
        return {
            "title": title,
            "thumbnail": thumb,
            "author": "",
            "provider": site,
            "duration": None,
        }
    except (OSError, ValueError):
        return None


def _fetch_preview(url):
    with _preview_lock:
        if url in _preview_cache:
            return _preview_cache[url]

    result = None

    # Intentar oEmbed para YouTube (mas rapido y fiable)
    platform = _detect_platform(url)
    if platform == "youtube":
        endpoint = _YOUTUBE_OEMBED.format(url=quote(url, safe=""))
        try:
            req = Request(endpoint, headers={"User-Agent": "Kodi/EspaDaily"})
            with _safe_opener.open(req, timeout=3) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            result = {
                "title": data.get("title", ""),
                "thumbnail": data.get("thumbnail_url", ""),
                "author": data.get("author_name", ""),
                "provider": data.get("provider_name", platform),
                "duration": data.get("duration"),
            }
        except (OSError, ValueError):
            pass

    # Fallback universal: Open Graph meta tags
    if not result and url.startswith(("http://", "https://")):
        result = _fetch_og_meta(url)

    if result:
        with _preview_lock:
            if len(_preview_cache) >= _PREVIEW_CACHE_MAX:
                _preview_cache.pop(next(iter(_preview_cache)))
            _preview_cache[url] = result

    return result


def _scan_videos_hybrid(url):
    """yt-dlp en escritorio; html_scanner como fallback universal."""
    import ytdlp_resolver
    if ytdlp_resolver.is_available():
        results = ytdlp_resolver.scan_videos(url)
        if results:
            return results
    import html_scanner
    return html_scanner.scan_page(url)


def _kodi_rpc(method, params=None):
    request = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params:
        request["params"] = params
    try:
        raw = xbmc.executeJSONRPC(json.dumps(request))
        return json.loads(raw).get("result")
    except (ValueError, TypeError, AttributeError):
        return None


def _get_player_status():
    players = _kodi_rpc("Player.GetActivePlayers")
    if not players:
        return {"playing": False}

    pid = players[0].get("playerid", 0)

    item = _kodi_rpc("Player.GetItem", {"playerid": pid, "properties": ["title"]})
    title = ""
    if item and item.get("item"):
        title = item["item"].get("title") or item["item"].get("label", "")

    props = _kodi_rpc("Player.GetProperties", {
        "playerid": pid,
        "properties": ["speed", "time", "totaltime"]
    })

    speed = 0
    time_str = ""
    total_str = ""
    seconds = 0
    totalseconds = 0
    if props:
        speed = props.get("speed", 0)
        t = props.get("time", {})
        tt = props.get("totaltime", {})
        time_str = "{0:02d}:{1:02d}:{2:02d}".format(
            t.get("hours", 0), t.get("minutes", 0), t.get("seconds", 0)
        )
        total_str = "{0:02d}:{1:02d}:{2:02d}".format(
            tt.get("hours", 0), tt.get("minutes", 0), tt.get("seconds", 0)
        )
        seconds = t.get("hours", 0) * 3600 + t.get("minutes", 0) * 60 + t.get("seconds", 0)
        totalseconds = tt.get("hours", 0) * 3600 + tt.get("minutes", 0) * 60 + tt.get("seconds", 0)

    vol_result = _kodi_rpc("Application.GetProperties", {"properties": ["volume", "muted"]})
    volume = 100
    muted = False
    if vol_result:
        volume = vol_result.get("volume", 100)
        muted = vol_result.get("muted", False)

    percentage = 0
    if totalseconds > 0:
        percentage = round((seconds / totalseconds) * 100, 1)

    return {
        "playing": True,
        "paused": speed == 0,
        "title": title,
        "time": time_str,
        "totaltime": total_str,
        "seconds": seconds,
        "totalseconds": totalseconds,
        "percentage": percentage,
        "volume": volume,
        "muted": muted,
    }


# Agradecimientos especiales al addon SendToKodi, cuyo código sirvió
# como inspiración.
class _RemoteHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        xbmc.log("[EspaDaily/remote] {0}".format(fmt % args), xbmc.LOGDEBUG)

    def _get_path(self):
        return urlparse(self.path).path

    def _check_token(self):
        if not self.server.secure:
            return True
        t = self.headers.get('X-Remote-Token', '').strip()
        if not t:
            qs = parse_qs(urlparse(self.path).query)
            t = qs.get('t', [''])[0]
        if not t:
            return False
        return secrets.compare_digest(t, self.server.token)

    def _reject_unauthorized(self):
        body = b'{"error":"No autorizado"}'
        self.send_response(403)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self._check_token():
            self._reject_unauthorized()
            return
        path = self._get_path()
        if path == "/" or path == "":
            self._serve_html()
        elif path == "/status":
            self._serve_status()
        elif path == "/events":
            self._serve_sse()
        elif path == "/history":
            self._serve_history()
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if not self._check_token():
            self._reject_unauthorized()
            return
        path = self._get_path()
        if path == "/send":
            self._handle_send()
        elif path == "/control":
            self._handle_control()
        elif path == "/toggle-keep-alive":
            self._handle_toggle_keep_alive()
        elif path == "/history/clear":
            self._handle_history_clear()
        elif path == "/history/remove":
            self._handle_history_remove()
        elif path == "/preview":
            self._handle_preview()
        elif path == "/scan":
            self._handle_scan()
        elif path == "/scan-telegram":
            self._handle_scan_telegram()
        else:
            self.send_response(404)
            self.end_headers()

    def _serve_html(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        if self.server.secure:
            token_script = (
                '<script>'
                'window.__RT__="{t}";'
                '(function(){{var _f=window.fetch;window.fetch=function(u,o){{'
                'o=o||{{}};o.headers=Object.assign({{}},o.headers,{{"X-Remote-Token":window.__RT__}});'
                'return _f(u,o);}};'
                'var _ES=window.EventSource;window.EventSource=function(u,c){{'
                'var s=u.indexOf("?")>=0?"&":"?";return new _ES(u+s+"t="+window.__RT__,c);}};'
                '}})()'
                '</script>'
            ).format(t=self.server.token)
            page = self.server.html_page.replace('</head>', token_script + '</head>', 1)
        else:
            page = self.server.html_page
        self.wfile.write(page.encode("utf-8"))

    def _serve_status(self):
        status = _get_player_status()
        self._json_response(200, status)

    def _handle_send(self):
        data = self._read_json_body()
        if data is None:
            return

        url = (data.get("url") or data.get("text") or "").strip()
        if not url:
            self._json_response(400, {"error": "Campo vacio"})
            return

        if self.server.mode == "url":
            if re.match(r'^[0-9a-fA-F]{40}$', url):
                url = "acestream://" + url.lower()
            if not url.startswith(_VALID_URL_SCHEMES):
                self._json_response(400, {"error": "URL no valida. Esquemas soportados: http, magnet, acestream"})
                return

        self.server.received_url = url
        if self.server.mode == "url":
            _add_to_history(url)
        with _keep_alive_lock:
            is_keep_alive = self.server.keep_alive
        if is_keep_alive and self.server.mode == "url":
            msg = "URL recibida. Reproduciendo en Kodi..."
            self._json_response(200, {"ok": True, "message": msg, "keepAlive": True})
            import url_player
            threading.Thread(
                target=url_player.play_url_action,
                args=(url,),
                daemon=True,
            ).start()
        else:
            self.server.url_event.set()
            msg = "URL recibida. Reproduciendo en Kodi..." if self.server.mode == "url" else "Texto recibido."
            self._json_response(200, {"ok": True, "message": msg})

    def _handle_control(self):
        data = self._read_json_body()
        if data is None:
            return

        action = data.get("action", "")
        result = False

        if action == "playpause":
            players = _kodi_rpc("Player.GetActivePlayers")
            if players:
                pid = players[0].get("playerid", 0)
                _kodi_rpc("Player.PlayPause", {"playerid": pid})
                result = True

        elif action == "stop":
            players = _kodi_rpc("Player.GetActivePlayers")
            if players:
                pid = players[0].get("playerid", 0)
                _kodi_rpc("Player.Stop", {"playerid": pid})
                result = True

        elif action == "volup":
            vol = _kodi_rpc("Application.GetProperties", {"properties": ["volume"]})
            if vol:
                new_vol = min(100, vol.get("volume", 50) + 5)
                _kodi_rpc("Application.SetVolume", {"volume": new_vol})
                result = True

        elif action == "voldown":
            vol = _kodi_rpc("Application.GetProperties", {"properties": ["volume"]})
            if vol:
                new_vol = max(0, vol.get("volume", 50) - 5)
                _kodi_rpc("Application.SetVolume", {"volume": new_vol})
                result = True

        elif action == "mute":
            _kodi_rpc("Application.SetMute", {"mute": "toggle"})
            result = True

        elif action == "seek":
            value = data.get("value")
            if value is not None:
                try:
                    pct = max(0, min(100, float(value)))
                except (ValueError, TypeError):
                    self._json_response(400, {"error": "Valor de seek no numerico"})
                    return
                players = _kodi_rpc("Player.GetActivePlayers")
                if players:
                    pid = players[0].get("playerid", 0)
                    _kodi_rpc("Player.Seek", {
                        "playerid": pid,
                        "value": {"percentage": pct},
                    })
                    result = True

        if result:
            self._json_response(200, {"ok": True})
        else:
            self._json_response(400, {"error": "Accion no reconocida o sin reproductor activo"})

    def _read_json_body(self):
        try:
            content_length = int(self.headers.get("Content-Length", 0))
        except (ValueError, TypeError):
            self._json_response(400, {"error": "Content-Length no valido"})
            return None
        if content_length == 0 or content_length > 4096:
            self._json_response(400, {"error": "Datos no validos"})
            return None

        body = self.rfile.read(content_length)
        try:
            return json.loads(body.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            self._json_response(400, {"error": "JSON no valido"})
            return None

    def _json_response(self, code, obj):
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.end_headers()
        self.wfile.write(json.dumps(obj, ensure_ascii=False).encode("utf-8"))

    def _handle_toggle_keep_alive(self):
        with _keep_alive_lock:
            self.server.keep_alive = not self.server.keep_alive
            new_state = self.server.keep_alive
        self._json_response(200, {
            "ok": True,
            "keepAlive": new_state,
        })

    def _serve_sse(self):
        global _sse_connections
        with _sse_lock:
            if _sse_connections >= _MAX_SSE:
                self._json_response(429, {"error": "Demasiadas conexiones SSE"})
                return
            _sse_connections += 1
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.end_headers()
            while True:
                status = _get_player_status()
                payload = "data: " + json.dumps(status) + "\n\n"
                self.wfile.write(payload.encode("utf-8"))
                self.wfile.flush()
                _time.sleep(2)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            with _sse_lock:
                _sse_connections -= 1

    def _serve_history(self):
        entries = _load_history()
        self._json_response(200, {"history": entries})

    def _handle_history_clear(self):
        # Drenar body sin error de formato (evita doble respuesta)
        try:
            cl = int(self.headers.get("Content-Length", 0))
            if 0 < cl <= 4096:
                self.rfile.read(cl)
        except (ValueError, TypeError, OSError):
            pass
        _save_history([])
        self._json_response(200, {"ok": True})

    def _handle_history_remove(self):
        data = self._read_json_body()
        if data is None:
            return
        url = (data.get("url") or "").strip()
        if not url:
            self._json_response(400, {"error": "url requerida"})
            return
        # Leer-filtrar-escribir en un único bloque para evitar race condition
        # (no se puede llamar a _load_history/_save_history aquí porque cada uno
        # adquiere _history_lock por separado y Lock no es reentrant).
        with _history_lock:
            path = _history_path()
            if path:
                try:
                    if os.path.isfile(path):
                        with open(path, "r", encoding="utf-8") as fh:
                            entries = json.load(fh)
                        if not isinstance(entries, list):
                            entries = []
                    else:
                        entries = []
                except (OSError, ValueError):
                    entries = []
                entries = [
                    h for h in entries
                    if (h.get("url") if isinstance(h, dict) else h) != url
                ]
                try:
                    with open(path, "w", encoding="utf-8") as fh:
                        json.dump(entries[:_MAX_HISTORY], fh, ensure_ascii=False)
                except OSError:
                    pass
        self._json_response(200, {"ok": True})

    def _handle_scan_telegram(self):
        data = self._read_json_body()
        if data is None:
            return
        channel = (data.get("url") or data.get("channel") or "").strip()
        if not channel:
            self._json_response(400, {"error": "Canal vacio"})
            return
        try:
            import telegram_scanner
            videos = telegram_scanner.scan_channel(channel)
        except Exception as exc:
            xbmc.log(
                "[EspaDaily/remote] Error escaneando Telegram {0}: {1}".format(channel[:40], exc),
                xbmc.LOGWARNING,
            )
            self._json_response(200, {"ok": True, "videos": [], "count": 0})
            return
        import html_scanner
        formatted = []
        for v in videos[:50]:
            formatted.append({
                "title": v.get("title") or v.get("url", "")[:60],
                "url": v.get("url", ""),
                "duration": html_scanner.format_duration(v.get("duration")),
                "filesize": html_scanner.format_size(v.get("filesize")),
                "ext": v.get("ext", ""),
                "source": v.get("source", "telegram"),
            })
        self._json_response(200, {
            "ok": True,
            "videos": formatted,
            "count": len(formatted),
        })

    def _handle_preview(self):
        data = self._read_json_body()
        if data is None:
            return
        url = (data.get("url") or "").strip()
        if not url:
            self._json_response(400, {"error": "URL vacia"})
            return
        if not url.startswith(("http://", "https://")):
            self._json_response(400, {"error": "Solo URLs HTTP/HTTPS"})
            return
        if self.server.secure and not _is_public_url(url):
            self._json_response(400, {"error": "URLs privadas no permitidas"})
            return
        meta = _fetch_preview(url)
        if meta:
            self._json_response(200, {"ok": True, "preview": meta})
        else:
            platform = _detect_platform(url)
            self._json_response(200, {"ok": True, "preview": None, "platform": platform})

    def _handle_scan(self):
        data = self._read_json_body()
        if data is None:
            return
        url = (data.get("url") or "").strip()
        if not url:
            self._json_response(400, {"error": "URL vacia"})
            return
        if not url.startswith(("http://", "https://")):
            self._json_response(400, {"error": "Solo URLs HTTP/HTTPS"})
            return
        if self.server.secure and not _is_public_url(url):
            self._json_response(400, {"error": "URLs privadas no permitidas"})
            return
        try:
            videos = _scan_videos_hybrid(url)
        except (OSError, ValueError, ImportError) as exc:
            xbmc.log(
                "[EspaDaily/remote] Error escaneando {0}: {1}".format(url[:60], exc),
                xbmc.LOGWARNING,
            )
            self._json_response(200, {"ok": True, "videos": [], "count": 0})
            return
        import html_scanner
        formatted = []
        for v in videos[:50]:
            formatted.append({
                "title": v.get("title") or v.get("url", "")[:60],
                "url": v.get("url", ""),
                "duration": html_scanner.format_duration(v.get("duration")),
                "filesize": html_scanner.format_size(v.get("filesize")),
                "ext": v.get("ext", ""),
            })
        self._json_response(200, {
            "ok": True,
            "videos": formatted,
            "count": len(formatted),
        })


class _RemoteServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, handler_class, mode="url", secure=False):
        self.received_url = None
        self.url_event = threading.Event()
        self.mode = mode
        self.keep_alive = False
        self.secure = secure
        self.token = secrets.token_urlsafe(16) if secure else None
        self.html_page = _HTML_URL if mode == "url" else _HTML_TEXT
        ThreadingHTTPServer.__init__(self, address, handler_class)


def _try_start_server(mode="url", secure=False):
    port_start = _get_port_start()
    port_end = port_start + _PORT_RANGE
    for port in range(port_start, port_end + 1):
        try:
            server = _RemoteServer(("", port), _RemoteHandler, mode, secure=secure)
            return server, port
        except OSError:
            continue
    return None, 0


def _run_server(mode, title, wait_msg):
    """Levanta servidor + diálogo de espera. Devuelve el texto/URL recibido o None."""
    ip = _get_local_ip()
    if not ip:
        xbmcgui.Dialog().ok(
            "EspaDaily",
            "No se pudo detectar la IP local.\n\n"
            "Asegurate de estar conectado a una red WiFi o Ethernet."
        )
        return None

    secure = _get_secure()
    server, port = _try_start_server(mode, secure=secure)
    if not server:
        port_start = _get_port_start()
        xbmcgui.Dialog().ok(
            "EspaDaily",
            "No se pudo iniciar el servidor.\n\n"
            "Los puertos {0}-{1} estan ocupados.".format(port_start, port_start + _PORT_RANGE)
        )
        return None

    if secure:
        addr = "http://{0}:{1}/?t={2}".format(ip, port, server.token)
    else:
        addr = "http://{0}:{1}".format(ip, port)
    xbmc.log("[EspaDaily/remote] Servidor iniciado en http://{0}:{1} (modo: {2})".format(ip, port, mode), xbmc.LOGINFO)

    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    pdp = xbmcgui.DialogProgress()
    pdp.create(
        title,
        "Abre esta direccion en tu navegador:\n\n"
        "[B]{0}[/B]\n\n"
        "{1}".format(addr, wait_msg)
    )

    received = None
    elapsed = 0

    while elapsed < _TIMEOUT_SECONDS:
        if pdp.iscanceled():
            break

        if server.url_event.wait(timeout=_POLL_INTERVAL_MS / 1000):
            received = server.received_url
            break

        # Con keep_alive activo, el servidor permanece abierto indefinidamente
        if server.keep_alive:
            elapsed = 0
            pdp.update(
                0,
                "Abre esta direccion en tu navegador:\n\n"
                "[B]{0}[/B]\n\n"
                "Servidor fijado (pulsa Cancel para cerrar)".format(addr)
            )
        else:
            elapsed += _POLL_INTERVAL_MS / 1000
            remaining = int(_TIMEOUT_SECONDS - elapsed)
            progress = int((elapsed / _TIMEOUT_SECONDS) * 100)
            pdp.update(
                progress,
                "Abre esta direccion en tu navegador:\n\n"
                "[B]{0}[/B]\n\n"
                "{1} ({2}s)".format(addr, wait_msg, remaining)
            )

    pdp.close()
    server.shutdown()
    server.server_close()
    thread.join(timeout=3)

    if elapsed >= _TIMEOUT_SECONDS and not received:
        xbmcgui.Dialog().notification(
            "EspaDaily", "Tiempo agotado",
            xbmcgui.NOTIFICATION_WARNING, 2000
        )

    return received


def _ntfy_stream_thread(server, topic, done_event, holder, stop_event, lock):
    # Conexión de streaming persistente: ntfy mantiene el GET abierto y empuja
    # los mensajes al instante. Un poll repetido agotaría el rate limit anónimo.
    url = "{0}/{1}/json".format(server, topic)
    while not stop_event.is_set():
        try:
            req = Request(url, headers={"User-Agent": "Kodi/EspaDaily"})
            resp = _safe_opener.open(req, timeout=_NTFY_READ_TIMEOUT)
            with lock:
                # stop() pudo dispararse mientras open() bloqueaba: cerramos aquí
                # en vez de entrar al loop y bloquear hasta el timeout de lectura.
                if stop_event.is_set():
                    try:
                        resp.close()
                    except OSError:
                        pass
                    return
                holder["resp"] = resp
            try:
                for raw in resp:
                    if stop_event.is_set():
                        return
                    line = raw.decode("utf-8", errors="ignore").strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except ValueError:
                        continue
                    if not isinstance(obj, dict):
                        continue   # ntfy siempre manda objetos; defensa ante self-hosted/anómalo
                    if obj.get("event") != "message":
                        continue
                    msg = (obj.get("message") or "").strip()
                    if msg:
                        holder["result"] = msg
                        done_event.set()
                        return
            finally:
                with lock:
                    holder["resp"] = None
                try:
                    resp.close()
                except OSError:
                    pass
        except OSError:
            if stop_event.is_set():
                return
        if not stop_event.is_set():
            stop_event.wait(timeout=_NTFY_RECONNECT_DELAY)


def _run_ntfy(mode, title, wait_msg):
    server = _get_webremote_server()
    topic = _get_or_create_topic()
    sub_url = "{0}/{1}".format(server, topic)

    holder = {"resp": None, "result": None}
    done_event = threading.Event()
    stop_event = threading.Event()
    lock = threading.Lock()
    thread = threading.Thread(
        target=_ntfy_stream_thread,
        args=(server, topic, done_event, holder, stop_event, lock),
        daemon=True,
    )
    thread.start()

    xbmc.log("[EspaDaily/remote] Modo internet escuchando en {0} (modo: {1})".format(sub_url, mode), xbmc.LOGINFO)

    pdp = xbmcgui.DialogProgress()
    pdp.create(
        title,
        "Abre esta direccion en tu movil o PC\ny pulsa Publicar para enviar:\n\n"
        "[B]{0}[/B]\n\n{1}".format(sub_url, wait_msg)
    )

    received = None
    elapsed = 0.0
    while elapsed < _TIMEOUT_SECONDS:
        if pdp.iscanceled():
            break
        if done_event.wait(timeout=_POLL_INTERVAL_MS / 1000):
            received = holder["result"]
            break
        elapsed += _POLL_INTERVAL_MS / 1000
        remaining = int(_TIMEOUT_SECONDS - elapsed)
        progress = int((elapsed / _TIMEOUT_SECONDS) * 100)
        pdp.update(
            progress,
            "Abre esta direccion en tu movil o PC\ny pulsa Publicar para enviar:\n\n"
            "[B]{0}[/B]\n\n{1} ({2}s)".format(sub_url, wait_msg, remaining)
        )

    pdp.close()
    stop_event.set()
    with lock:
        resp = holder["resp"]
        holder["resp"] = None
    if resp is not None:
        try:
            resp.close()   # desbloquea la lectura del hilo al instante
        except OSError:
            pass
    thread.join(timeout=5)

    if elapsed >= _TIMEOUT_SECONDS and not received:
        xbmcgui.Dialog().notification(
            "EspaDaily", "Tiempo agotado",
            xbmcgui.NOTIFICATION_WARNING, 2000
        )

    return received


def start_remote():
    if _get_webremote_mode() == "internet":
        received = _run_ntfy("url", "Enviar dirección por internet", "Esperando dirección...")
        if received:
            if re.match(r'^[0-9a-fA-F]{40}$', received):
                received = "acestream://" + received.lower()
            if not received.startswith(_VALID_URL_SCHEMES):
                xbmc.log("[EspaDaily/remote] URL ignorada (esquema invalido): " + received[:80], xbmc.LOGWARNING)
                received = None
    else:
        received = _run_server("url", "Enviar dirección desde móvil/PC", "Esperando dirección...")

    if received:
        if _get_webremote_confirm() and not xbmcgui.Dialog().yesno(
                "EspaDaily", "¿Reproducir la dirección recibida?\n\n" + received[:150]):
            return
        xbmcgui.Dialog().notification(
            "EspaDaily", "Dirección recibida, reproduciendo...",
            xbmcgui.NOTIFICATION_INFO, 2000
        )
        import url_player
        url_player.play_url_action(received)


def receive_text(title="Escribir desde movil/PC"):
    if _get_webremote_mode() == "internet":
        received = _run_ntfy("text", title, "Esperando texto...")
    else:
        received = _run_server("text", title, "Esperando texto...")
    if received:
        xbmcgui.Dialog().notification(
            "EspaDaily", "Texto recibido",
            xbmcgui.NOTIFICATION_INFO, 1500
        )
    return received


# HTML embebido (pagina URL)

_HTML_URL = """<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<title>EspaDaily Remote</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  background:#0d1117;color:#c9d1d9;
  min-height:100vh;display:flex;align-items:center;justify-content:center;
  padding:16px;
}
.card{
  background:#161b22;border:1px solid #30363d;border-radius:12px;
  padding:32px 24px;max-width:540px;width:100%;
  box-shadow:0 8px 32px rgba(0,0,0,.4);
}
h1{
  font-size:1.35em;text-align:center;margin-bottom:4px;
  color:#e6edf3;font-weight:500;letter-spacing:-.3px;
}
.sub{
  text-align:center;color:#8b949e;font-size:.85em;margin-bottom:6px;
}
.status-dot{
  display:inline-block;width:8px;height:8px;border-radius:50%;
  background:#484f58;margin-right:6px;vertical-align:middle;
  transition:background .3s;
}
.status-dot.on{background:#3fb950}
.status-bar{
  text-align:center;font-size:.75em;color:#8b949e;margin-bottom:20px;
  min-height:16px;
}
label{
  display:block;font-size:.9em;color:#8b949e;margin-bottom:6px;
}
.badge{
  display:inline-block;font-size:.7em;padding:2px 8px;border-radius:10px;
  margin-left:8px;vertical-align:middle;font-weight:600;
  background:#21262d;color:#8b949e;transition:all .3s;
}
.badge.youtube{background:#2d1117;color:#f85149}
.badge.dailymotion{background:#1a1d2e;color:#58a6ff}
.badge.stream{background:#0d2818;color:#3fb950}
.badge.torrent{background:#2d1f0d;color:#d29922}
.badge.acestream{background:#0d1f2d;color:#39d2e5}
.badge.twitch{background:#24163a;color:#a970ff}
.badge.vimeo{background:#1a2d2e;color:#1ab7ea}
.drop-zone{
  position:relative;
  width:100%;min-height:80px;padding:12px;
  background:#0d1117;color:#c9d1d9;
  border:1px solid #30363d;border-radius:8px;
  font-size:16px;font-family:monospace;
  resize:vertical;outline:none;
  transition:border-color .2s;
}
.drop-zone:focus{border-color:#58a6ff}
.drop-zone::placeholder{color:#484f58}
.drop-zone.dragover{
  border-color:#58a6ff;border-style:dashed;
  background:rgba(88,166,255,.05);
}
.btn-primary{
  display:block;width:100%;padding:14px;margin-top:16px;
  background:#e6edf3;color:#0d1117;
  border:1px solid #d0d7de;border-radius:8px;
  font-size:1em;font-weight:600;cursor:pointer;
  transition:background .15s,border-color .15s;
}
.btn-primary:hover{background:#f0f6fc}
.btn-primary:active{background:#d0d7de;transform:scale(.99)}
.btn-primary:disabled{background:#21262d;color:#484f58;border-color:#21262d;cursor:not-allowed}
.msg{
  margin-top:14px;padding:10px 14px;border-radius:8px;
  font-size:.9em;text-align:center;display:none;
}
.msg.ok{display:flex;align-items:center;justify-content:center;gap:8px;background:#0d2818;color:#3fb950;border:1px solid #238636}
.msg.err{display:block;background:#2d1117;color:#f85149;border:1px solid #da3633}
.check-svg{width:20px;height:20px;flex-shrink:0}
.check-svg circle{stroke:#3fb950;stroke-width:2;fill:none;stroke-dasharray:52;stroke-dashoffset:52;animation:circ .4s ease forwards}
.check-svg path{stroke:#3fb950;stroke-width:2;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:20;stroke-dashoffset:20;animation:tick .3s .35s ease forwards}
@keyframes circ{to{stroke-dashoffset:0}}
@keyframes tick{to{stroke-dashoffset:0}}

/* --- Controles --- */
.controls{
  display:flex;align-items:center;justify-content:center;gap:6px;
  margin-top:18px;padding-top:16px;border-top:1px solid #21262d;
}
.ctrl-btn{
  width:40px;height:40px;border-radius:8px;border:1px solid #30363d;
  background:#0d1117;color:#c9d1d9;cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  font-size:1.1em;transition:background .15s,border-color .15s;
}
.ctrl-btn:hover{background:#161b22;border-color:#58a6ff}
.ctrl-btn:active{transform:scale(.93)}
.ctrl-btn svg{width:18px;height:18px;fill:#c9d1d9}
.vol-label{font-size:.7em;color:#8b949e;min-width:32px;text-align:center}
.now-playing{
  text-align:center;font-size:.78em;color:#8b949e;margin-top:8px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
  max-width:100%;min-height:16px;
}

/* --- Barra de progreso --- */
.progress-container{
  margin-top:8px;padding:0 4px;display:none;
}
.progress-container.visible{display:block}
.progress-times{
  display:flex;justify-content:space-between;
  font-size:.7em;color:#484f58;margin-bottom:4px;font-variant-numeric:tabular-nums;
}
.progress-bar{
  -webkit-appearance:none;appearance:none;width:100%;height:6px;
  background:#21262d;border-radius:3px;outline:none;cursor:pointer;
}
.progress-bar::-webkit-slider-thumb{
  -webkit-appearance:none;appearance:none;
  width:14px;height:14px;border-radius:50%;
  background:#58a6ff;cursor:pointer;
  border:2px solid #0d1117;
  margin-top:-4px;
}
.progress-bar::-moz-range-thumb{
  width:14px;height:14px;border-radius:50%;
  background:#58a6ff;cursor:pointer;
  border:2px solid #0d1117;
}
.progress-bar::-webkit-slider-runnable-track{
  height:6px;border-radius:3px;
}
.progress-bar::-moz-range-track{
  height:6px;border-radius:3px;background:#21262d;
}

/* --- Preview card --- */
.preview-card{
  display:none;margin-top:10px;padding:10px;border-radius:8px;
  background:#0d1117;border:1px solid #30363d;
  gap:10px;align-items:center;
}
.preview-card.visible{display:flex}
.preview-card.loading{display:flex}
.preview-thumb{
  width:100px;min-width:100px;height:56px;border-radius:4px;
  object-fit:cover;background:#21262d;
}
.preview-info{flex:1;overflow:hidden}
.preview-title{
  font-size:.82em;color:#c9d1d9;font-weight:600;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}
.preview-author{
  font-size:.72em;color:#8b949e;margin-top:2px;
}
.preview-skeleton{
  background:linear-gradient(90deg,#21262d 25%,#30363d 50%,#21262d 75%);
  background-size:400% 100%;animation:shimmer 1.5s infinite;
  border-radius:4px;
}
@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}
.preview-skeleton-thumb{width:100px;min-width:100px;height:56px}
.preview-skeleton-text{height:12px;width:70%;margin-bottom:6px}
.preview-skeleton-text2{height:10px;width:45%}

/* --- Historial --- */
.history{margin-top:18px;padding-top:14px;border-top:1px solid #21262d}
.history-header{
  display:flex;align-items:center;justify-content:center;
  position:relative;padding:4px 0;
  cursor:pointer;user-select:none;
}
.history-header span{font-size:.92em;color:#8b949e;display:flex;align-items:center;gap:9px}
.hist-icon{width:22px;height:22px;fill:#6e7681;flex-shrink:0}
.history-header .arrow{
  width:16px;height:16px;fill:#484f58;flex-shrink:0;
  transition:transform .2s;
}
.history-header .arrow.open{transform:rotate(90deg)}
.history-list{
  list-style:none;margin-top:8px;max-height:260px;overflow-y:auto;
}
.history-list.hidden{display:none}
.history-item{
  display:flex;align-items:center;gap:8px;
  padding:6px 8px;margin-bottom:4px;border-radius:6px;
  background:#0d1117;border:1px solid transparent;
  cursor:pointer;transition:border-color .15s;
}
.history-item:hover{border-color:#30363d}
.history-thumb{
  width:60px;height:34px;object-fit:cover;border-radius:3px;
  flex-shrink:0;background:#21262d;
}
.history-info{
  flex:1;min-width:0;display:flex;flex-direction:column;gap:1px;
}
.history-title{
  font-size:.8em;color:#c9d1d9;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
}
.history-date{font-size:.7em;color:#6e7681}
.history-del{
  background:none;border:none;color:#484f58;cursor:pointer;
  font-size:.9em;padding:3px 5px;border-radius:3px;flex-shrink:0;
  transition:color .15s,background .15s;
}
.history-del:hover{color:#f85149;background:#21262d}
.clear-btn{
  position:absolute;right:0;
  background:none;border:none;cursor:pointer;
  padding:6px;border-radius:4px;line-height:0;
  visibility:hidden;opacity:0;
  transition:background .15s,opacity .2s;
}
.clear-btn svg{width:20px;height:20px;fill:#484f58;transition:fill .15s}
.clear-btn:hover{background:#21262d}
.clear-btn:hover svg{fill:#f85149}
#history-section.hist-open .clear-btn{visibility:visible;opacity:1}

.footer{
  text-align:center;color:#484f58;font-size:.75em;margin-top:20px;
}
.keep-alive-btn{
  display:block;margin:8px auto 0;padding:6px 16px;
  background:none;border:1px solid #30363d;border-radius:6px;
  color:#8b949e;font-size:.72em;cursor:pointer;
  transition:all .2s;
}
.keep-alive-btn:hover{border-color:#58a6ff;color:#58a6ff}
.keep-alive-btn.active{border-color:#238636;color:#3fb950;background:#0d2818}

/* --- Tipos compatibles --- */
.compat{margin-top:2px;margin-bottom:4px;text-align:center}
.compat summary{
  display:inline-flex;align-items:center;gap:5px;
  font-size:.75em;color:#8b949e;cursor:pointer;
  list-style:none;user-select:none;
  border:1px solid #30363d;border-radius:20px;
  padding:4px 14px;
  transition:border-color .15s,color .15s;
}
.compat summary:hover{border-color:#444c56;color:#c9d1d9}
.compat summary::-webkit-details-marker{display:none}
.compat-chevron{width:11px;height:11px;fill:currentColor;transition:transform .2s;flex-shrink:0}
details[open].compat .compat-chevron{transform:rotate(180deg)}
.compat-list{
  margin-top:8px;display:flex;flex-wrap:wrap;justify-content:center;
  gap:4px 16px;font-size:.72em;color:#8b949e;
}
.compat-item{display:flex;align-items:center;gap:6px;padding:3px 0}
.compat-item .badge{margin-left:0;font-size:.9em}

/* --- EscaÌner de viÌdeos --- */
.btn-row{display:flex;gap:8px;margin-top:8px}
.btn-ghost{
  flex:1;display:flex;align-items:center;justify-content:center;
  padding:11px 12px;
  background:transparent;border:1px solid #373e47;border-radius:8px;
  color:#c9d1d9;font-size:.9em;font-weight:500;cursor:pointer;
  transition:background .15s,border-color .15s;
}
.btn-ghost:hover{background:#1c2128;border-color:#444c56}
.btn-ghost:active{transform:scale(.98)}
.btn-ghost:disabled{color:#484f58;border-color:#21262d;cursor:not-allowed}
.btn-ghost--tg:hover{border-color:#1e4d6e}
@media(max-width:360px){
  .btn-row{flex-direction:column}
  .btn-ghost{flex:none;width:100%}
}
.tg-hint{font-size:.72em;color:#6e7681;margin-top:6px;display:none}
.scan-results{margin-top:12px;display:none}
.scan-results.visible{display:block}
.scan-count{font-size:.8em;color:#8b949e;margin-bottom:6px}
.scan-list{list-style:none;max-height:300px;overflow-y:auto}
.scan-item{
  padding:10px 12px;margin-bottom:4px;border-radius:6px;
  background:#0d1117;border:1px solid transparent;
  cursor:pointer;transition:border-color .15s;
}
.scan-item:hover{border-color:#444c56}
.scan-item-title{font-size:.85em;color:#c9d1d9;font-weight:500}
.scan-item-meta{font-size:.72em;color:#8b949e;margin-top:2px}
</style>
</head>
<body>
<div class="card">
  <h1>EspaDaily Remote</h1>
  <p class="sub">Pega una dirección web para reproducirla en Kodi</p>

  <details class="compat" id="compat-details">
    <summary>
      <svg class="compat-chevron" viewBox="0 0 24 24"><path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/></svg>
      Enlaces compatibles
    </summary>
    <div class="compat-list">
      <div class="compat-item"><span class="badge youtube">YouTube</span> youtube.com, youtu.be</div>
      <div class="compat-item"><span class="badge dailymotion">Dailymotion</span> dailymotion.com</div>
      <div class="compat-item"><span class="badge twitch">Twitch</span> twitch.tv</div>
      <div class="compat-item"><span class="badge vimeo">Vimeo</span> vimeo.com</div>
      <div class="compat-item"><span class="badge stream">Stream</span> .m3u8, .mp4, .mpd</div>
      <div class="compat-item"><span class="badge torrent">Torrent</span> magnet:, .torrent</div>
      <div class="compat-item"><span class="badge acestream">AceStream</span> acestream://</div>
      <div class="compat-item"><span class="badge">Web</span> cualquier dirección web</div>
    </div>
  </details>

  <div class="status-bar">
    <span class="status-dot" id="dot"></span>
    <span id="status-text">Conectando...</span>
  </div>

  <label for="url">Dirección web del vídeo <span class="badge" id="badge"></span></label>
  <textarea class="drop-zone" id="url" placeholder="https://youtu.be/dQw4w9WgXcQ&#10;https://example.com/canal.m3u8&#10;magnet:?xt=urn:btih:...&#10;acestream://abcdef1234..." autofocus></textarea>
  <div class="preview-card" id="preview-card">
    <img class="preview-thumb" id="preview-thumb" src="" alt="">
    <div class="preview-info">
      <div class="preview-title" id="preview-title"></div>
      <div class="preview-author" id="preview-author"></div>
    </div>
  </div>
  <button class="btn-primary" id="send" onclick="enviar()">Enviar a Kodi</button>
  <div class="btn-row">
    <button class="btn-ghost" id="scan-btn" onclick="escanear()">Escanear web</button>
    <button class="btn-ghost btn-ghost--tg" id="scan-tg-btn" onclick="escanearTelegram()">Canal Telegram</button>
  </div>
  <div class="tg-hint" id="tg-hint">Solo canales públicos: @canal o t.me/canal</div>
  <div class="msg" id="msg"></div>
  <div class="scan-results" id="scan-results">
    <div class="scan-count" id="scan-count"></div>
    <ul class="scan-list" id="scan-list"></ul>
  </div>

  <div class="controls" id="controls">
    <button class="ctrl-btn" onclick="ctrl('voldown')" title="Vol -">
      <svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3z"/></svg>
    </button>
    <span class="vol-label" id="vol">--</span>
    <button class="ctrl-btn" onclick="ctrl('volup')" title="Vol +">
      <svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0012 7.5v9a4.5 4.5 0 004.5-4.5z"/></svg>
    </button>
    <div style="width:12px"></div>
    <button class="ctrl-btn" onclick="ctrl('playpause')" title="Play / Pausa" id="pp-btn">
      <svg viewBox="0 0 24 24" id="pp-icon"><polygon points="5,3 19,12 5,21"/></svg>
    </button>
    <button class="ctrl-btn" onclick="ctrl('stop')" title="Stop">
      <svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="1"/></svg>
    </button>
  </div>
  <div class="now-playing" id="np"></div>
  <div class="progress-container" id="progress-container">
    <div class="progress-times">
      <span id="p-cur">00:00:00</span>
      <span id="p-tot">00:00:00</span>
    </div>
    <input type="range" class="progress-bar" id="progress-bar" min="0" max="100" step="0.1" value="0"
      oninput="this.dataset.seeking='1'" onchange="seekTo(this.value);this.dataset.seeking=''">
  </div>

  <div class="history" id="history-section">
    <div class="history-header" onclick="toggleHistory()">
      <span>
        <svg class="hist-icon" viewBox="0 0 24 24"><path d="M13 3a9 9 0 0 0-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42A8.954 8.954 0 0 0 13 21a9 9 0 0 0 0-18zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"/></svg>
        Historial
        <svg class="arrow" id="arrow" viewBox="0 0 24 24"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg>
      </span>
      <button class="clear-btn" onclick="event.stopPropagation();clearHistory()" title="Limpiar historial">
        <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
      </button>
    </div>
    <ul class="history-list hidden" id="history-list"></ul>
  </div>

  <p class="footer" id="footer-msg">El servidor se cerrará automáticamente tras recibir la dirección.</p>
  <button class="keep-alive-btn" id="keep-alive-btn" onclick="toggleKeepAlive()">Mantener servidor abierto</button>
  <p style="text-align:center;color:#484f58;font-size:.7em;margin-top:8px">Concepto: RubenSDFA1laberot</p>
</div>
<script>
/* --- Deteccion de tipo --- */
var TYPE_MAP=[
  [/youtu\\.?be|youtube/i,'YouTube','youtube'],
  [/dailymotion|dai\\.ly/i,'Dailymotion','dailymotion'],
  [/twitch\\.tv/i,'Twitch','twitch'],
  [/vimeo\\.com/i,'Vimeo','vimeo'],
  [/^magnet:\\?|\\.torrent(\\?|$)/i,'Torrent','torrent'],
  [/^acestream:\\/\\//i,'AceStream','acestream'],
  [/^[0-9a-fA-F]{40}$/,'AceStream','acestream'],
  [/\\.m3u8|\\.mpd|\\.mp4|\\.mkv|\\.avi|\\.ts|\\.flv|\\.webm|\\.mov/i,'Stream','stream']
];
function detectType(u){
  for(var i=0;i<TYPE_MAP.length;i++){
    if(TYPE_MAP[i][0].test(u)) return {label:TYPE_MAP[i][1],cls:TYPE_MAP[i][2]};
  }
  return u?{label:'Web',cls:''}:null;
}
var urlEl=document.getElementById('url');
var badgeEl=document.getElementById('badge');
function updateBadge(){
  var t=detectType(urlEl.value.trim());
  if(t){badgeEl.textContent=t.label;badgeEl.className='badge '+t.cls;}
  else{badgeEl.textContent='';badgeEl.className='badge';}
}
urlEl.addEventListener('input',updateBadge);

/* --- Drag & drop --- */
urlEl.addEventListener('dragover',function(e){
  e.preventDefault();urlEl.classList.add('dragover');
});
urlEl.addEventListener('dragleave',function(){
  urlEl.classList.remove('dragover');
});
urlEl.addEventListener('drop',function(e){
  e.preventDefault();urlEl.classList.remove('dragover');
  var text=e.dataTransfer.getData('text/uri-list')||e.dataTransfer.getData('text/plain')||'';
  if(text){urlEl.value=text.split('\\n')[0].trim();updateBadge();}
});

/* --- Auto-paste --- */
(function(){
  var done=false;
  urlEl.addEventListener('focus',function(){
    if(done||urlEl.value.trim()) return;
    done=true;
    if(navigator.clipboard&&navigator.clipboard.readText){
      navigator.clipboard.readText().then(function(t){
        t=t.trim();
        if(t&&(/^(https?:\\/\\/|magnet:\\?|acestream:\\/\\/)/i.test(t)||/^[0-9a-fA-F]{40}$/.test(t))&&!urlEl.value.trim()){
          urlEl.value=t;updateBadge();
        }
      }).catch(function(){});
    }
  });
})();

/* --- Historial (sincronizado con servidor) --- */
function fetchHistory(){
  fetch('/history').then(function(r){return r.json()}).then(function(d){
    renderHistory(d.history||[]);
  }).catch(function(){renderHistory([]);});
}
function renderHistory(h){
  var list=document.getElementById('history-list');
  list.innerHTML='';
  if(!h.length){
    document.getElementById('history-section').style.display='none';
    return;
  }
  document.getElementById('history-section').style.display='';
  h.forEach(function(item){
    var u=typeof item==='string'?item:item.url;
    var label=(item.label&&item.label!==u)?item.label:u;
    var thumb=item.thumb||'';
    var date=item.date||'';
    var li=document.createElement('li');
    li.className='history-item';
    li.title=u;
    if(thumb){
      var img=document.createElement('img');
      img.src=thumb;img.className='history-thumb';
      img.onerror=function(){this.style.display='none';};
      li.appendChild(img);
    }
    var info=document.createElement('div');
    info.className='history-info';
    var titleEl=document.createElement('span');
    titleEl.className='history-title';
    titleEl.textContent=label.length>70?label.slice(0,67)+'...':label;
    info.appendChild(titleEl);
    if(date){
      var dateEl=document.createElement('span');
      dateEl.className='history-date';dateEl.textContent=date;
      info.appendChild(dateEl);
    }
    li.appendChild(info);
    var del=document.createElement('button');
    del.className='history-del';del.textContent='âœ•';del.title='Eliminar';
    del.onclick=function(e){
      e.stopPropagation();
      fetch('/history/remove',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({url:u})}).then(function(){fetchHistory();}).catch(function(){});
    };
    li.appendChild(del);
    li.onclick=function(){urlEl.value=u;updateBadge();urlEl.focus();};
    list.appendChild(li);
  });
}
function toggleHistory(){
  var list=document.getElementById('history-list');
  var arrow=document.getElementById('arrow');
  var hidden=list.classList.toggle('hidden');
  arrow.classList.toggle('open',!hidden);
  document.getElementById('history-section').classList.toggle('hist-open',!hidden);
}
function clearHistory(){
  fetch('/history/clear',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})
  .then(function(){fetchHistory();}).catch(function(){});
}
fetchHistory();

/* --- Keep-alive --- */
var keepAlive=false;
function toggleKeepAlive(){
  fetch('/toggle-keep-alive',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})
  .then(function(r){return r.json();})
  .then(function(d){
    keepAlive=d.keepAlive;
    var btn=document.getElementById('keep-alive-btn');
    var footer=document.getElementById('footer-msg');
    if(keepAlive){
      btn.textContent='Servidor fijado (click para cerrar tras envio)';
      btn.classList.add('active');
      footer.textContent='El servidor permanecera abierto. Puedes enviar varias URLs.';
    }else{
      btn.textContent='Mantener servidor abierto';
      btn.classList.remove('active');
      footer.textContent='El servidor se cerrara automaticamente tras recibir la URL.';
    }
  });
}

/* --- Enviar --- */
function checkSVG(){
  return '<svg class="check-svg" viewBox="0 0 24 24">'
    +'<circle cx="12" cy="12" r="10"/>'
    +'<path d="M7 12.5l3 3 7-7"/></svg>';
}
function enviar(){
  var url=urlEl.value.trim();
  var msg=document.getElementById('msg');
  var btn=document.getElementById('send');
  msg.className='msg';msg.style.display='none';
  if(!url){
    msg.className='msg err';msg.textContent='Escribe una URL';msg.style.display='block';
    return;
  }
  if(!/^(https?|rtmp|rtsp):\\/\\//i.test(url)&&!/^magnet:\\?/i.test(url)&&!/^acestream:\\/\\//i.test(url)&&!/^[0-9a-fA-F]{40}$/.test(url)){
    msg.className='msg err';msg.textContent='Esquemas soportados: http, magnet, acestream';msg.style.display='block';
    return;
  }
  btn.disabled=true;btn.textContent='Enviando...';
  fetch('/send',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({url:url})
  })
  .then(function(r){return r.json()})
  .then(function(d){
    if(d.ok){
      msg.className='msg ok';
      msg.innerHTML=checkSVG()+'<span>URL enviada a Kodi</span>';
      fetchHistory();
      setTimeout(function(){btn.disabled=false;btn.textContent='Enviar a Kodi';urlEl.value='';updateBadge();msg.className='msg';msg.style.display='none';document.getElementById('preview-card').className='preview-card';},1800);
    }else{
      msg.className='msg err';
      msg.textContent=d.error||'Error desconocido';
      btn.disabled=false;btn.textContent='Enviar a Kodi';
    }
    msg.style.display='';
  })
  .catch(function(){
    msg.className='msg err';
    msg.textContent='Error de conexion con Kodi';
    msg.style.display='block';
    btn.disabled=false;btn.textContent='Enviar a Kodi';
  });
}
urlEl.addEventListener('keydown',function(e){
  if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();enviar()}
});

/* --- Escanear videos --- */
function escanear(){
  var url=urlEl.value.trim();
  var msg=document.getElementById('msg');
  var scanBtn=document.getElementById('scan-btn');
  var scanResults=document.getElementById('scan-results');
  var scanList=document.getElementById('scan-list');
  var scanCount=document.getElementById('scan-count');
  msg.className='msg';msg.style.display='none';
  scanResults.className='scan-results';
  if(!url){
    msg.className='msg err';msg.textContent='Escribe una URL para escanear';msg.style.display='block';
    return;
  }
  if(!/^https?:\\/\\//i.test(url)){
    msg.className='msg err';msg.textContent='Solo URLs http:// o https://';msg.style.display='block';
    return;
  }
  scanBtn.disabled=true;scanBtn.textContent='Escaneando...';
  fetch('/scan',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({url:url})
  })
  .then(function(r){return r.json()})
  .then(function(d){
    scanBtn.disabled=false;scanBtn.textContent='Escanear';
    if(!d.ok||!d.videos||!d.videos.length){
      msg.className='msg err';msg.textContent='No se encontraron videos en esta pagina';msg.style.display='block';
      return;
    }
    scanCount.textContent=d.count+' video'+(d.count===1?'':'s')+' encontrado'+(d.count===1?'':'s');
    scanList.innerHTML='';
    d.videos.forEach(function(v){
      var li=document.createElement('li');
      li.className='scan-item';
      var title=document.createElement('div');
      title.className='scan-item-title';
      title.textContent=v.title||v.url;
      li.appendChild(title);
      var meta=[];
      if(v.duration) meta.push(v.duration);
      if(v.filesize) meta.push(v.filesize);
      if(v.ext) meta.push(v.ext.toUpperCase());
      if(meta.length){
        var metaEl=document.createElement('div');
        metaEl.className='scan-item-meta';
        metaEl.textContent=meta.join(' - ');
        li.appendChild(metaEl);
      }
      li.onclick=function(){sendVideo(v.url,v.title)};
      scanList.appendChild(li);
    });
    scanResults.className='scan-results visible';
  })
  .catch(function(){
    scanBtn.disabled=false;scanBtn.textContent='Escanear';
    msg.className='msg err';msg.textContent='Error de conexion al escanear';msg.style.display='block';
  });
}
function escanearTelegram(){
  var url=urlEl.value.trim();
  var msg=document.getElementById('msg');
  var tgBtn=document.getElementById('scan-tg-btn');
  var scanResults=document.getElementById('scan-results');
  var scanList=document.getElementById('scan-list');
  var scanCount=document.getElementById('scan-count');
  var hint=document.getElementById('tg-hint');
  msg.className='msg';msg.style.display='none';
  scanResults.className='scan-results';
  hint.style.display='block';
  if(!url){
    msg.className='msg err';msg.textContent='Escribe @canal o t.me/canal';msg.style.display='block';
    return;
  }
  tgBtn.disabled=true;tgBtn.textContent='Escaneando...';
  fetch('/scan-telegram',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({url:url})
  })
  .then(function(r){return r.json()})
  .then(function(d){
    tgBtn.disabled=false;tgBtn.textContent='Canal Telegram';
    if(!d.ok||!d.videos||!d.videos.length){
      msg.className='msg err';
      msg.textContent='No se encontraron contenidos. Comprueba que el canal es público.';
      msg.style.display='block';
      return;
    }
    scanCount.textContent=d.count+' elemento'+(d.count===1?'':'s')+' encontrado'+(d.count===1?'':'s')+' en Telegram';
    scanList.innerHTML='';
    d.videos.forEach(function(v){
      var li=document.createElement('li');
      li.className='scan-item';
      var title=document.createElement('div');
      title.className='scan-item-title';
      title.textContent=v.title||v.url;
      li.appendChild(title);
      var meta=[];
      if(v.duration) meta.push(v.duration);
      if(v.filesize) meta.push(v.filesize);
      if(v.ext) meta.push(v.ext.toUpperCase());
      if(meta.length){
        var metaEl=document.createElement('div');
        metaEl.className='scan-item-meta';
        metaEl.textContent=meta.join(' - ');
        li.appendChild(metaEl);
      }
      li.onclick=function(){sendVideo(v.url,v.title)};
      scanList.appendChild(li);
    });
    scanResults.className='scan-results visible';
  })
  .catch(function(){
    tgBtn.disabled=false;tgBtn.textContent='Canal Telegram';
    msg.className='msg err';msg.textContent='Error de conexion al escanear Telegram';msg.style.display='block';
  });
}
function sendVideo(videoUrl,title){
  var msg=document.getElementById('msg');
  fetch('/send',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({url:videoUrl})
  })
  .then(function(r){return r.json()})
  .then(function(d){
    if(d.ok){
      msg.className='msg ok';
      msg.innerHTML=checkSVG()+'<span></span>';
      msg.querySelector('span').textContent=(title||'Video')+' enviado a Kodi';
      msg.style.display='';
      fetchHistory();
    }
  })
  .catch(function(){});
}

/* --- Controles remotos --- */
function ctrl(action){
  fetch('/control',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:action})
  }).catch(function(){});
  if(action==='playpause'||action==='stop') setTimeout(pollStatus,300);
}

/* --- Preview oEmbed --- */
var _previewTimer=null;
var _previewAbort=null;
function requestPreview(url){
  var card=document.getElementById('preview-card');
  var thumb=document.getElementById('preview-thumb');
  var ptitle=document.getElementById('preview-title');
  var pauthor=document.getElementById('preview-author');
  if(!url||url.length<10){
    card.className='preview-card';return;
  }
  // Skeleton loader
  card.className='preview-card loading visible';
  thumb.src='';thumb.className='preview-thumb preview-skeleton preview-skeleton-thumb';
  ptitle.textContent='';ptitle.className='preview-title preview-skeleton preview-skeleton-text';
  ptitle.innerHTML=' ';
  pauthor.textContent='';pauthor.className='preview-author preview-skeleton preview-skeleton-text2';
  pauthor.innerHTML=' ';
  // Abort previous
  if(_previewAbort)try{_previewAbort.abort();}catch(e){}
  _previewAbort=new AbortController();
  fetch('/preview',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({url:url}),signal:_previewAbort.signal
  }).then(function(r){return r.json()}).then(function(d){
    if(d.ok&&d.preview){
      thumb.src=d.preview.thumbnail||'';
      thumb.className='preview-thumb';
      ptitle.textContent=d.preview.title||'';
      ptitle.className='preview-title';
      pauthor.textContent=d.preview.author?(d.preview.author+' • '+d.preview.provider):(d.preview.provider||'');
      pauthor.className='preview-author';
      card.className='preview-card visible';
    }else{
      card.className='preview-card';
    }
  }).catch(function(){
    card.className='preview-card';
  });
}
function debouncePreview(){
  clearTimeout(_previewTimer);
  _previewTimer=setTimeout(function(){
    var url=document.getElementById('url').value.trim();
    if(/^https?:\\/\\//i.test(url)) requestPreview(url);
    else document.getElementById('preview-card').className='preview-card';
  },400);
}
urlEl.addEventListener('input',debouncePreview);
urlEl.addEventListener('paste',function(){setTimeout(debouncePreview,50);});

/* --- Estado (SSE con fallback a polling) --- */
var ppIcon=document.getElementById('pp-icon');
var PLAY_PATH='<polygon points="5,3 19,12 5,21"/>';
var PAUSE_PATH='<rect x="5" y="4" width="4" height="16" rx="1"/><rect x="15" y="4" width="4" height="16" rx="1"/>';
var _pollTimer=null;
function updateStatus(s){
  var dot=document.getElementById('dot');
  var stxt=document.getElementById('status-text');
  var np=document.getElementById('np');
  var vol=document.getElementById('vol');
  var pC=document.getElementById('progress-container');
  var pBar=document.getElementById('progress-bar');
  var pCur=document.getElementById('p-cur');
  var pTot=document.getElementById('p-tot');
  dot.classList.add('on');
  if(s.playing){
    stxt.textContent=s.paused?'Pausado':'Reproduciendo';
    np.textContent=s.title||'';
    ppIcon.innerHTML=s.paused?PLAY_PATH:PAUSE_PATH;
    pC.classList.add('visible');
    if(!pBar.dataset.seeking){pBar.value=s.percentage||0;}
    pCur.textContent=s.time||'00:00:00';
    pTot.textContent=s.totaltime||'00:00:00';
  }else{
    stxt.textContent='Sin reproduccion';
    np.textContent='';
    ppIcon.innerHTML=PLAY_PATH;
    pC.classList.remove('visible');
  }
  var v=s.volume;vol.textContent=(v!=null)?(s.muted?'\U0001f507':v+'%'):'--';
}
function pollStatus(){
  fetch('/status').then(function(r){return r.json()}).then(updateStatus)
  .catch(function(){
    document.getElementById('dot').classList.remove('on');
    document.getElementById('status-text').textContent='Sin conexion';
  });
}
function startSSE(){
  if(typeof EventSource==='undefined'){startPolling();return;}
  var es=new EventSource('/events');
  es.onmessage=function(e){
    try{updateStatus(JSON.parse(e.data));}catch(err){}
  };
  es.onerror=function(){
    es.close();
    startPolling();
  };
}
function startPolling(){
  pollStatus();
  _pollTimer=setInterval(pollStatus,3000);
}
function seekTo(pct){
  fetch('/control',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'seek',value:parseFloat(pct)})
  });
}
startSSE();
</script>
</body>
</html>"""

# HTML embebido (pagina texto)

_HTML_TEXT = """<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<title>EspaDaily Remote</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  background:#0d1117;color:#c9d1d9;
  min-height:100vh;display:flex;align-items:center;justify-content:center;
  padding:16px;
}
.card{
  background:#161b22;border:1px solid #30363d;border-radius:12px;
  padding:32px 24px;max-width:480px;width:100%;
  box-shadow:0 8px 32px rgba(0,0,0,.4);
}
h1{
  font-size:1.4em;text-align:center;margin-bottom:6px;
  color:#e6edf3;font-weight:600;
}
.sub{
  text-align:center;color:#8b949e;font-size:.85em;margin-bottom:24px;
}
label{
  display:block;font-size:.9em;color:#8b949e;margin-bottom:6px;
}
input[type=text]{
  width:100%;padding:14px 12px;
  background:#0d1117;color:#c9d1d9;
  border:1px solid #30363d;border-radius:8px;
  font-size:16px;outline:none;
  transition:border-color .2s;
}
input[type=text]:focus{border-color:#58a6ff}
input[type=text]::placeholder{color:#484f58}
.btn{
  display:block;width:100%;padding:14px;margin-top:16px;
  background:#1f6feb;color:#fff;
  border:none;border-radius:8px;
  font-size:1em;font-weight:600;cursor:pointer;
  transition:background .2s;
}
.btn:hover{background:#388bfd}
.btn:active{background:#1f6feb;transform:scale(.98)}
.btn:disabled{background:#21262d;color:#484f58;cursor:not-allowed}
.msg{
  margin-top:14px;padding:10px 14px;border-radius:8px;
  font-size:.9em;text-align:center;display:none;
}
.msg.ok{display:flex;align-items:center;justify-content:center;gap:8px;background:#0d2818;color:#3fb950;border:1px solid #238636}
.msg.err{display:block;background:#2d1117;color:#f85149;border:1px solid #da3633}
.check-svg{width:20px;height:20px;flex-shrink:0}
.check-svg circle{stroke:#3fb950;stroke-width:2;fill:none;stroke-dasharray:52;stroke-dashoffset:52;animation:circ .4s ease forwards}
.check-svg path{stroke:#3fb950;stroke-width:2;fill:none;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:20;stroke-dashoffset:20;animation:tick .3s .35s ease forwards}
@keyframes circ{to{stroke-dashoffset:0}}
@keyframes tick{to{stroke-dashoffset:0}}
.footer{
  text-align:center;color:#484f58;font-size:.75em;margin-top:20px;
}
</style>
</head>
<body>
<div class="card">
  <h1>EspaDaily Remote</h1>
  <p class="sub">Escribe texto para enviarlo a Kodi</p>
  <input type="text" id="txt" placeholder="Escribe aqui..." autofocus>
  <button class="btn" id="send" onclick="enviar()">Enviar a Kodi</button>
  <div class="msg" id="msg"></div>
  <p class="footer">El servidor se cerrara automaticamente tras recibir el texto.</p>
  <p style="text-align:center;color:#484f58;font-size:.7em;margin-top:8px">Concepto: RubenSDFA1laberot</p>
</div>
<script>
function checkSVG(){
  return '<svg class="check-svg" viewBox="0 0 24 24">'
    +'<circle cx="12" cy="12" r="10"/>'
    +'<path d="M7 12.5l3 3 7-7"/></svg>';
}
function enviar(){
  var txt=document.getElementById('txt').value.trim();
  var msg=document.getElementById('msg');
  var btn=document.getElementById('send');
  msg.className='msg';msg.style.display='none';
  if(!txt){
    msg.className='msg err';msg.textContent='Escribe algo';msg.style.display='block';
    return;
  }
  btn.disabled=true;btn.textContent='Enviando...';
  fetch('/send',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({text:txt})
  })
  .then(function(r){return r.json()})
  .then(function(d){
    if(d.ok){
      msg.className='msg ok';
      msg.innerHTML=checkSVG()+'<span>Texto enviado a Kodi</span>';
      btn.textContent='Enviado';
    }else{
      msg.className='msg err';
      msg.textContent=d.error||'Error desconocido';
      btn.disabled=false;btn.textContent='Enviar a Kodi';
    }
    msg.style.display='';
  })
  .catch(function(){
    msg.className='msg err';
    msg.textContent='Error de conexion con Kodi';
    msg.style.display='block';
    btn.disabled=false;btn.textContent='Enviar a Kodi';
  });
}
document.getElementById('txt').addEventListener('keydown',function(e){
  if(e.key==='Enter'){e.preventDefault();enviar()}
});
</script>
</body>
</html>"""
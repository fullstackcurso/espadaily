import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import re

try:
    import requests
except ImportError:
    requests = None

try:
    import requests
except ImportError:
    requests = None

try:
    import json
    import os
    import xbmcvfs
except ImportError:
    pass

import base64
_d = lambda s: base64.b64decode(s).decode()
import core_settings

class PluginTools:
    def get_params(self):
        return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

    def add_item(self, action="", title="", thumbnail="", fanart="", url="", plot="", folder=True, isPlayable=False, page="", main_action=None, show_title="", context_pass=False):
        base_url = sys.argv[0]
        
        # Determina el contexto para el siguiente nivel
        # Si estamos navegando por carpetas (context_pass=True), añadimos el título actual al contexto
        # Si somos un nodo hoja o solo mostramos, no añadimos, pero pasamos lo que tenemos
        
        next_context = show_title
        if context_pass and title:
             clean_t = title.replace('[B]', '').replace('[/B]', '').strip()
             if next_context:
                 next_context += "||" + clean_t
             else:
                 next_context = clean_t
        
        if main_action:
            # Construcción final de la consulta de búsqueda
            q = self._build_query(url, show_title) if main_action == "lfr" else url
            params = {
                "action": main_action,
                "q": q, 
                "ot": thumbnail
            }
        else:
            # Enrutamiento interno
            params = {
                "action": "rtve_ext_router",
                "rtve_action": action,
                "url": url,
                "thumbnail": thumbnail,
                "title": title,
                "page": page,
                "show_title": next_context
            }
        
        # Filtrar parámetros vacíos
        params = {k: v for k, v in params.items() if v}
        
        u = base_url + "?" + urllib.parse.urlencode(params)
        
        li = xbmcgui.ListItem(label=title)
        if thumbnail: li.setArt({'icon': thumbnail, 'thumb': thumbnail})
        if fanart: li.setArt({'fanart': fanart})
        if plot: li.setInfo('video', {'plot': plot})
        
        if isPlayable:
            li.setProperty('IsPlayable', 'true')
        
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=folder)

    def _build_query(self, title_or_query, context_title):
        return core_settings.build_query(title_or_query, context_title)

    def close_item_list(self):
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    def find_single_match(self, data, pattern):
        if not data: return ""
        match = re.search(pattern, data, flags=re.DOTALL)
        if match:
            if len(match.groups()) > 1:
                return match.groups()
            return match.group(1)
        return ""

    def find_multiple_matches(self, data, pattern):
        if not data: return []
        return re.findall(pattern, data, flags=re.DOTALL)

    def read_body_and_headers(self, url, headers=None):
        if not requests: return "", {}
        h = {}
        if headers:
            for k, v in headers: h[k] = v
        if not h:
            h = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"}
            
        try:
            r = requests.get(url, headers=h, verify=False, timeout=10)
            return r.content.decode('utf-8', 'ignore'), r.headers
        except:
            return "", {}

plugintools = PluginTools()
addon = xbmcaddon.Addon()

def main_list(params):
    plugintools.add_item(action="tve_buscador", title="[B]Buscador[/B]", folder=True)
    plugintools.add_item(action="tve_todos", title="[B]Completa[/B]", folder=True, url= _d("aHR0cHM6Ly93d3cucnR2ZS5lcy9wbGF5L2Etei8="))
    plugintools.add_item(action="tve_informativos", title="[B]Informativos[/B]", folder=True, url= _d("aHR0cHM6Ly93d3cucnR2ZS5lcy9wbGF5L2luZm9ybWF0aXZvcy8="))
    plugintools.add_item(action="tve_informativos", title="[B]Cine[/B]", folder=True, url= _d("aHR0cHM6Ly93d3cucnR2ZS5lcy9wbGF5L2NpbmUv"))
    plugintools.add_item(action="tve_informativos", title="[B]Series[/B]", folder=True, url= _d("aHR0cHM6Ly93d3cucnR2ZS5lcy9wbGF5L3Nlcmllcy8="))
    plugintools.add_item(action="tve_todos", title="[B]Crímenes[/B]", folder=True, url= _d("aHR0cHM6Ly93d3cucnR2ZS5lcy9wbGF5L2NvbGVjY2lvbmVzL3RydWUtY3JpbWUvMTc3MC8="))
    plugintools.add_item(action="secciones_tve", title="[B]Archivo[/B]", folder=True, url= _d("aHR0cHM6Ly93d3cucnR2ZS5lcy9wbGF5L2FyY2hpdm8v"))
    plugintools.add_item(action="tve_informativos", title="[B]Entretenimiento[/B]", folder=True, url= _d("aHR0cHM6Ly93d3cucnR2ZS5lcy9wbGF5L2VudHJldGVuaW1pZW50by8="))
    plugintools.add_item(action="tve_informativos", title="[B]Eurovision[/B]", folder=True, url= _d("aHR0cHM6Ly93d3cucnR2ZS5lcy9wbGF5L2V1cm92aXNpb24v"))
    plugintools.add_item(action="tve_informativos", title="[B]Playz[/B]", folder=True, url= _d("aHR0cHM6Ly93d3cucnR2ZS5lcy9wbGF5L3BsYXl6Lw=="))
    plugintools.add_item(action="seriesclan", title="[B]Infantil (Clan)[/B]", folder=True, url= _d("aHR0cHM6Ly93d3cucnR2ZS5lcy9kcm1uL2NhdGFsb2ctY2F0ZWdvcnkvP3BhZ2U9MSZjb2xUPTQmY29sTT0yJnNpemU9MTgmc2l6ZVQ9MTgmc2l6ZU09MTEmZXhUPU4mZXhNPU4mdGlwb3BhZz0wJnRwVD0wJnRwTT0wJnByb2d0aXRsZT1TJmN0eD1JTkYmY3NlbD0xJm4xPVRvZG9zJmMxPU5OJmkxPTAmdDE9UFJPJmYxPU4mbzE9RlAmZTEmcTE9aW5QdWJUYXJnZXQlMjUzRElORkFOVElMJTI1MjZsYW5nJTI1M0RlcyUyNTI2b3JkZXIlMjUzRHByb2dyYW1fb3JkZW4lMjUyQ2FzYyZkZT1OJmxsPU4mc3R0PVMmZmFrZUltZz1TJmNvbD00JnI9L2luZmFudGlsL3Nlcmllcy8="))
    
    plugintools.close_item_list()

def tve_buscador(params):
    dialog = xbmcgui.Dialog()
    d = dialog.input('Buscar:', type=xbmcgui.INPUT_ALPHANUM).replace(" ", "%2520")
    if not d: return
    
    url = _d("aHR0cHM6Ly9hcGkucnR2ZS5lcy9hcGkvc2VhcmNoL3Byb2dyYW1zP3NlYXJjaD0=") + d + '&page=1&size=50&context=tve&isExpanded=true&isChild=true&useOntology=true'
    if not requests: return
    r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, verify=False)
    data = r.text
    
    matches = plugintools.find_multiple_matches(data, r'"htmlShortUrl":"https://www.rtve.es/pr/.*?"htmlUrl":".*?".*?"imageSEO":".*?".*?longDescription":"<p>.*?<.*?"name":".*?".*?')
    for generos in matches:
        patron = plugintools.find_single_match(generos, r'"htmlShortUrl":"https://www.rtve.es/pr/.*?"htmlUrl":"(.*?)".*?"imageSEO":"(.*?)".*?"imgPortada":"(.*?)".*?longDescription":"<p>(.*?)<.*?"name":"(.*?)".*?')
        
        if len(patron) < 5: continue
        
        url_target = patron[0]
        foto = patron[1]
        foto2 = patron[2]
        texto = patron[3]
        titulo = patron[4].replace("#8211;", "")
        
        plugintools.add_item(action="series_tve_temporada", plot=texto, url=url_target, title="[B]"+titulo+"[/B]", thumbnail=foto, fanart=foto2, folder=True, show_title=titulo)
        
    plugintools.close_item_list()

def tve_informativos(params):
    url = params.get("url")
    body, _ = plugintools.read_body_and_headers(url)
    
    matches = plugintools.find_multiple_matches(body, r'<div class="secBox">\n.*?<strong>\n.*?<a href="https://www.rtve.es/play/colecciones.*?".*?\n.*?\s*.*?\s*</a>')
    
    for generos in matches:
        patron = plugintools.find_single_match(generos, r'<div class="secBox">\n.*?<strong>\n.*?<a href="(https://www.rtve.es/play/colecciones.*?)".*?\n.*?\s*(.*?)\s*</a>')
        if not patron: continue
        
        ide = patron[0]
        titulo = patron[1]
        thumbnail = params.get("thumbnail")
        plugintools.add_item(action="series_tve_series", url=ide, title="[B]"+titulo+"[/B]", thumbnail=thumbnail, folder=True, show_title=titulo)
        
    plugintools.close_item_list()

def tve_todos(params):
    url = params.get("url") + '?criteria=ASC&order=1&pageSize=40'
    body, _ = plugintools.read_body_and_headers(url)
    
    matches = plugintools.find_multiple_matches(body, r'(?s)<li class="elem_nV.*?.*?<a href=".*?".*?class="maintitle">.*?<.*?<p>.*?<.*?src=".*?".*?alt=".*?".*?src="https://img2.rtve.es/p/.*?".*?')
    
    for generos in matches:
        patron = plugintools.find_single_match(generos, r'(?s)<li class="elem_nV.*?.*?<a href="(.*?)".*?class="maintitle">(.*?)<.*?<p>(.*?)<.*?src=".*?".*?alt=".*?".*?src="(https://img2.rtve.es/p/.*?)".*?')
        if not patron: continue
        
        url_target = patron[0]
        titulo = patron[1]
        texto = patron[2]
        foto = patron[3].replace('amp;','')
        
        plugintools.add_item(action="series_tve_temporada", url=url_target, plot=texto, title="[B]"+titulo+"[/B]", thumbnail=foto, fanart=foto, folder=True, show_title=show_title, context_pass=True)

    plugintools.close_item_list()

def secciones_tve(params):
    url = params.get("url")
    body, _ = plugintools.read_body_and_headers(url)
    
    matches = plugintools.find_multiple_matches(body, r'<a href="https://www.rtve.es/play/colecciones/.*?".*? >\s*.*?\s*<')
    for generos in matches:
        url = plugintools.find_single_match(generos,r'<a href="(https://www.rtve.es/play/colecciones/.*?)".*? >\s*.*?\s*<').replace("&amp;", "&")
        titulo = plugintools.find_single_match(generos,r'<a href="https://www.rtve.es/play/colecciones/.*?".*? >\s*(.*?)\s*<')
        plugintools.add_item(action = "series_tve_series" , title ="[B]"+titulo+"[/B]" ,url =url, folder = True, show_title=titulo, context_pass=True)
    plugintools.close_item_list()

def series_tve_series(params):
    url = params.get("url")
    show_title = params.get("show_title") or params.get("title") or ""
    
    body, _ = plugintools.read_body_and_headers(url)
    
    if 'class="mod serie_mod tve' in body:
        matches = plugintools.find_multiple_matches(body, r'(?s)class="mod serie_mod tve">.*?<a href=".*?".*?class="maintitle">.*?<.*?src=".*?".*?src=".*?".*?alt=".*?".*?')
        for generos in matches:
            patron = plugintools.find_single_match(generos, r'(?s)class="mod serie_mod tve">.*?<a href="(.*?)".*?class="maintitle">.*?<.*?src="(.*?)".*?src="(.*?)".*?alt="(.*?)".*?')
            if not patron: continue
            url5, foto, foto2, titulo = patron[0], patron[1], patron[2], patron[3]
            plugintools.add_item(action="series_tve_temporada", title="[B]"+titulo+"[/B]", url=url5, thumbnail=foto2, fanart=foto, folder=True, show_title=show_title, context_pass=True)
    else:
        matches = plugintools.find_multiple_matches(body, r'<div class="cellBox"><div class="mod video_mod"><a href=".*?".*?class="pretitle">.*?<.*?class="maintitle">.*?<.*?</strong><p>.*?<.*?src=".*?".*?')
        for generos in matches:
            patron = plugintools.find_single_match(generos, r'<div class="cellBox"><div class="mod video_mod"><a href="(.*?)".*?class="pretitle">(.*?)<.*?class="maintitle">(.*?)<.*?</strong><p>(.*?)<.*?src="(.*?)".*?')
            if not patron: continue
            url5, titulo, texto, foto = patron[0], patron[2], patron[3], patron[4]
            # Usar título simple, add_item manejará el contexto basado en la configuración
            plugintools.add_item(main_action="lfr", title="[B]"+titulo+"[/B]", url=titulo, plot=texto, thumbnail=foto, fanart=foto, folder=True, show_title=show_title)
            
    plugintools.close_item_list()

def series_tve_temporada(params):
    url = params.get("url")
    show_title = params.get("show_title") or params.get("title") or ""
    
    body, _ = plugintools.read_body_and_headers(url)
    
    page = plugintools.find_single_match(body, r'data-tab="capters"   >.*?data-module="(/play/videos/modulos.*?)"')
    if page:
        url = 'https://www.rtve.es' + page
        body, _ = plugintools.read_body_and_headers(url)
    
    if 'Seleccionar temporada' in body:
        matches = plugintools.find_multiple_matches(body, r'(?s)data-season=".*?" data-order=".*?<a href=".*?"><span>.*?</span>')
        for generos in matches:
             url_target = plugintools.find_single_match(generos, r'(?s)data-season=".*?" data-order=".*?<a href="(.*?)"><span>.*?</span>')
             # El título aquí es solo "Temporada X". Queremos mantener el contexto show_title.
             titulo = plugintools.find_single_match(generos, r'(?s)data-season=".*?" data-order=".*?<a href=".*?"><span>(.*?)</span>')
             plugintools.add_item(action="series_tve_capitulos", url=url_target, title="[B]"+titulo+"[/B]", folder=True, show_title=show_title)
    else:
        matches = plugintools.find_multiple_matches(body, r'(?s)li class="elem_nH getoff.*?"imagen": ".*?".*?class="maintitle">.*?<.*?<.*?href="https://www.rtve.es/play/videos/.*?"')
        for generos in matches:
            patron = plugintools.find_single_match(generos, r'(?s)li class="elem_nH getoff.*?"imagen": "(.*?)".*?class="maintitle">(.*?)<.*?href="(https://www.rtve.es/play/videos/.*?)"')
            if not patron: continue
            foto, titulo, url_target = patron[0], patron[1].replace('&quot;', '"'), patron[2]
            try: texto = plugintools.find_single_match(generos, r'(?s)description .*?<p>(.*?)<.*?')
            except: texto = ""
            
            plugintools.add_item(main_action="lfr", title="[B]"+titulo+"[/B]", url=titulo, plot=texto, thumbnail=foto, folder=True, show_title=show_title)
            
    plugintools.close_item_list()

def series_tve_capitulos(params):
    base_url = 'https://www.rtve.es' + params.get("url")
    show_title = params.get("show_title") or ""
    
    body, _ = plugintools.read_body_and_headers(base_url + '/?page=1')
    matches = plugintools.find_multiple_matches(body, r'(?s)li class="elem_nH getoff.*?"imagen": ".*?".*?class="maintitle">.*?<.*?<.*?.*?<.*?href="https://www.rtve.es/play/videos/.*?"')
    for generos in matches:
        foto = plugintools.find_single_match(generos, r'"imagen": "(.*?)"')
        # Limpiar titulo: a veces viene sucio
        titulo = plugintools.find_single_match(generos, r'class="maintitle">(.*?)<').strip()
        url_target = plugintools.find_single_match(generos, r'href="(https://www.rtve.es/play/videos/.*?)"')
        
        plugintools.add_item(main_action="lfr", title="[B]"+titulo+"[/B]", url=titulo, thumbnail=foto, folder=True, show_title=show_title)
        
    plugintools.close_item_list()

def seriesclan(params):
    url = params.get("url")
    body, _ = plugintools.read_body_and_headers(url)
    matches = plugintools.find_multiple_matches(body, r'(?s)data-rtve-id=".*?".*?a class="linkElemento mainLink" href=".*?".*?ttribute-src=".*?".*?lass="tit M">.*?<.*?apiCall summary"><p>.*?</p>')
    for generos in matches:
        patron = plugintools.find_single_match(generos, r'(?s)data-rtve-id="(.*?)".*?a class="linkElemento mainLink" href=".*?".*?ttribute-src="(.*?)".*?lass="tit M">(.*?)<.*?apiCall summary"><p>(.*?)</p>')
        if not patron: continue
        url_orig, foto, titulo, texto = patron[0], patron[1], patron[2], patron[3]
        final_url = 'https://www.rtve.es/drmn/iso/catalog-category/?&col=5&colT=3&colM=2&size=40&sizeT=9&sizeM=6&exT=N&exM=N&tipopag=0&tpT=0&tpM=0&ctx=INF&n1=Todos&c1=TEM&i1='+url_orig+'&t1=VID&f1=N&o1=FP&e1&q1=type%3D39816&csel=1&de=S&ll=N&stt=S&fakeImg=S&r=/infantil/series/team-nuggets/'
        plugintools.add_item(action="capitulos_clan", url=final_url, title="[B]"+titulo+"[/B]", plot=texto, thumbnail=foto, folder=True, show_title=titulo)
    plugintools.close_item_list()

def capitulos_clan(params):
    url = params.get("url")
    show_title = params.get("show_title") or ""
    
    body, _ = plugintools.read_body_and_headers(url)
    matches = plugintools.find_multiple_matches(body, r'(?s)a class="linkElemento mainLink" href=".*?".*?ttribute-src=".*?".*?lass="tit M">.*?<.*?apiCall summary"><p>.*?</p>')
    for generos in matches:
        patron = plugintools.find_single_match(generos, r'(?s)a class="linkElemento mainLink" href="(.*?)".*?ttribute-src="(.*?)".*?lass="tit M">(.*?)<.*?apiCall summary"><p>(.*?)</p>')
        if not patron: continue
        url_target, foto, titulo, texto = patron[0], patron[1], patron[2], patron[3]
        
        plugintools.add_item(main_action="lfr", title="[B]"+titulo+"[/B]", url=titulo, plot=texto, thumbnail=foto, folder=True, show_title=show_title)
    plugintools.close_item_list()

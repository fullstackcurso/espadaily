# -*- coding: utf-8 -*-
"""
Historial de Exploración
========================
Guarda las últimas 50 rutas de navegación que llegaron a mostrar resultados de búsqueda.
Permite editar palabras clave y añadir al historial de búsquedas.
"""
import sys
import os
import json
import time
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import core_settings

# --- PATHS (Lazy init) ---
_exp_file = None
_settings_file = None
MAX_ITEMS = 50

def _get_profile():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(profile): os.makedirs(profile)
    return profile

def _get_exp_file():
    global _exp_file
    if _exp_file is None:
        _exp_file = os.path.join(_get_profile(), 'exploration_history.json')
    return _exp_file

def _get_settings_file():
    global _settings_file
    if _settings_file is None:
        _settings_file = os.path.join(_get_profile(), 'exploration_settings.json')
    return _settings_file

# --- HELPERS ---
def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

def load_history():
    f = _get_exp_file()
    if not os.path.exists(f): return []
    try:
        with open(f, 'r', encoding='utf-8') as fp:
            return json.load(fp)
    except: return []

def save_history(data):
    f = _get_exp_file()
    try:
        with open(f, 'w', encoding='utf-8') as fp:
            json.dump(data, fp, ensure_ascii=False)
    except: pass

# --- SETTINGS: Depth level ---
def get_depth_level():
    """Obtiene el nivel de profundidad configurado (cuántas palabras del árbol guardar). 0 = todas"""
    f = _get_settings_file()
    if not os.path.exists(f): return 0  # Default: guardar todo
    try:
        with open(f, 'r', encoding='utf-8') as fp:
            return json.load(fp).get("depth", 0)
    except: return 0

def set_depth_level(level):
    f = _get_settings_file()
    try:
        with open(f, 'w', encoding='utf-8') as fp:
            json.dump({"depth": level}, fp)
    except: pass

def trim_query_to_depth(query, depth):
    """
    Recorta el query según el depth configurado.
    depth=0: Todo (sin recorte)
    depth=1: Solo la última palabra (hijo)
    depth=2: Últimas 2 palabras (padre + hijo)
    depth=3: Últimas 3 palabras (abuelo + padre + hijo)
    etc.
    """
    if depth == 0: return query
    
    parts = query.split()
    if len(parts) <= depth:
        return query
    
    return " ".join(parts[-depth:])

def add_exploration(query):
    """
    Añade una ruta de exploración al historial.
    """
    if not query or not query.strip(): return
    query = query.strip()
    
    # Aplicar el recorte según depth configurado
    depth = get_depth_level()
    trimmed_query = trim_query_to_depth(query, depth)
    
    history = load_history()
    
    # --- GESTIÓN DE REPETIDOS Y SIMILARES ---
    # 1. Si ya existe exactamente igual, lo quitamos para que al insertar aparezca al principio
    # 2. Si existe uno que es "parte" de este (ej: "Batman" y el nuevo es "Batman Begins"), 
    #    quitamos el viejo para quedarnos con el más específico.
    new_history = []
    for entry in history:
        old_q = entry.get("query", "")
        # Si el viejo es igual al nuevo, o el nuevo es más completo que el viejo, se descarta el viejo
        if old_q == trimmed_query or (len(trimmed_query) > len(old_q) and trimmed_query.startswith(old_q)):
            continue
        # Si el viejo es más completo que el nuevo, descartamos el nuevo (no lo añadimos porque ya tenemos uno mejor)
        if len(old_q) > len(trimmed_query) and old_q.startswith(trimmed_query):
            return
        new_history.append(entry)
    history = new_history
    
    # Crear entrada con timestamp
    entry = {
        "query": trimmed_query,
        "full_query": query,
        "timestamp": time.time(),
        "date": time.strftime("%d/%m/%Y %H:%M")
    }
    
    # Insertar al principio
    history.insert(0, entry)
    history = history[:MAX_ITEMS]
    save_history(history)

# --- MENU ---
def show_menu():
    """Muestra el historial de rutas exploradas"""
    history = load_history()
    h = _handle()
    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')
    
    # Botón para configurar profundidad
    depth = get_depth_level()
    depth_labels = {0: "TODO (Sin límite)", 1: "1 nivel (Hijo)", 2: "2 niveles (Padre+Hijo)", 3: "3 niveles (Abuelo+Padre+Hijo)", 4: "4 niveles"}
    depth_text = depth_labels.get(depth, f"{depth} niveles")
    
    li = xbmcgui.ListItem(label=f"[COLOR orange]Guardar: {depth_text}[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Configura cuántos niveles del árbol de navegación guardar.\n\n• TODO: Guarda la ruta completa (ej: 'Atresplayer Series Drama La Promesa Capítulo 5').\n• 1 nivel: Solo el último elemento (ej: 'Capítulo 5').\n• 2 niveles: Padre + Hijo (ej: 'La Promesa Capítulo 5').\n• 3 niveles: Abuelo + Padre + Hijo.\n\nPulsa para cambiar."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="exp_set_depth"), listitem=li, isFolder=False)
    
    if not history:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay rutas de exploración guardadas[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'plot': "Las rutas se guardan automáticamente cuando navegas por Atresplayer, RTVE o Mediaset y llegas hasta los resultados de búsqueda."})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    else:
        # Info header
        li = xbmcgui.ListItem(label=f"[COLOR cyan][B]{len(history)} rutas guardadas[/B][/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'plot': "Pulsa en una ruta para EDITAR y BUSCAR.\nClic derecho para más opciones."})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        
        for entry in history:
            q = entry.get("query", "")
            date = entry.get("date", "")
            
            li = xbmcgui.ListItem(label=f"{q}")
            li.setArt({'icon': 'DefaultFolder.png', 'thumb': icon})
            li.setInfo('video', {'plot': f"Explorado: {date}\n\nPulsa para editar y buscar.\nClic derecho para más opciones."})
            
            # Context Menu
            cm = []
            cm.append(("Buscar directamente", f"RunPlugin({_u(action='exp_search_direct', q=q)})"))
            
            # Add to Favorites
            fav_params = json.dumps({'q': q, 'ot': icon})
            # Use safe ID for exploration paths
            import hashlib
            safe_id = hashlib.md5(q.encode('utf-8')).hexdigest()
            cm.append(("Añadir a Mis Favoritos", f"RunPlugin({_u(action='add_favorite', title=q, fav_url=f'lfr_{safe_id}', icon=icon, platform='search', fav_action='lfr', params=fav_params)})"))
            
            if core_settings.is_palantir_integration_enabled():
                cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=q)})"))
            
            cm.append(("Añadir al Historial de Búsquedas", f"RunPlugin({_u(action='exp_to_search', q=q)})"))
            cm.append(("Borrar de esta lista", f"RunPlugin({_u(action='exp_delete', q=q)})"))
            li.addContextMenuItems(cm)
            
            # Al pulsar, abre el teclado con el texto para editar
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="exp_edit", q=q), listitem=li, isFolder=False)
    
    # Botón para borrar todo
    if history:
        li = xbmcgui.ListItem(label="[COLOR red]Borrar todo el historial de exploración[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="exp_clear_all"), listitem=li, isFolder=False)
    
    xbmcplugin.endOfDirectory(h)

def set_depth():
    """Permite configurar la profundidad del árbol a guardar"""
    options = [
        "TODO (Sin límite) - Guarda la ruta completa",
        "1 nivel - Solo el último elemento (Hijo)",
        "2 niveles - Padre + Hijo",
        "3 niveles - Abuelo + Padre + Hijo",
        "4 niveles"
    ]
    
    current = get_depth_level()
    
    sel = xbmcgui.Dialog().select(f"Actualmente: {current} niveles", options)
    if sel >= 0:
        set_depth_level(sel)
        xbmcgui.Dialog().notification("EspaDaily", f"Guardando: {options[sel].split(' - ')[0]}", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")

def edit_query(q):
    """Muestra un menú de opciones para la ruta seleccionada"""
    if not q: return
    
    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')
    
    options = []
    options.append("Buscar directamente")
    
    palantir_enabled = core_settings.is_palantir_integration_enabled()
    if palantir_enabled:
        options.append("Buscar en Palantir 3")
        
    options.append("Editar palabras clave y buscar")
    options.append("Añadir a Mis Favoritos")
    options.append("Añadir al Historial de Búsquedas")
    options.append("Eliminar de esta lista")
    
    sel = xbmcgui.Dialog().select(q, options)
    if sel < 0: return

    # Map selection back to action logic
    selected_txt = options[sel]
    
    if selected_txt == "Buscar directamente":
        xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=q, ot=icon)})")
    
    elif selected_txt == "Buscar en Palantir 3":
        xbmc.executebuiltin(f"RunPlugin({_u(action='palantir_search', q=q)})")

    elif selected_txt == "Editar palabras clave y buscar":
        kb = xbmc.Keyboard(q, 'Edita las palabras clave')
        kb.doModal()
    
    elif selected_txt == "Añadir a Mis Favoritos":
        xbmc.executebuiltin(f"RunPlugin({_u(action='add_favorite', title=q, fav_url=f'lfr_{q}', icon=icon, platform='search', fav_action='lfr', params=json.dumps({'q': q, 'ot': icon}))})")
        if kb.isConfirmed():
            new_q = kb.getText().strip()
            if new_q:
                xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=new_q, ot=icon)})")
    
    elif selected_txt == "Añadir al Historial de Búsquedas":
        add_to_search_history(q)
    
    elif selected_txt == "Eliminar de esta lista":
        delete_entry(q)

def search_direct(q):
    """Busca directamente sin editar"""
    if not q: return
    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')
    xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=q, ot=icon)})")

def add_to_search_history(q):
    """Añade la ruta al historial de búsquedas normal"""
    if not q: return
    
    profile = _get_profile()
    hist_file = os.path.join(profile, 'search_history.json')
    
    history = []
    if os.path.exists(hist_file):
        try:
            with open(hist_file, 'r', encoding='utf-8') as f:
                history = json.load(f)
        except: pass
    
    # Evitar duplicados
    if q in history:
        history.remove(q)
    
    # Insertar al principio
    history.insert(0, q)
    
    # Limitar
    history = history[:50]
    
    try:
        with open(hist_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False)
        xbmcgui.Dialog().notification("EspaDaily", "Añadido al historial de búsquedas", xbmcgui.NOTIFICATION_INFO)
    except:
        xbmcgui.Dialog().notification("EspaDaily", "Error al guardar", xbmcgui.NOTIFICATION_ERROR)

def delete_entry(q):
    """Borra una entrada específica del historial de exploración"""
    if not q: return
    
    history = load_history()
    history = [e for e in history if e.get("query") != q]
    save_history(history)
    xbmc.executebuiltin("Container.Refresh")

def clear_all():
    """Borra todo el historial de exploración"""
    if xbmcgui.Dialog().yesno("Borrar Historial", "¿Estás seguro de que quieres borrar todo el historial de exploración?"):
        save_history([])
        xbmc.executebuiltin("Container.Refresh")

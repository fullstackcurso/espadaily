# -*- coding: utf-8 -*-
import sys
import re
import html
import json
import os
import time
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import requests

_CARTELERA_URL = "https://www.sensacine.com/peliculas/en-cartelera/cines/"
_ESTRENOS_URL  = "https://www.sensacine.com/peliculas/estrenos/"
_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "es-ES,es;q=0.9",
    "Referer": "https://www.sensacine.com/",
}
_SC_TTL = 6 * 3600       # 6 horas
_SC_MIN_FILMS = 3         # resultado con menos películas se considera fallo


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])


# Caché

def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espadaily_sc_cache.json')


def _load_cache():
    empty = {"cartelera": {}}
    try:
        path = _cache_path()
        if not os.path.exists(path):
            return empty
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data.get("cartelera"), dict):
            return empty
        return data
    except Exception as e:
        xbmc.log(f"[EspaDaily-SC] cache load error: {e}", xbmc.LOGWARNING)
        return empty


def _save_cache(data):
    try:
        path = _cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as e:
        xbmc.log(f"[EspaDaily-SC] cache save error: {e}", xbmc.LOGWARNING)


def _cache_fresh(cache):
    c = cache.get("cartelera", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


# Scraping

def _scrape_cartelera():
    """Devuelve lista de {id, title, poster} o None si hay fallo de red."""
    try:
        r = requests.get(_CARTELERA_URL, headers=_HEADERS, timeout=12)
        xbmc.log(f"[EspaDaily-SC] cartelera -> {r.status_code}", xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+class="[^"]*entity-card[^"]*")', r.text):
            id_m = re.search(r'/peliculas/pelicula-(\d+)/', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="meta-title-link"[^>]*>([^<]+)</a>', block)
            if not title_m:
                continue
            seen.add(fid)
            title = html.unescape(title_m.group(1).strip())
            img_m = re.search(r'data-src="(https://[^"]+acsta\.net[^"]*)"', block)
            if not img_m:
                img_m = re.search(r'\bsrc="(https://[^"]+acsta\.net[^"]*)"', block)
            poster = img_m.group(1) if img_m else ''
            films.append({'id': fid, 'title': title, 'poster': poster})
        if len(films) < _SC_MIN_FILMS:
            xbmc.log(f"[EspaDaily-SC] resultado sospechoso ({len(films)} films), ignorando", xbmc.LOGWARNING)
            return None
        xbmc.log(f"[EspaDaily-SC] scrapeadas {len(films)} películas", xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log(f"[EspaDaily-SC] scrape error: {e}", xbmc.LOGERROR)
        return None


# Entrada pública

def _fetch_cartelera():
    cache = _load_cache()

    if _cache_fresh(cache):
        films = cache["cartelera"]["films"]
        xbmc.log(f"[EspaDaily-SC] cartelera desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films

    scraped = _scrape_cartelera()
    if scraped is not None:
        films = scraped
        cache["cartelera"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("cartelera", {}).get("films"):
        films = cache["cartelera"]["films"]
        xbmc.log("[EspaDaily-SC] SC inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_cartelera():
    films = _fetch_cartelera()
    if not films:
        xbmcgui.Dialog().notification("EspaDaily", "No se pudo cargar SensaCine", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return
    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
        li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=f['poster'], mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())

 
# Estrenos

def _estrenos_fresh(cache):
    c = cache.get("estrenos", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


def _scrape_estrenos():
    """Devuelve lista de {id, title, poster} o None si hay fallo de red."""
    try:
        r = requests.get(_ESTRENOS_URL, headers=_HEADERS, timeout=12)
        xbmc.log(f"[EspaDaily-SC] estrenos -> {r.status_code}", xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+class="[^"]*entity-card[^"]*")', r.text):
            id_m = re.search(r'/peliculas/pelicula-(\d+)/', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="meta-title-link"[^>]*>([^<]+)</a>', block)
            if not title_m:
                continue
            seen.add(fid)
            title = html.unescape(title_m.group(1).strip())
            img_m = re.search(r'data-src="(https://[^"]+acsta\.net[^"]*)"', block)
            if not img_m:
                img_m = re.search(r'\bsrc="(https://[^"]+acsta\.net[^"]*)"', block)
            poster = img_m.group(1) if img_m else ''
            films.append({'id': fid, 'title': title, 'poster': poster})
        if len(films) < _SC_MIN_FILMS:
            xbmc.log(f"[EspaDaily-SC] estrenos sospechoso ({len(films)} films), ignorando", xbmc.LOGWARNING)
            return None
        xbmc.log(f"[EspaDaily-SC] estrenos: {len(films)} películas", xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log(f"[EspaDaily-SC] estrenos error: {e}", xbmc.LOGERROR)
        return None


def _fetch_estrenos():
    cache = _load_cache()

    if _estrenos_fresh(cache):
        films = cache["estrenos"]["films"]
        xbmc.log(f"[EspaDaily-SC] estrenos desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films

    scraped = _scrape_estrenos()
    if scraped is not None:
        films = scraped
        cache["estrenos"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("estrenos", {}).get("films"):
        films = cache["estrenos"]["films"]
        xbmc.log("[EspaDaily-SC] estrenos inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_estrenos():
    films = _fetch_estrenos()
    if not films:
        xbmcgui.Dialog().notification("EspaDaily", "No se pudo cargar SensaCine Estrenos", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return
    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
        li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=f['poster'], mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())
